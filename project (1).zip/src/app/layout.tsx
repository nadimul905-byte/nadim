import type { Metadata } from 'next';
import { Inter, Dancing_Script } from 'next/font/google';
import './globals.css';
import { Toaster } from "@/components/ui/toaster";
import { Providers } from './providers';
import Script from 'next/script'; // Import Script component

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
const dancingScript = Dancing_Script({ subsets: ['latin'], variable: '--font-dancing-script' });

export const metadata: Metadata = {
  title: 'Ladook | The Intelligent OS for B2B Fashion',
  description: 'The definitive supply chain infrastructure for global fashion. AI Design Studio, Procurement Hub, and Trust-Bridge Microfinance.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        
      </head>
      <body className={`${inter.variable} ${dancingScript.variable} font-body antialiased`} suppressHydrationWarning={true}>
        <Providers>
          {children}
          <Toaster />
        </Providers>
      </body>
    </html>
  );
}
