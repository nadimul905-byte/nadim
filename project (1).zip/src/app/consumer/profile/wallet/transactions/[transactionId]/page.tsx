"use client";

import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Receipt, DollarSign, Calendar, Info, ShoppingBag, CreditCard, Repeat, HelpCircle } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import Link from 'next/link';

// Mock data - in a real app, this would be fetched from an API based on transactionId
const mockTransactions = [
  { id: 'txn1', type: 'Purchase', amount: -250.00, description: 'Order #ORDC123 - Chic Designs Co.', date: '2024-07-29', time: '14:35', status: 'Completed', paymentMethod: 'Ladook Wallet', reference: 'LAD-PAY-XYZ123' },
  { id: 'txn2', type: 'Funding', amount: 1000.00, description: 'Added funds from Visa **** 1234', date: '2024-07-28', time: '09:12', status: 'Completed', paymentMethod: 'Visa **** 1234', reference: 'STRIPE-ABC456' },
  { id: 'txn3', type: 'Purchase', amount: -75.50, description: 'Order #ORDC122 - Summer Styles', date: '2024-07-27', time: '18:02', status: 'Completed', paymentMethod: 'Ladook Wallet', reference: 'LAD-PAY-DEF456' },
  { id: 'txn4', type: 'Refund', amount: 50.00, description: 'Refund for Order #ORDC119', date: '2024-07-26', time: '11:45', status: 'Completed', paymentMethod: 'Ladook Wallet', reference: 'LAD-REF-GHI789' },
];

type Transaction = typeof mockTransactions[0];

export default function TransactionDetailPage() {
  const router = useRouter();
  const params = useParams();
  const transactionId = params.transactionId as string;
  
  const [transaction, setTransaction] = useState<Transaction | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(true);
    const foundTx = mockTransactions.find(tx => tx.id === transactionId);
    setTransaction(foundTx || null);
    setIsLoading(false);
  }, [transactionId]);

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-24" />
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!transaction) {
    return (
      <div className="text-center py-10">
        <p className="text-lg">Transaction not found.</p>
        <Button onClick={() => router.back()} className="mt-4">Go Back</Button>
      </div>
    );
  }

  const isDebit = transaction.amount < 0;

  return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.back()}>
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Wallet
      </Button>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-headline">Transaction Details</CardTitle>
          <CardDescription>Reference: {transaction.reference}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex justify-center items-center flex-col py-6 bg-muted/50 rounded-lg">
             <p className={`text-5xl font-bold ${isDebit ? 'text-destructive' : 'text-green-600'}`}>
                {isDebit ? `-$${Math.abs(transaction.amount).toFixed(2)}` : `+$${transaction.amount.toFixed(2)}`}
             </p>
             <p className="text-lg font-medium">{transaction.type}</p>
             <p className="text-sm text-muted-foreground">{transaction.status}</p>
          </div>
          
          <Separator />

          <div className="space-y-3 text-sm">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground flex items-center"><Info className="mr-2 h-4 w-4"/>Description</span>
              <span className="font-medium text-right">{transaction.description}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground flex items-center"><Calendar className="mr-2 h-4 w-4"/>Date & Time</span>
              <span className="font-medium">{transaction.date} at {transaction.time}</span>
            </div>
             <div className="flex justify-between items-center">
              <span className="text-muted-foreground flex items-center"><DollarSign className="mr-2 h-4 w-4"/>Payment Method</span>
              <span className="font-medium flex items-center">
                {transaction.paymentMethod.includes('Wallet') ? <ShoppingBag className="mr-1.5 h-4 w-4"/> : <CreditCard className="mr-1.5 h-4 w-4"/>}
                {transaction.paymentMethod}
              </span>
            </div>
          </div>

        </CardContent>
        <CardFooter className="flex-col sm:flex-row gap-3">
          <Button variant="outline" className="w-full sm:w-auto">
            <Receipt className="mr-2 h-4 w-4"/> Download Receipt
          </Button>
          {transaction.type === 'Purchase' && (
              <Button variant="outline" className="w-full sm:w-auto">
                  <Repeat className="mr-2 h-4 w-4"/> Request Refund
              </Button>
          )}
          <Button variant="ghost" className="w-full sm:w-auto sm:ml-auto">
            <HelpCircle className="mr-2 h-4 w-4"/> Report an Issue
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
