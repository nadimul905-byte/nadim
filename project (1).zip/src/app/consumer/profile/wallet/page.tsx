
"use client";

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { ArrowLeft, Wallet, Plus, Minus, Settings, Fingerprint, History, CreditCard, Banknote, Sparkles, ShoppingBag, MessageSquare, Gift } from 'lucide-react';
import Link from 'next/link';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger, DialogClose } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';

// Mock data
const mockTransactions = [
  { id: 'txn1', type: 'Purchase', amount: -250.00, description: 'Order #ORDC123 - Chic Designs Co.', date: '2024-07-29' },
  { id: 'txn2', type: 'Funding', amount: 1000.00, description: 'Added funds from Visa **** 1234', date: '2024-07-28' },
  { id: 'txn3', type: 'Purchase', amount: -75.50, description: 'Order #ORDC122 - Summer Styles', date: '2024-07-27' },
  { id: 'txn4', type: 'Refund', amount: 50.00, description: 'Refund for Order #ORDC119', date: '2024-07-26' },
];

const mockPaymentMethods = [
  { id: 'pm1', type: 'Visa', last4: '1234' },
  { id: 'pm2', type: 'Mastercard', last4: '5678' },
];

const mockBankAccounts = [
  { id: 'acc1', name: 'Main Checking Account', last4: '6789' },
  { id: 'acc2', name: 'Savings Account', last4: '5432' },
];


export default function ConsumerWalletPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [balance, setBalance] = useState(724.50);
  const [lkoinBalance, setLkoinBalance] = useState(1250.00);

  const [addAmount, setAddAmount] = useState('');
  const [selectedCard, setSelectedCard] = useState('pm1');
  const [isAddingFunds, setIsAddingFunds] = useState(false);
  
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [selectedAccount, setSelectedAccount] = useState('acc1');
  const [isWithdrawing, setIsWithdrawing] = useState(false);

  const [convertAmount, setConvertAmount] = useState('');
  const [isConverting, setIsConverting] = useState(false);
  const LKoinRate = 10; // 1 USD = 10 LKoin

  const handleAddFunds = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(addAmount);
    if (!amount || amount <= 0) {
      toast({ title: "Invalid Amount", description: "Please enter a valid amount to add.", variant: "destructive" });
      return;
    }

    setIsAddingFunds(true);
    await new Promise(resolve => setTimeout(resolve, 1500));

    setBalance(prev => prev + amount);
    toast({ title: "Funds Added!", description: `$${amount.toFixed(2)} has been successfully added to your wallet.` });
    
    mockTransactions.unshift({
        id: `txn${Date.now()}`,
        type: 'Funding',
        amount: amount,
        description: `Added funds from ${mockPaymentMethods.find(pm => pm.id === selectedCard)?.type} **** ${mockPaymentMethods.find(pm => pm.id === selectedCard)?.last4}`,
        date: new Date().toISOString().split('T')[0],
    });
    
    setAddAmount('');
    setIsAddingFunds(false);
  };
  
  const handleWithdrawFunds = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(withdrawAmount);
    if (!amount || amount <= 0) {
      toast({ title: "Invalid Amount", description: "Please enter a valid amount to withdraw.", variant: "destructive" });
      return;
    }
    if (amount > balance) {
      toast({ title: "Insufficient Funds", description: "You cannot withdraw more than your current balance.", variant: "destructive" });
      return;
    }

    setIsWithdrawing(true);
    await new Promise(resolve => setTimeout(resolve, 1500));

    setBalance(prev => prev - amount);
    toast({ title: "Withdrawal Initiated", description: `$${amount.toFixed(2)} is being sent to your account.` });
    
    mockTransactions.unshift({
        id: `txn${Date.now()}`,
        type: 'Withdrawal',
        amount: -amount,
        description: `Withdrawal to ${mockBankAccounts.find(acc => acc.id === selectedAccount)?.name} (**** ${mockBankAccounts.find(acc => acc.id === selectedAccount)?.last4})`,
        date: new Date().toISOString().split('T')[0],
    });
    
    setWithdrawAmount('');
    setIsWithdrawing(false);
  };
  
  const handleConversion = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(convertAmount);
    if (!amount || amount <= 0) {
        toast({ title: "Invalid Amount", description: "Please enter a valid amount to convert.", variant: "destructive" });
        return;
    }
    if (amount > balance) {
        toast({ title: "Insufficient Funds", description: "You cannot convert more than your current USD balance.", variant: "destructive" });
        return;
    }
    setIsConverting(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    const lkoinEarned = amount * LKoinRate;
    setBalance(prev => prev - amount);
    setLkoinBalance(prev => prev + lkoinEarned);
    toast({ title: "Conversion Successful!", description: `You converted $${amount.toFixed(2)} to ${lkoinEarned.toFixed(2)} LKoin.` });
    setConvertAmount('');
    setIsConverting(false);
  };


  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={() => router.push('/consumer/profile')}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Profile
        </Button>
        <Button variant="ghost" size="icon" asChild>
            <Link href="/consumer/profile/wallet/security">
                <Settings className="h-5 w-5" />
            </Link>
        </Button>
      </div>

      <Card className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Wallet /> Ladook Wallet (USD)
          </CardTitle>
          <CardDescription className="text-primary-foreground/80">Your current balance</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-5xl font-bold">${balance.toFixed(2)}</p>
        </CardContent>
        <CardFooter className="grid grid-cols-2 gap-3">
          <Dialog>
            <DialogTrigger asChild>
                <Button className="bg-primary-foreground/20 hover:bg-primary-foreground/30 text-primary-foreground">
                    <Plus className="mr-2 h-4 w-4" /> Add Funds
                </Button>
            </DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Add Funds to Your Wallet</DialogTitle>
                    <DialogDescription>Enter the amount you wish to add and select a payment method.</DialogDescription>
                </DialogHeader>
                <form onSubmit={handleAddFunds}>
                    <div className="space-y-4 py-4">
                        <div>
                            <Label htmlFor="amount">Amount (USD)</Label>
                            <Input id="amount" type="number" placeholder="0.00" value={addAmount} onChange={(e) => setAddAmount(e.target.value)} required />
                        </div>
                        <div>
                            <Label>Select Payment Method</Label>
                            <RadioGroup defaultValue="pm1" value={selectedCard} onValueChange={setSelectedCard} className="space-y-2 mt-2">
                                {mockPaymentMethods.map(pm => (
                                    <Label key={pm.id} htmlFor={pm.id} className="flex items-center space-x-3 p-3 border rounded-md has-[:checked]:border-primary has-[:checked]:bg-primary/10 cursor-pointer">
                                        <RadioGroupItem value={pm.id} id={pm.id} />
                                        <CreditCard className="h-5 w-5 mr-2" />
                                        <span>{pm.type} ending in **** {pm.last4}</span>
                                    </Label>
                                ))}
                            </RadioGroup>
                        </div>
                    </div>
                    <DialogFooter>
                        <DialogClose asChild>
                          <Button type="button" variant="outline" disabled={isAddingFunds}>Cancel</Button>
                        </DialogClose>
                        <Button type="submit" disabled={isAddingFunds}>
                            {isAddingFunds ? <>Adding...</> : <>Add ${addAmount || '0.00'}</>}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
          </Dialog>
           <Dialog>
              <DialogTrigger asChild>
                <Button className="bg-primary-foreground/20 hover:bg-primary-foreground/30 text-primary-foreground">
                  <Minus className="mr-2 h-4 w-4" /> Withdraw
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Withdraw Funds</DialogTitle>
                  <DialogDescription>Select an amount and destination account for your withdrawal.</DialogDescription>
                </DialogHeader>
                <form onSubmit={handleWithdrawFunds}>
                    <div className="space-y-4 py-4">
                        <div>
                            <Label htmlFor="withdraw-amount">Amount (USD)</Label>
                            <Input id="withdraw-amount" type="number" placeholder="0.00" value={withdrawAmount} onChange={(e) => setWithdrawAmount(e.target.value)} required />
                        </div>
                        <div>
                            <Label>Withdraw to</Label>
                            <RadioGroup defaultValue="acc1" value={selectedAccount} onValueChange={setSelectedAccount} className="space-y-2 mt-2">
                                {mockBankAccounts.map(acc => (
                                    <Label key={acc.id} htmlFor={acc.id} className="flex items-center space-x-3 p-3 border rounded-md has-[:checked]:border-primary has-[:checked]:bg-primary/10 cursor-pointer">
                                        <RadioGroupItem value={acc.id} id={acc.id} />
                                        <Banknote className="h-5 w-5 mr-2" />
                                        <span>{acc.name} (**** {acc.last4})</span>
                                    </Label>
                                ))}
                            </RadioGroup>
                        </div>
                    </div>
                    <DialogFooter>
                        <DialogClose asChild>
                          <Button type="button" variant="outline" disabled={isWithdrawing}>Cancel</Button>
                        </DialogClose>
                        <Button type="submit" disabled={isWithdrawing}>
                            {isWithdrawing ? <>Processing...</> : <>Withdraw ${withdrawAmount || '0.00'}</>}
                        </Button>
                    </DialogFooter>
                </form>
              </DialogContent>
          </Dialog>
        </CardFooter>
      </Card>
      
      <Card className="bg-gradient-to-br from-accent/90 to-accent/70 text-accent-foreground shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Sparkles /> Ladook Crypto (LKoin)
          </CardTitle>
          <CardDescription className="text-accent-foreground/80">Your platform-native crypto balance.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-5xl font-bold">LK {lkoinBalance.toFixed(2)}</p>
        </CardContent>
        <CardFooter>
             <Dialog>
                <DialogTrigger asChild>
                    <Button className="bg-accent-foreground/20 hover:bg-accent-foreground/30 text-accent-foreground w-full">
                        Convert Funds to LKoin
                    </Button>
                </DialogTrigger>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Convert USD to LKoin</DialogTitle>
                        <DialogDescription>1 USD = {LKoinRate} LKoin. The amount will be deducted from your USD wallet.</DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleConversion}>
                         <div className="space-y-4 py-4">
                            <div>
                                <Label htmlFor="convert-amount">Amount to Convert (USD)</Label>
                                <Input id="convert-amount" type="number" placeholder="0.00" value={convertAmount} onChange={(e) => setConvertAmount(e.target.value)} required />
                            </div>
                            {convertAmount && <p className="text-center font-bold text-lg">You will receive: {parseFloat(convertAmount) * LKoinRate} LKoin</p>}
                        </div>
                        <DialogFooter>
                            <DialogClose asChild><Button type="button" variant="outline" disabled={isConverting}>Cancel</Button></DialogClose>
                            <Button type="submit" disabled={isConverting}>
                                {isConverting ? <>Converting...</> : <>Convert</>}
                            </Button>
                        </DialogFooter>
                    </form>
                </DialogContent>
             </Dialog>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="text-primary"/> How to Earn LKoin
          </CardTitle>
          <CardDescription>
            Actively participate in the Ladook ecosystem to earn more LKoin rewards.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
           <div className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg">
                <ShoppingBag className="h-5 w-5 text-muted-foreground mt-1"/>
                <div>
                    <p className="font-semibold">Make Purchases</p>
                    <p className="text-xs text-muted-foreground">Earn LKoin for every successful order you place on Ladook.</p>
                </div>
           </div>
            <div className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg">
                <MessageSquare className="h-5 w-5 text-muted-foreground mt-1"/>
                <div>
                    <p className="font-semibold">Write Helpful Reviews</p>
                    <p className="text-xs text-muted-foreground">Get LKoin rewards for leaving verified reviews on products you've purchased.</p>
                </div>
            </div>
             <div className="flex items-start gap-3 p-3 bg-muted/50 rounded-lg">
                <Gift className="h-5 w-5 text-muted-foreground mt-1"/>
                <div>
                    <p className="font-semibold">Participate in Promotions</p>
                    <p className="text-xs text-muted-foreground">Keep an eye out for special events and promotions to earn bonus LKoin.</p>
                </div>
            </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Recent Transactions
            <Link href="/consumer/profile/wallet/transactions" className="text-sm font-normal text-primary hover:underline flex items-center">
              View All <History className="ml-1 h-4 w-4" />
            </Link>
          </CardTitle>
          <CardDescription>Your latest wallet activities.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockTransactions.slice(0, 4).map(tx => (
              <Link key={tx.id} href={`/consumer/profile/wallet/transactions/${tx.id}`} className="block p-3 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-semibold">{tx.description}</p>
                    <p className="text-xs text-muted-foreground">{tx.date}</p>
                  </div>
                  <p className={`font-semibold text-lg ${tx.amount > 0 ? 'text-green-500' : 'text-foreground'}`}>
                    {tx.amount > 0 ? `+$${tx.amount.toFixed(2)}` : `-$${Math.abs(tx.amount).toFixed(2)}`}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>

    </div>
  );
}
