"use client";
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { User, Mail, Heart, Settings, HelpCircle, LogOut, Edit3, Moon, Sun, Wallet, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useThemeContext } from '@/app/providers';
import { useRouter } from 'next/navigation';

const ProfileItem = ({ icon: Icon, label, value, action, href }: { icon: React.ElementType, label: string, value?: string | React.ReactNode, action?: React.ReactNode, href?: string }) => (
  <div className="flex items-center justify-between py-3">
    <div className="flex items-center">
      <Icon className="h-5 w-5 text-muted-foreground mr-3" />
      <div>
        <p className="text-sm font-medium">{label}</p>
        {value && typeof value === 'string' ? <p className="text-xs text-muted-foreground">{value}</p> : value}
      </div>
    </div>
    {action && !href && action}
    {href && <Button variant="ghost" size="sm" asChild><Link href={href}><Edit3 className="h-4 w-4"/></Link></Button>}
  </div>
);

export default function ConsumerProfilePage() {
  const router = useRouter(); 
  const { theme, toggleTheme } = useThemeContext();
  const [userName, setUserName] = useState("John Doe"); 
  const [userEmail, setUserEmail] = useState<string | null>("loading...");

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setUserEmail(localStorage.getItem('userEmail') || 'john.doe@email.com');
    }
  }, []);

  const handleLogout = () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('isAuthenticated');
      localStorage.removeItem('selectedRole');
      localStorage.removeItem('userEmail');
    }
    router.push('/auth'); 
  };

  return (
    <div className="space-y-6">
      <Card className="overflow-hidden">
        <CardHeader className="bg-muted/30 p-6 flex flex-col items-center text-center">
           <Avatar className="w-24 h-24 mb-3 border-4 border-background shadow-md">
            <AvatarImage src={"https://picsum.photos/seed/consumer_profile/150/150"} alt={userName} data-ai-hint="person avatar" />
            <AvatarFallback>{userName?.charAt(0)?.toUpperCase() || 'C'}</AvatarFallback>
          </Avatar>
          <CardTitle className="text-2xl font-headline">{userName}</CardTitle>
          <CardDescription>{userEmail}</CardDescription>
          <Button variant="outline" size="sm" className="mt-2" asChild>
            <Link href="/consumer/profile/edit">
              <Edit3 className="mr-2 h-4 w-4"/>Edit Profile
            </Link>
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y">
            <ProfileItem icon={Heart} label="Wishlist" href="/consumer/wishlist" />
            <ProfileItem 
                icon={theme === 'dark' ? Moon : Sun} 
                label="Theme"
                action={<Switch id="theme-toggle" checked={theme === 'dark'} onCheckedChange={toggleTheme}/>}
            />
            <ProfileItem icon={Settings} label="Account Settings" href="/consumer/settings" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="flex items-center gap-2"><Wallet/> Ladook Wallet</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="p-4 bg-secondary/50 rounded-lg flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground">Current Balance</p>
              <p className="text-2xl font-bold text-primary">$724.50</p>
            </div>
            <Button asChild>
              <Link href="/consumer/profile/wallet">Manage <ArrowRight className="ml-2 h-4 w-4"/></Link>
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Help & Support</CardTitle></CardHeader>
        <CardContent className="p-0 divide-y">
            <ProfileItem icon={HelpCircle} label="FAQs & Support Center" href="/consumer/help" />
            <ProfileItem icon={Mail} label="Contact Us" href="/consumer/help/contact" />
        </CardContent>
      </Card>
      
      <Button variant="destructive" className="w-full" onClick={handleLogout}>
        <LogOut className="mr-2 h-4 w-4" /> Logout
      </Button>
    </div>
  );
}
