
"use client";

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Save, UploadCloud, Mail, Phone, Loader2, User } from 'lucide-react';

const CONSUMER_PROFILE_STORAGE_KEY = 'ladookConsumerProfile';
const DEFAULT_AVATAR_URL = "https://picsum.photos/seed/consumer_avatar/150/150";


export default function ConsumerEditProfilePage() {
  const router = useRouter();
  const { toast } = useToast();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [avatarImage, setAvatarImage] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(DEFAULT_AVATAR_URL);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const storedProfileData = localStorage.getItem(CONSUMER_PROFILE_STORAGE_KEY);
      const storedUserEmail = localStorage.getItem('userEmail');

      if (storedProfileData) {
        const parsedData = JSON.parse(storedProfileData);
        setFullName(parsedData.fullName || 'John Doe');
        setEmail(storedUserEmail || parsedData.email || '');
        setPhone(parsedData.phone || '');
        setAvatarPreview(parsedData.avatarPreview || DEFAULT_AVATAR_URL);
      } else {
        setEmail(storedUserEmail || '');
        setFullName('John Doe');
      }
    }
  }, []);

  const handleAvatarChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      setAvatarImage(file);
      setAvatarPreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const profileDataToSave = { fullName, email, phone, avatarPreview };
    localStorage.setItem(CONSUMER_PROFILE_STORAGE_KEY, JSON.stringify(profileDataToSave));
    if (localStorage.getItem('userEmail') !== email) {
        localStorage.setItem('userEmail', email);
    }
    
    await new Promise(resolve => setTimeout(resolve, 1000)); 
    toast({ title: "Profile Updated!", description: "Your profile has been successfully updated." });
    setIsSubmitting(false);
    router.push('/consumer/profile'); 
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="flex items-center gap-4">
        <Button type="button" variant="outline" size="icon" onClick={() => router.back()}><ArrowLeft className="h-5 w-5" /></Button>
        <h1 className="text-3xl font-headline font-semibold">Edit Profile</h1>
      </div>

      <Card>
        <CardHeader><CardTitle>Profile Picture</CardTitle></CardHeader>
        <CardContent className="flex flex-col items-center space-y-4">
          <Avatar className="w-32 h-32 mb-3 border-4 shadow-lg"><AvatarImage src={avatarPreview || undefined} alt={fullName} data-ai-hint="person consumer" /><AvatarFallback className="text-4xl">{fullName?.charAt(0)?.toUpperCase() || 'C'}</AvatarFallback></Avatar>
          <Label htmlFor="avatarUpload" className="cursor-pointer w-full"><div className="flex items-center justify-center w-full p-3 border-2 border-dashed rounded-md hover:bg-muted/50"><UploadCloud className="w-6 h-6 mr-2 text-muted-foreground" /><span className="text-sm text-muted-foreground">Upload Picture</span></div><Input id="avatarUpload" type="file" className="hidden" onChange={handleAvatarChange} accept="image/*" /></Label>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Personal Information</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div><Label htmlFor="fullName">Full Name</Label><div className="relative"><User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" /><Input id="fullName" value={fullName} onChange={(e) => setFullName(e.target.value)} required className="pl-10"/></div></div>
          <div><Label htmlFor="email">Email</Label><div className="relative"><Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" /><Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="pl-10"/></div></div>
          <div><Label htmlFor="phone">Phone</Label><div className="relative"><Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" /><Input id="phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} className="pl-10"/></div></div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={() => router.back()} disabled={isSubmitting}>Cancel</Button>
        <Button type="submit" disabled={isSubmitting} size="lg">{isSubmitting ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Save className="mr-2 h-5 w-5" />}Save Changes</Button>
      </div>
    </form>
  );
}
