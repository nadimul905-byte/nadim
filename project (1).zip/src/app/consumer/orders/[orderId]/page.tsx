"use client";

import React from 'react';
import { useRouter, useParams } from 'next/navigation';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Package, Truck, CheckCircle, XCircle, ShoppingBag, CreditCard, MapPin } from 'lucide-react';
import Link from 'next/link';
import { OrderStatusTimeline } from '@/components/OrderStatusTimeline';

const mockOrder = {
  id: 'ORDC001', date: '2024-07-28', vendorName: 'Fashion House Inc.', status: 'Shipped' as const, totalAmount: 179.98,
  items: [{ id: 'P001', name: 'Elegant Gown', sku: 'EG-RED-M', quantity: 1, unitPrice: 179.98, image: 'https://placehold.co/80x100.png', aiHint: 'gown dress', variant: 'Red, Size M' }],
  shippingAddress: { name: 'John Doe', addressLine1: '456 Oak Avenue', city: 'Metropolis', state: 'NY', zip: '10001', country: 'USA' },
  paymentMethod: 'Visa **** 1234', shippingMethod: 'Standard Express', trackingNumber: '1Z999AA10123456789'
};
type Order = typeof mockOrder;
type OrderItem = typeof mockOrder.items[0];

const StatusBadge = ({ status }: { status: Order['status'] }) => {
  let Icon = Package, color = "bg-gray-100 text-gray-800";
  if (status === "Shipped") { Icon = Truck; color = "bg-purple-100 text-purple-800"; }
  else if (status === "Delivered") { Icon = CheckCircle; color = "bg-green-100 text-green-800"; }
  return <Badge className={`text-sm px-3 py-1.5 ${color}`}><Icon className="h-4 w-4 mr-2" />{status}</Badge>;
};

const OrderItemCard = ({ item }: { item: OrderItem }) => (
  <Card className="overflow-hidden shadow-sm">
    <CardContent className="flex items-center gap-4 p-4">
      <Image src={item.image} alt={item.name} width={80} height={100} className="rounded-md object-cover bg-muted" data-ai-hint={item.aiHint}/>
      <div className="flex-1">
        <h4 className="font-semibold text-base">{item.name}</h4>
        <p className="text-sm text-muted-foreground">SKU: {item.sku}</p>
        <p className="text-xs text-muted-foreground">Variant: {item.variant}</p>
      </div>
      <div className="text-sm text-right">
        <p>{item.quantity} x ${item.unitPrice.toFixed(2)}</p>
        <p className="font-semibold text-primary">${(item.quantity * item.unitPrice).toFixed(2)}</p>
      </div>
    </CardContent>
  </Card>
);

export default function ConsumerOrderDetailPage() {
  const router = useRouter();
  const params = useParams();
  const orderId = params.orderId as string;
  const order = mockOrder;

  return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.push('/consumer/orders')}><ArrowLeft className="mr-2 h-4 w-4" /> Back to My Orders</Button>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between md:items-start gap-2">
            <div>
              <CardTitle className="text-2xl font-headline">Order #{order.id}</CardTitle>
              <CardDescription>Placed on: {order.date} with <Link href={`/consumer/vendors/${order.vendorName.toLowerCase().replace(/\s+/g, '-')}`} className="text-primary font-medium hover:underline">{order.vendorName}</Link></CardDescription>
            </div>
            <StatusBadge status={order.status} />
          </div>
          <CardDescription>Order ID: {orderId}</CardDescription>
        </CardHeader>
        <CardContent><OrderStatusTimeline currentStatus={order.status as any} /></CardContent>
      </Card>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card><CardHeader><CardTitle>Items Ordered</CardTitle></CardHeader><CardContent><OrderItemCard item={order.items[0]} /></CardContent></Card>
        </div>
        <div className="md:col-span-1 space-y-6">
          <Card>
            <CardHeader><CardTitle>Order Summary</CardTitle></CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between"><span>Subtotal:</span> <span>${(order.totalAmount / 1.08 - 5).toFixed(2)}</span></div>
              <div className="flex justify-between"><span>Shipping:</span> <span>$5.00</span></div>
              <div className="flex justify-between"><span>Tax:</span> <span>${(order.totalAmount - (order.totalAmount / 1.08)).toFixed(2)}</span></div>
              <Separator className="my-2"/>
              <div className="flex justify-between font-bold text-lg text-primary"><span>Total:</span> <span>${order.totalAmount.toFixed(2)}</span></div>
            </CardContent>
          </Card>
           <Card>
                <CardHeader><CardTitle>Shipping & Payment</CardTitle></CardHeader>
                <CardContent className="text-sm space-y-3">
                    <div className="font-semibold">Shipping Address:</div>
                    <p className="flex items-start"><MapPin className="mr-2 h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5"/> <span>{order.shippingAddress.name}, {order.shippingAddress.addressLine1}, {order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zip}</span></p>
                    <Separator/>
                    <div className="font-semibold">Payment Method:</div>
                    <p className="flex items-center"><CreditCard className="mr-2 h-4 w-4 text-muted-foreground"/>{order.paymentMethod}</p>
                </CardContent>
            </Card>
        </div>
      </div>
    </div>
  );
}
