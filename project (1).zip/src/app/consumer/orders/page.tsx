"use client";
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Package, Truck, CheckCircle, XCircle, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { Badge } from '@/components/ui/badge';
import { OrderStatusTimeline } from '@/components/OrderStatusTimeline';

// Re-using the retailer order structure for consumers
type OrderStatus = "Pending" | "Processing" | "Shipped" | "Delivered" | "Completed" | "Cancelled";
interface OrderItem { id: string; name: string; image: string; aiHint: string; }
interface Order { id: string; date: string; vendorName: string; status: OrderStatus; totalAmount: number; items: OrderItem[]; }

const mockConsumerOrders: Order[] = [
  { id: 'ORDC001', date: '2024-07-28', vendorName: 'Fashion House Inc.', status: 'Shipped', totalAmount: 179.98, items: [{ id: 'P001', name: 'Elegant Gown', image: 'https://placehold.co/80x80.png', aiHint: 'gown dress' }] },
  { id: 'ORDC002', date: '2024-07-25', vendorName: 'Sneaker World', status: 'Delivered', totalAmount: 89.99, items: [{ id: 'P002', name: 'Stylish Sneakers', image: 'https://placehold.co/80x80.png', aiHint: 'sneakers shoes' }] },
  { id: 'ORDC003', date: '2024-07-30', vendorName: 'Accessories Galore', status: 'Processing', totalAmount: 45.50, items: [{ id: 'P003', name: 'Leather Belt', image: 'https://placehold.co/80x80.png', aiHint: 'leather belt' }] },
  { id: 'ORDC004', date: '2024-07-15', vendorName: 'Denim Co.', status: 'Cancelled', totalAmount: 75.00, items: [{ id: 'P006', name: 'Designer Jeans', image: 'https://placehold.co/80x80.png', aiHint: 'jeans fashion' }] },
];

const StatusIcon = ({ status }: { status: OrderStatus }) => {
  switch (status) {
    case "Pending": return <Package className="h-4 w-4 text-yellow-500" />;
    case "Processing": return <Truck className="h-4 w-4 text-blue-500 animate-pulse" />;
    case "Shipped": return <Truck className="h-4 w-4 text-purple-500" />;
    case "Delivered": case "Completed": return <CheckCircle className="h-4 w-4 text-green-500" />;
    case "Cancelled": return <XCircle className="h-4 w-4 text-red-500" />;
    default: return <Package className="h-4 w-4 text-gray-500" />;
  }
};

const OrderCard = ({ order }: { order: Order }) => (
  <Card className="hover:shadow-md transition-shadow flex flex-col">
    <CardHeader className="p-4 flex flex-row justify-between items-start">
      <div>
        <CardTitle className="text-md">Order #{order.id}</CardTitle>
        <CardDescription>Date: {order.date} • From: {order.vendorName}</CardDescription>
      </div>
      <Badge variant="outline" className="capitalize"><StatusIcon status={order.status} /><span className="ml-1.5">{order.status}</span></Badge>
    </CardHeader>
    <CardContent className="p-4 pt-0 flex-grow">
      {(order.status === 'Processing' || order.status === 'Shipped' || order.status === 'Delivered' || order.status === 'Completed') && <OrderStatusTimeline currentStatus={order.status as any} className="mb-4" />}
      <div className="flex items-center space-x-2">
        {order.items.slice(0,3).map((item, index) => <Image key={index} src={item.image} alt={item.name} width={50} height={50} className="rounded-md border" data-ai-hint={item.aiHint}/>)}
        {order.items.length > 3 && <span className="text-xs text-muted-foreground">+{order.items.length - 3} more</span>}
      </div>
    </CardContent>
    <CardFooter className="p-4 border-t bg-muted/5 flex justify-between items-center">
        <p className="font-semibold text-primary text-lg">${order.totalAmount.toFixed(2)}</p>
        <Button variant="outline" size="sm" asChild><Link href={`/consumer/orders/${order.id}`}>View Details <ArrowRight className="ml-1 h-4 w-4"/></Link></Button>
    </CardFooter>
  </Card>
);

export default function ConsumerOrdersPage() {
  const orderStatuses: OrderStatus[] = ["Processing", "Shipped", "Delivered", "Cancelled"];
  const [currentTab, setCurrentTab] = useState<string>("Processing");

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-headline font-semibold">My Orders</h1>
      <Tabs value={currentTab} onValueChange={setCurrentTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          {orderStatuses.map(status => <TabsTrigger key={status} value={status}>{status}</TabsTrigger>)}
        </TabsList>
        {orderStatuses.map(status => (
          <TabsContent key={status} value={status}>
            <div className="space-y-4 mt-4">
              {mockConsumerOrders.filter(order => order.status === status).length > 0 ? (
                mockConsumerOrders.filter(order => order.status === status).map(order => <OrderCard key={order.id} order={order} />)
              ) : ( <p className="text-center text-muted-foreground py-8">No orders in "{status}" status.</p> )}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
