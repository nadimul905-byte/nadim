"use client";

import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Star, Heart, MessageSquare, ShoppingCart, Sparkles, ChevronLeft, ChevronRight, ZoomIn, PackageSearch, Zap } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { allMockProducts, type Product as BasicProduct } from '@/app/retailer/products/page';
import { Skeleton } from '@/components/ui/skeleton';

interface ConsumerProductDetail {
  id: string;
  name: string;
  brand: string;
  images: { src: string; alt: string; aiHint: string }[];
  price: number;
  variants: {
    size: string[];
    color: string[];
  };
  description: string;
  details: string;
  vendorInfo: {
    name: string;
    logo: string;
    logoAiHint: string;
    rating: number;
    reviews: number;
  };
  reviewsData: { id: number; user: string; rating: number; comment: string }[];
  relatedProducts: { id: string; name: string; price: string; image: string; aiHint: string }[];
}

const generateConsumerMockDetails = (basicProductInfo: BasicProduct): ConsumerProductDetail => {
  const priceStr = basicProductInfo.price.replace('$', '');
  const price = parseFloat(priceStr) || 0;

  return {
    id: basicProductInfo.id,
    name: basicProductInfo.name,
    brand: basicProductInfo.vendorName,
    images: [
      { src: basicProductInfo.image, alt: `${basicProductInfo.name} main view`, aiHint: basicProductInfo.aiHint },
      { src: "https://placehold.co/600x800.png?text=Side+View", alt: `${basicProductInfo.name} side view`, aiHint: "product side" },
      { src: "https://placehold.co/600x800.png?text=Detail+Shot", alt: `${basicProductInfo.name} detail`, aiHint: "product detail" },
    ],
    price: price,
    variants: { 
      size: ['S', 'M', 'L', 'XL'],
      color: ['Default Color', 'Variation Color 1', 'Variation Color 2'],
    },
    description: basicProductInfo.shortDescription + " This is a detailed consumer-facing description about the product's unique qualities, style, and how it can fit into one's life.",
    details: `Material: High-Quality Fabric. Origin: Designed and crafted with care.`,
    vendorInfo: {
      name: basicProductInfo.vendorName,
      logo: basicProductInfo.vendorAvatar,
      logoAiHint: basicProductInfo.vendorAvatarAiHint,
      rating: 4.5 + (Math.random() * 0.5), 
      reviews: Math.floor(Math.random() * 500) + 50, 
    },
    reviewsData: [
      { id: 1, user: "Alex J.", rating: 5, comment: "Absolutely love this! The quality is amazing for the price." },
    ],
    relatedProducts: allMockProducts.slice(5,9).filter(p => p.id !== basicProductInfo.id).map(p => ({
        id: p.id,
        name: p.name,
        price: p.price,
        image: p.image,
        aiHint: p.aiHint
    })),
  };
};

export default function ConsumerProductDetailsPage() {
  const router = useRouter();
  const params = useParams();
  const productId = params.productId as string;
  const { toast } = useToast();

  const [product, setProduct] = useState<ConsumerProductDetail | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string | undefined>();
  const [selectedColor, setSelectedColor] = useState<string | undefined>();
  const [quantity, setQuantity] = useState(1);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [zoomedImageUrl, setZoomedImageUrl] = useState<string | null>(null);

  useEffect(() => {
    setIsLoading(true);
    if (productId) {
      const basicProductInfo = allMockProducts.find(p => p.id === productId);
      if (basicProductInfo) {
        const detailedProduct = generateConsumerMockDetails(basicProductInfo);
        setProduct(detailedProduct);
        setSelectedSize(detailedProduct.variants.size[0]);
        setSelectedColor(detailedProduct.variants.color[0]);
      }
    }
    setIsLoading(false);
  }, [productId]);

  const handleAddToCart = () => {
    if (!product) return;
    toast({ title: "Added to Cart!", description: `${product.name} has been added to your cart.`});
  };
  
  const handleBuyNow = () => {
     if (!product) return;
    toast({ title: "Proceeding to Checkout...", description: `Adding ${product.name} to cart.`});
    router.push('/consumer/checkout');
  };

  if (isLoading) {
    return (
      <div className="container mx-auto py-8">
        <div className="grid md:grid-cols-2 gap-8">
          <div><Skeleton className="aspect-[3/4] w-full rounded-lg" /></div>
          <div className="space-y-4"><Skeleton className="h-8 w-3/4" /><Skeleton className="h-6 w-1/2" /><Skeleton className="h-10 w-1/4" /><Skeleton className="h-24 w-full" /></div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container mx-auto py-12 text-center">
        <PackageSearch className="mx-auto h-24 w-24 text-muted-foreground mb-4" />
        <h1 className="text-2xl font-bold mb-2">Product Not Found</h1>
        <Button onClick={() => router.push('/consumer/categories')}>Back to Shop</Button>
      </div>
    );
  }

  const vendorSlug = product.vendorInfo.name.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]+/g, '');

  return (
    <div className="container mx-auto py-8">
      <div className="grid md:grid-cols-2 gap-8">
        <div className="relative">
          <div className="aspect-[3/4] relative overflow-hidden rounded-lg shadow-lg bg-muted">
            {product.images.length > 0 ? <Image src={product.images[currentImageIndex].src} alt={product.images[currentImageIndex].alt} layout="fill" objectFit="cover" data-ai-hint={product.images[currentImageIndex].aiHint} /> : null}
            <Button variant="ghost" size="icon" className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/30 text-white" onClick={() => setCurrentImageIndex(i => (i - 1 + product.images.length) % product.images.length)}><ChevronLeft /></Button>
            <Button variant="ghost" size="icon" className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/30 text-white" onClick={() => setCurrentImageIndex(i => (i + 1) % product.images.length)}><ChevronRight /></Button>
            <Button variant="ghost" size="icon" className="absolute top-2 right-2 bg-black/30 text-white" onClick={() => { setZoomedImageUrl(product.images[currentImageIndex].src); setIsImageModalOpen(true); }}><ZoomIn /></Button>
          </div>
        </div>

        <div className="space-y-4">
          <h1 className="text-3xl font-headline font-bold">{product.name}</h1>
          <Link href={`/consumer/vendors/${vendorSlug}`} className="text-lg text-muted-foreground hover:text-primary">{product.brand}</Link>
          <div className="flex items-center space-x-2"><Star className="h-5 w-5 text-yellow-400 fill-yellow-400" /><span>{product.vendorInfo.rating.toFixed(1)} ({product.vendorInfo.reviews} reviews)</span></div>
          <div><p className="text-3xl font-semibold text-primary">${product.price.toFixed(2)}</p></div>

          <div className="grid grid-cols-2 gap-4">
            <div><Label htmlFor="size-select">Size</Label><Select value={selectedSize} onValueChange={setSelectedSize}><SelectTrigger id="size-select"><SelectValue /></SelectTrigger><SelectContent>{product.variants.size.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select></div>
            <div><Label htmlFor="color-select">Color</Label><Select value={selectedColor} onValueChange={setSelectedColor}><SelectTrigger id="color-select"><SelectValue /></SelectTrigger><SelectContent>{product.variants.color.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select></div>
          </div>
          
          <div><Label htmlFor="quantity">Quantity</Label><Input type="number" id="quantity" value={quantity} onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))} min="1" className="w-24 mt-1" /></div>

          <div className="space-y-3 pt-4">
            <div className="grid grid-cols-2 gap-3">
              <Button size="lg" className="flex-1" variant="outline" onClick={handleAddToCart}><ShoppingCart className="mr-2 h-5 w-5" />Add to Cart</Button>
              <Button size="lg" className="flex-1" onClick={handleBuyNow}><Zap className="mr-2 h-5 w-5"/>Buy Now</Button>
            </div>
             <div className="grid grid-cols-2 gap-3">
                <Button size="lg" variant="outline" onClick={() => setIsWishlisted(!isWishlisted)} className="flex-1"><Heart className={`mr-2 h-5 w-5 ${isWishlisted ? 'fill-red-500 text-red-500' : ''}`} />{isWishlisted ? 'Wishlisted' : 'Wishlist'}</Button>
                <Button size="lg" variant="outline" className="flex-1" asChild><Link href={`/consumer/messages/${vendorSlug}`}><MessageSquare className="mr-2 h-4 w-4" />Ask Seller</Link></Button>
            </div>
          </div>
        </div>
      </div>
      
      <Dialog open={isImageModalOpen} onOpenChange={setIsImageModalOpen}><DialogContent className="max-w-3xl p-0">{zoomedImageUrl && <div className="relative aspect-[3/4] w-full"><Image src={zoomedImageUrl} alt="Zoomed product" layout="fill" objectFit="contain" /></div>}</DialogContent></Dialog>
    </div>
  );
}
