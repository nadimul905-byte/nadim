
"use client";
import React from 'react';
import { useRouter } from 'next/navigation'; 
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Search, Image as ImageIcon, Heart } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { allMockProducts, type Product as HomePageProduct } from '@/app/retailer/products/page';

const promoBanners = [
  { id: 1, src: "https://images.unsplash.com/photo-1594969155368-f19485a9d88c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxmYXNoaW9uJTIwc2FsZXxlbnwwfHx8fDE3NDkxMjUyMTd8MA&ixlib=rb-4.1.0&q=80&w=1080", alt: "Seasonal Sale", link: "/consumer/products?category=sale", aiHint: "fashion sale" },
  { id: 2, src: "https://images.unsplash.com/photo-1626784579980-db39c1a13aa9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw3fHxmYXNoaW9uJTIwZGVzaWduZXJ8ZW58MHx8fHwxNzQ5MjIwMTUzfDA&ixlib=rb-4.1.0&q=80&w=1080", alt: "Featured Designers", link: "/consumer/designers", aiHint: "fashion designer" },
];

const trendingProducts = allMockProducts.filter(p => ['rp1', 'rp2', 'rp3', 'rp4'].includes(p.id));
const newArrivals = allMockProducts.filter(p => ['new1', 'new2', 'new3', 'new4'].includes(p.id));
const mostViewed = allMockProducts.filter(p => ['view3', 'view4', 'outerwear01', 'active01'].includes(p.id));
const mostBought = allMockProducts.filter(p => ['bought2', 'ss01', 'bag001', 'formal01'].includes(p.id));

const ProductCard = ({ product }: { product: HomePageProduct }) => (
  <Card className="w-48 flex-shrink-0 snap-start overflow-hidden group transform transition-all hover:shadow-lg flex flex-col">
    <Link href={`/consumer/products/${product.id}`} className="block flex-grow flex flex-col">
      <CardContent className="p-0">
        <div className="relative h-48 w-full bg-muted">
          <Image 
            src={product.image} 
            alt={product.name} 
            layout="fill" 
            objectFit="cover" 
            className="transition-transform duration-300 group-hover:scale-105"
            data-ai-hint={product.aiHint} 
          />
           <Button variant="ghost" size="icon" className="absolute top-2 right-2 bg-black/20 hover:bg-black/40 text-white rounded-full h-8 w-8">
              <Heart className="h-4 w-4" />
            </Button>
        </div>
      </CardContent>
      <CardHeader className="p-2.5 flex-grow">
        <CardTitle className="text-sm font-semibold truncate group-hover:text-primary">{product.name}</CardTitle>
        <CardDescription className="text-xs text-muted-foreground mt-0.5 line-clamp-1 h-4">
          {product.vendorName}
        </CardDescription>
        <div className="flex justify-between items-baseline mt-1">
            <p className="text-sm text-primary font-bold">{product.price}</p>
        </div>
      </CardHeader>
    </Link>
  </Card>
);

const ProductCarouselSection = ({ title, products }: { title: string, products: HomePageProduct[] }) => (
  <section>
    <h2 className="text-xl font-headline font-semibold mb-3">{title}</h2>
    <div className="flex overflow-x-auto snap-x snap-mandatory space-x-4 pb-4 no-scrollbar">
      {products.map(product => <ProductCard key={product.id} product={product} />)}
    </div>
  </section>
);


export default function ConsumerHomePage() {
  const [currentBanner, setCurrentBanner] = React.useState(0);
  const [searchTerm, setSearchTerm] = React.useState(''); 
  const router = useRouter(); 

  React.useEffect(() => {
    const timer = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % promoBanners.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const handleSearchSubmit = () => {
    if (searchTerm.trim()) {
      router.push(`/consumer/search?q=${encodeURIComponent(searchTerm.trim())}`);
    }
  };

  return (
    <div className="space-y-8">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input 
          type="search" 
          placeholder="Search products, brands..." 
          className="pl-9 pr-12 py-2 text-sm h-10"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              handleSearchSubmit();
            }
          }}
        />
        <Button variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8" onClick={() => router.push('/consumer/search?image=true')}>
          <ImageIcon className="h-4 w-4 text-muted-foreground" />
        </Button>
      </div>

      <Card className="overflow-hidden shadow-md relative">
        <div className="relative w-full h-40 md:h-48">
          {promoBanners.map((banner, index) => (
            <Link href={banner.link} key={banner.id}>
              <Image 
                src={banner.src} 
                alt={banner.alt} 
                layout="fill" 
                objectFit="cover" 
                className={`transition-opacity duration-1000 ease-in-out ${index === currentBanner ? 'opacity-100' : 'opacity-0'}`}
                data-ai-hint={banner.aiHint}
              />
            </Link>
          ))}
        </div>
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex space-x-1.5">
          {promoBanners.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentBanner(index)}
              className={`w-2 h-2 rounded-full ${index === currentBanner ? 'bg-primary' : 'bg-gray-300'}`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </Card>
      
      <ProductCarouselSection title="Trending Now" products={trendingProducts} />
      <ProductCarouselSection title="New Arrivals" products={newArrivals} />
      <ProductCarouselSection title="Most Viewed" products={mostViewed} />
      <ProductCarouselSection title="Most Purchased" products={mostBought} />

    </div>
  );
}
