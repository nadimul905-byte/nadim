"use client";
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Bell, Moon, Sun, Globe, Edit3, Shield, CreditCard, MapPin } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useThemeContext } from '@/app/providers';
import Link from 'next/link';

const SettingsItem = ({ icon: Icon, label, children }: { icon: React.ElementType, label: string, children: React.ReactNode }) => (
  <div className="flex items-center justify-between py-4 border-b last:border-b-0">
    <div className="flex items-center">
      <Icon className="h-5 w-5 text-muted-foreground mr-4" />
      <Label className="text-base">{label}</Label>
    </div>
    <div>{children}</div>
  </div>
);

export default function ConsumerSettingsPage() {
  const { theme, toggleTheme } = useThemeContext();

  return (
    <div className="space-y-8 max-w-2xl mx-auto">
      <h1 className="text-3xl font-headline font-semibold">Settings</h1>
      
      <Card>
        <CardHeader><CardTitle>General</CardTitle></CardHeader>
        <CardContent className="p-0 divide-y">
          <SettingsItem icon={theme === 'dark' ? Moon : Sun} label="Theme">
            <div className="flex items-center space-x-2">
              <Sun className={`h-5 w-5 ${theme === 'light' ? 'text-primary' : 'text-muted-foreground'}`} />
              <Switch id="theme-toggle" checked={theme === 'dark'} onCheckedChange={toggleTheme} aria-label="Toggle theme"/>
              <Moon className={`h-5 w-5 ${theme === 'dark' ? 'text-primary' : 'text-muted-foreground'}`} />
            </div>
          </SettingsItem>
           <SettingsItem icon={Globe} label="Language & Currency">
            <Button variant="outline" size="sm" asChild><Link href="/consumer/settings/language-currency">English, USD <Edit3 className="ml-2 h-3 w-3" /></Link></Button>
          </SettingsItem>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Notifications</CardTitle></CardHeader>
        <CardContent className="p-0 divide-y">
          <SettingsItem icon={Bell} label="Promotions & Sales"><Switch defaultChecked id="promo-notifications"/></SettingsItem>
          <SettingsItem icon={Bell} label="Order Updates"><Switch defaultChecked id="order-notifications"/></SettingsItem>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Manage</CardTitle></CardHeader>
        <CardContent className="p-0 divide-y">
            <SettingsItem icon={MapPin} label="My Addresses"><Button variant="outline" size="sm" asChild><Link href="/consumer/profile/addresses">Manage</Link></Button></SettingsItem>
            <SettingsItem icon={CreditCard} label="Payment Methods"><Button variant="outline" size="sm" asChild><Link href="/consumer/profile/payment-methods">Manage</Link></Button></SettingsItem>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader><CardTitle>Security</CardTitle></CardHeader>
        <CardContent className="p-0 divide-y">
            <SettingsItem icon={Shield} label="Change Password"><Button variant="outline" size="sm">Change</Button></SettingsItem>
            <SettingsItem icon={Shield} label="Two-Factor Authentication"><Button variant="outline" size="sm">Set Up</Button></SettingsItem>
        </CardContent>
      </Card>
    </div>
  );
}
