
"use client";
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { CreditCard, Landmark, Truck, CircleDollarSign, Loader2, ShoppingBag, Banknote } from 'lucide-react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

// Mock cart items for consumer checkout
const mockCartItems = [
    { id: '1', name: 'Elegant Evening Gown', price: 129.99, quantity: 1, image: 'https://placehold.co/80x80.png', aiHint: "evening gown", variant: 'Cream, Size M' },
    { id: '2', name: 'Stylish Sneakers', price: 89.99, quantity: 2, image: 'https://placehold.co/80x80.png', aiHint: "sneakers shoes", variant: 'White, Size 9' },
];

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  aiHint: string;
  variant?: string;
}


export default function ConsumerCheckoutPage() {
    const { toast } = useToast();
    const router = useRouter();
    
    const [shippingAddress, setShippingAddress] = useState({ name: '', phone: '', address1: '', address2: '', city: '', state: '', zip: '', country: 'USA' });
    const [paymentMethod, setPaymentMethod] = useState('card');
    const [savedAddresses, setSavedAddresses] = useState([{ id: 'addr1', label: 'Home - 123 Main St...', fullAddress: { name: 'John Doe', phone: '555-1234', address1: '123 Main St', city: 'Anytown', state: 'CA', zip: '90210', country: 'USA' }}]);
    const [selectedSavedAddress, setSelectedSavedAddress] = useState('new');
    const [isProcessing, setIsProcessing] = useState(false);
    
    const subtotal = mockCartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const tax = subtotal * 0.08;
    const shippingCost = 5.00;
    const total = subtotal + tax + shippingCost;
    
    const handleSelectSavedAddress = (value: string) => {
        setSelectedSavedAddress(value);
        if(value !== 'new') {
            const addr = savedAddresses.find(a => a.id === value)?.fullAddress;
            if(addr) setShippingAddress(addr);
        } else {
            setShippingAddress({ name: '', phone: '', address1: '', address2: '', city: '', state: '', zip: '', country: 'USA' });
        }
    }

    const handleShippingInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setShippingAddress((prev: any) => ({ ...prev, [name]: value }));
    };
    
    const handlePlaceOrder = (e: React.FormEvent) => {
        e.preventDefault();
        setIsProcessing(true);

         if (!shippingAddress.name || !shippingAddress.address1 || !shippingAddress.city || !shippingAddress.zip) {
            toast({
                title: "Incomplete Shipping Address",
                description: "Please complete your shipping address before placing the order.",
                variant: "destructive"
            });
            setIsProcessing(false);
            return;
        }

        toast({ title: "Processing Order...", description: "Please wait." });
        setTimeout(() => {
            const orderId = `ORDC${Math.floor(Math.random() * 9000) + 1000}`;
            localStorage.setItem('lastConsumerOrderId', orderId);
            toast({ title: "Order Placed!", description: `Your order #${orderId} has been successfully placed.`, duration: 5000});
            router.push('/consumer/orders/confirmation'); 
            setIsProcessing(false);
        }, 2000);
    };

    return (
        <div className="container mx-auto py-8">
            <h1 className="text-3xl font-headline font-semibold mb-6 text-center">Checkout</h1>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
                <div className="lg:col-span-2">
                    <Accordion type="single" collapsible defaultValue="item-1" className="w-full space-y-4">
                        <Card>
                          <AccordionItem value="item-1" className="border-b-0">
                            <AccordionTrigger className="text-xl font-semibold p-4">
                                <div className="flex items-center gap-3">
                                    <Truck className="h-6 w-6 text-primary" />
                                    1. Shipping Address
                                </div>
                            </AccordionTrigger>
                            <AccordionContent className="p-4 pt-0">
                              <div className="space-y-4">
                                <Select onValueChange={handleSelectSavedAddress} defaultValue="new">
                                  <SelectTrigger><SelectValue placeholder="Select an address" /></SelectTrigger>
                                  <SelectContent>
                                    {savedAddresses.map((addr: any) => <SelectItem key={addr.id} value={addr.id}>{addr.label}</SelectItem>)}
                                    <SelectItem value="new">Add New Address</SelectItem>
                                  </SelectContent>
                                </Select>
                                {selectedSavedAddress === 'new' && (
                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t mt-4">
                                    <div><Label htmlFor="name">Full Name</Label><Input id="name" name="name" value={shippingAddress.name} onChange={handleShippingInputChange} required /></div>
                                    <div><Label htmlFor="phone">Phone</Label><Input id="phone" name="phone" type="tel" value={shippingAddress.phone} onChange={handleShippingInputChange} required /></div>
                                    <div className="md:col-span-2"><Label htmlFor="address1">Address Line 1</Label><Input id="address1" name="address1" value={shippingAddress.address1} onChange={handleShippingInputChange} required /></div>
                                    <div className="md:col-span-2"><Label htmlFor="address2">Address Line 2 (Optional)</Label><Input id="address2" name="address2" value={shippingAddress.address2} onChange={handleShippingInputChange} /></div>
                                    <div><Label htmlFor="city">City</Label><Input id="city" name="city" value={shippingAddress.city} onChange={handleShippingInputChange} required /></div>
                                    <div><Label htmlFor="state">State/Province</Label><Input id="state" name="state" value={shippingAddress.state} onChange={handleShippingInputChange} required /></div>
                                    <div><Label htmlFor="zip">ZIP/Postal Code</Label><Input id="zip" name="zip" value={shippingAddress.zip} onChange={handleShippingInputChange} required /></div>
                                    <div><Label htmlFor="country">Country</Label><Input id="country" name="country" value={shippingAddress.country} onChange={handleShippingInputChange} required /></div>
                                  </div>
                                )}
                              </div>
                            </AccordionContent>
                          </AccordionItem>
                        </Card>
                        <Card>
                          <AccordionItem value="item-2" className="border-b-0">
                            <AccordionTrigger className="text-xl font-semibold p-4">
                                <div className="flex items-center gap-3">
                                    <CreditCard className="h-6 w-6 text-primary" />
                                    2. Payment Method
                                </div>
                            </AccordionTrigger>
                            <AccordionContent className="p-4 pt-0">
                                <RadioGroup defaultValue="card" onValueChange={setPaymentMethod} className="space-y-3">
                                    <Label htmlFor="card" className="flex items-center space-x-3 p-3 border rounded-md has-[:checked]:border-primary has-[:checked]:bg-primary/10 cursor-pointer">
                                        <RadioGroupItem value="card" id="card" />
                                        <CreditCard className="h-5 w-5 mr-2" />
                                        <span>Credit/Debit Card</span>
                                    </Label>
                                    {paymentMethod === 'card' && (
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 border rounded-md ml-8">
                                            <div><Label htmlFor="cc-num">Card Number</Label><Input id="cc-num" placeholder="•••• •••• •••• ••••" /></div>
                                            <div><Label htmlFor="cc-exp">Expiry (MM/YY)</Label><Input id="cc-exp" placeholder="MM/YY" /></div>
                                            <div><Label htmlFor="cc-cvc">CVC</Label><Input id="cc-cvc" placeholder="•••" /></div>
                                            <div><Label htmlFor="cc-name">Name on Card</Label><Input id="cc-name" placeholder="John Doe" /></div>
                                        </div>
                                    )}
                                    <Label htmlFor="upi" className="flex items-center space-x-3 p-3 border rounded-md has-[:checked]:border-primary has-[:checked]:bg-primary/10 cursor-pointer">
                                        <RadioGroupItem value="upi" id="upi" /><Landmark className="h-5 w-5 mr-2" /><span>UPI / Digital Wallets</span>
                                    </Label>
                                    <Label htmlFor="cod" className="flex items-center space-x-3 p-3 border rounded-md has-[:checked]:border-primary has-[:checked]:bg-primary/10 cursor-pointer">
                                        <RadioGroupItem value="cod" id="cod" /><CircleDollarSign className="h-5 w-5 mr-2" /><span>Cash on Delivery (COD)</span>
                                    </Label>
                                </RadioGroup>
                            </AccordionContent>
                          </AccordionItem>
                        </Card>
                    </Accordion>
                </div>
                <div className="lg:col-span-1">
                    <Card className="sticky top-24">
                        <CardHeader><CardTitle>Order Summary</CardTitle></CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-3 max-h-60 overflow-y-auto pr-3">
                                {mockCartItems.map((item: CartItem) => (
                                <div key={item.id} className="flex items-center justify-between text-sm">
                                    <div className="flex items-center gap-3">
                                        <Image src={item.image} alt={item.name} width={50} height={50} className="rounded" data-ai-hint={item.aiHint}/>
                                        <div>
                                            <p className="font-medium line-clamp-1">{item.name}</p>
                                            <p className="text-muted-foreground text-xs">Qty: {item.quantity}</p>
                                        </div>
                                    </div>
                                    <span>${(item.price * item.quantity).toFixed(2)}</span>
                                </div>
                                ))}
                            </div>
                            <Separator/>
                            <div className="space-y-1">
                                <div className="flex justify-between text-sm"><span>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
                                <div className="flex justify-between text-sm"><span>Shipping</span><span>${shippingCost.toFixed(2)}</span></div>
                                <div className="flex justify-between text-sm"><span>Tax</span><span>${tax.toFixed(2)}</span></div>
                                <Separator className="my-2"/>
                                <div className="flex justify-between font-bold text-xl"><span>Total</span><span>${total.toFixed(2)}</span></div>
                            </div>
                        </CardContent>
                        <CardFooter>
                            <Button size="lg" className="w-full" onClick={handlePlaceOrder} disabled={isProcessing}>
                                {isProcessing ? <Loader2 className="mr-2 h-5 w-5 animate-spin"/> : <Truck className="mr-2 h-5 w-5"/>}
                                Place Order
                            </Button>
                        </CardFooter>
                    </Card>
                </div>
            </div>
        </div>
    );
}
