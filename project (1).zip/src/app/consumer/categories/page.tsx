
"use client";
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shirt, Watch, Diamond, Footprints, SprayCan, Dumbbell, ShoppingBag, Layers, Scissors, Palette, Package, Sparkles, Tag, Scaling } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { useSearchParams } from 'next/navigation';

// Reusing the same data source as the retailer for consistency
const productCategories = [
  { name: "Women's Apparel", icon: Shirt, link: "/consumer/products?category=womens-apparel", image: "https://images.unsplash.com/photo-1618244972963-dbee1a7edc95?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw1fHx3b21lbiUyMGZhc2hpb258ZW58MHx8fHwxNzQ5NDc5NjM4fDA&ixlib=rb-4.1.0&q=80&w=1080", aiHint:"women fashion" },
  { name: "Men's Apparel", icon: Shirt, link: "/consumer/products?category=mens-apparel", image: "https://images.unsplash.com/photo-1507680434567-5739c80be1ac?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw5fHxtZW4lMjBmYXNoaW9ufGVufDB8fHx8MTc0OTQ3OTYzOHww&ixlib=rb-4.1.0&q=80&w=1080", aiHint:"men fashion" },
  { name: "Kids' Apparel", icon: Shirt, link: "/consumer/products?category=kids-apparel", image: "https://images.unsplash.com/photo-1596870230751-ebdfce98ec42?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwzfHxraWRzJTIwZmFzaGlvbnxlbnwwfHx8fDE3NDk1NTk0NTR8MA&ixlib=rb-4.1.0&q=80&w=1080", aiHint: "kids fashion" },
  { name: "Shoes", icon: Footprints, link: "/consumer/products?category=shoes", image: "https://images.unsplash.com/photo-1529810313688-44ea1c2d81d3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxzaG9lcyUyMGZvb3R3ZWFyfGVufDB8fHx8MTc0OTQ3OTYzOHww&ixlib=rb-4.1.0&q=80&w=1080", aiHint:"shoes footwear" },
  { name: "Accessories", icon: Watch, link: "/consumer/products?category=accessories", image: "https://images.unsplash.com/photo-1618677366787-c02f9a52d6e8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw5fHxmYXNoaW9uJTIwYWNjZXNzb3JpZXN8ZW58MHx8fHwxNzQ5NDc5NjM4fDA&ixlib.rb-4.1.0&q=80&w=1080", aiHint:"fashion accessories" },
  { name: "Bags", icon: ShoppingBag, link: "/consumer/products?category=bags", image: "https://images.unsplash.com/photo-1556935383-b0f5f9ca4100?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw5fHxoYW5kYmFncyUyMGZhc2hpb258ZW58MHx8fHwxNzQ5NTU5NDU0fDA&ixlib=rb-4.1.0&q=80&w=1080", aiHint: "handbags fashion" },
  { name: "Jewelry", icon: Diamond, link: "/consumer/products?category=jewelry", image: "https://images.unsplash.com/photo-1598560917807-1bae44bd2be8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxqZXdlbHJ5JTIwZ29sZHxlbnwwfHx8fDE3NDk0Nzk2Mzh8MA&ixlib.rb-4.1.0&q=80&w=1080", aiHint:"jewelry gold" },
  { name: "Cosmetics", icon: SprayCan, link: "/consumer/products?category=cosmetics", image: "https://images.unsplash.com/photo-1521840233161-295ed621e056?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw5fHxjb3NtZXRpY3MlMjBtYWtldXB8ZW58MHx8fHwxNzQ5NDc5NjM4fDA&ixlib.rb-4.1.0&q=80&w=1080", aiHint:"cosmetics makeup" },
  { name: "Outerwear", icon: Shirt, link: "/consumer/products?category=outerwear", image: "https://images.unsplash.com/photo-1616150840617-a0124ea42a1f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwzfHxqYWNrZXRzJTIwY29hdHN8ZW58MHx8fHwxNzQ5NTU5NDU0fDA&ixlib.rb-4.1.0&q=80&w=1080", aiHint: "jackets coats" },
  { name: "Formal Wear", icon: Shirt, link: "/consumer/products?category=formal-wear", image: "https://images.unsplash.com/photo-1601653311133-9789564fa789?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw5fHxmb3JtYWwlMjBkcmVzc3xlbnwwfHx8fDE3NDk1NTk0NTR8MA&ixlib.rb-4.1.0&q=80&w=1080", aiHint: "formal dress" },
  { name: "Activewear", icon: Dumbbell, link: "/consumer/products?category=activewear", image: "https://images.unsplash.com/photo-1637666544359-0e88de7b3206?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw4fHxhY3RpdmV3ZWFyJTIwc3BvcnRzd2VhcnxlbnwwfHx8fDE3NDk1NTk0NTN8MA&ixlib.rb-4.1.0&q=80&w=1080", aiHint: "activewear sportswear" },
];

const CategoryCard = ({ category }: { category: { name: string, icon: React.ElementType, link: string, image: string, aiHint: string }}) => {
    const Icon = category.icon;
    return (
        <Link href={category.link} key={category.name}>
          <Card className="text-center hover:shadow-xl transition-shadow duration-300 group overflow-hidden">
            <CardHeader className="p-0">
                <div className="relative w-full h-40">
                    <Image src={category.image} alt={category.name} layout="fill" objectFit="cover" className="transition-transform duration-300 group-hover:scale-105" data-ai-hint={category.aiHint}/>
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                         <Icon className="h-10 w-10 text-white mb-2" />
                    </div>
                </div>
            </CardHeader>
            <CardContent className="p-4">
              <CardTitle className="text-md font-medium group-hover:text-primary cursor-pointer">{category.name}</CardTitle>
            </CardContent>
          </Card>
        </Link>
    )
};

export default function ConsumerCategoriesPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-headline font-semibold text-center sm:text-left">Shop by Category</h1>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {productCategories.map(category => (
              <CategoryCard key={category.name} category={category} />
          ))}
      </div>
    </div>
  );
}
