"use client";
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { MinusCircle, PlusCircle, Trash2, ShoppingBag, ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  aiHint: string;
  variant?: string;
}

const initialCartItems: CartItem[] = [
  { id: '1', name: 'Elegant Evening Gown', price: 129.99, quantity: 1, image: 'https://images.unsplash.com/photo-1589083133356-aa13ceaef7fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxldmVuaW5nJTIwZ293bnxlbnwwfHx8fDE3NDkzMzY1NzZ8MA&ixlib=rb-4.1.0&q=80&w=1080', aiHint: "evening gown", variant: "Size: M, Color: Burgundy" },
  { id: '2', name: 'Stylish Sneakers', price: 89.99, quantity: 2, image: 'https://images.unsplash.com/photo-1657627713076-9667ba9aa5dc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw3fHxzbmVha2VycyUyMHNob2VzfGVufDB8fHx8MTc0OTMzNjU3Nnww&ixlib.rb-4.1.0&q=80&w=1080', aiHint: "sneakers shoes", variant: "Size: 9, Color: White" },
];

export default function ConsumerCartPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [cartItems, setCartItems] = useState<CartItem[]>(initialCartItems);

  const updateQuantity = (id: string, newQuantity: number) => {
    if (newQuantity < 1) newQuantity = 1;
    setCartItems(items => items.map(item => item.id === id ? { ...item, quantity: newQuantity } : item));
  };

  const removeItem = (id: string) => {
    setCartItems(items => items.filter(item => item.id !== id));
    toast({ title: "Item Removed", description: "The item has been removed from your cart." });
  };

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const taxRate = 0.08;
  const tax = subtotal * taxRate;
  const shipping = cartItems.length > 0 ? 5.00 : 0;
  const total = subtotal + tax + shipping;

  if (cartItems.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <ShoppingBag className="w-24 h-24 text-muted-foreground mb-6" />
        <h2 className="text-2xl font-semibold mb-2">Your cart is empty</h2>
        <p className="text-muted-foreground mb-6">Looks like you haven't added anything yet.</p>
        <Button asChild size="lg">
          <Link href="/consumer/categories">Shop Now</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-headline font-semibold">Your Cart</h1>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          {cartItems.map(item => (
            <Card key={item.id} className="flex flex-col sm:flex-row items-start sm:items-center p-4 gap-4">
              <Image src={item.image} alt={item.name} width={100} height={120} className="rounded-md object-cover" data-ai-hint={item.aiHint} />
              <div className="flex-1">
                <h3 className="font-semibold">{item.name}</h3>
                {item.variant && <p className="text-xs text-muted-foreground">{item.variant}</p>}
                <p className="text-sm font-medium text-primary">${item.price.toFixed(2)}</p>
              </div>
              <div className="flex items-center space-x-2 mt-2 sm:mt-0">
                <Button variant="ghost" size="icon" onClick={() => updateQuantity(item.id, item.quantity - 1)} disabled={item.quantity <= 1}><MinusCircle className="h-5 w-5" /></Button>
                <Input type="number" value={item.quantity} onChange={(e) => updateQuantity(item.id, parseInt(e.target.value))} className="w-16 text-center h-9" readOnly/>
                <Button variant="ghost" size="icon" onClick={() => updateQuantity(item.id, item.quantity + 1)}><PlusCircle className="h-5 w-5" /></Button>
              </div>
              <Button variant="ghost" size="icon" onClick={() => removeItem(item.id)} className="text-destructive hover:text-destructive-foreground hover:bg-destructive ml-auto sm:ml-4"><Trash2 className="h-5 w-5" /></Button>
            </Card>
          ))}
        </div>

        <div className="lg:col-span-1">
          <Card className="sticky top-20">
            <CardHeader><CardTitle>Order Summary</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between"><span>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
              <div className="flex justify-between"><span>Shipping</span><span>${shipping.toFixed(2)}</span></div>
              <div className="flex justify-between"><span>Tax ({(taxRate * 100).toFixed(0)}%)</span><span>${tax.toFixed(2)}</span></div>
              <Separator />
              <div className="flex justify-between font-semibold text-lg"><span>Total</span><span>${total.toFixed(2)}</span></div>
            </CardContent>
            <CardFooter className="flex flex-col gap-3">
              <Button size="lg" className="w-full" onClick={() => router.push('/consumer/checkout')}>Proceed to Checkout</Button>
              <Button variant="outline" className="w-full" asChild><Link href="/consumer"><ArrowLeft className="mr-2 h-4 w-4" /> Continue Shopping</Link></Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}
