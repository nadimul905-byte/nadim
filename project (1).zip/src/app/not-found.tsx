"use client";

import React from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import LadookLogo from '@/components/LadookLogo';
import { ArrowLeft, Home, Search, ShieldCheck, PackageSearch } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gradient-to-br from-background to-secondary/50 animate-in fade-in duration-700">
      <div className="mb-12 text-center space-y-2">
        <LadookLogo size="medium" className="mx-auto" />
        <p className="text-[10px] font-black uppercase tracking-[0.5em] text-primary">Terminal Status: Online</p>
      </div>

      <Card className="w-full max-w-md rounded-[2.5rem] border shadow-2xl overflow-hidden bg-card transition-all ring-1 ring-zinc-200/50">
        <CardHeader className="p-8 pb-4 text-center">
          <div className="mx-auto h-20 w-20 rounded-3xl bg-primary/10 flex items-center justify-center mb-6 border border-primary/20 shadow-xl">
            <PackageSearch className="h-10 w-10 text-primary" />
          </div>
          <CardTitle className="text-3xl font-headline font-black tracking-tight leading-tight">
            Sector <span className="text-primary italic">Operational.</span>
          </CardTitle>
          <CardDescription className="text-xs font-medium text-muted-foreground mt-2 px-4">
            The platform infrastructure is live, but the requested manifest node has not been indexed in the current OS directory.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-8 pt-4 space-y-6">
          <div className="p-4 bg-muted/30 rounded-2xl border border-dashed flex items-start gap-3">
            <ShieldCheck className="h-4 w-4 text-primary shrink-0 mt-0.5" />
            <p className="text-[11px] font-medium text-muted-foreground leading-relaxed">
              "System integrity verified. The routing failed due to an unmapped path identity within the global supply chain manifest."
            </p>
          </div>

          <div className="space-y-3">
             <Button asChild className="w-full h-14 rounded-2xl bg-zinc-900 text-white hover:bg-zinc-800 font-black uppercase text-xs shadow-xl active:scale-95 transition-all">
                <Link href="/">
                    <Home className="mr-2 h-4 w-4" /> Return to Terminal Hub
                </Link>
            </Button>
            
            <div className="grid grid-cols-2 gap-3">
                <Button variant="outline" asChild className="rounded-xl h-12 text-[10px] font-black uppercase tracking-widest border-zinc-200">
                    <Link href="/auth">
                        Re-Authorize
                    </Link>
                </Button>
                 <Button variant="outline" onClick={() => window.history.back()} className="rounded-xl h-12 text-[10px] font-black uppercase tracking-widest border-zinc-200">
                    <ArrowLeft className="mr-1.5 h-3.5 w-3.5" /> Previous Node
                </Button>
            </div>
          </div>
        </CardContent>
        <div className="p-4 bg-muted/10 border-t border-dashed text-center">
            <p className="text-[8px] font-black uppercase text-muted-foreground/40 tracking-[0.3em]">Ladook Global Infrastructure v4.1.0</p>
        </div>
      </Card>
      
      <div className="mt-12 flex items-center gap-6">
         <Search className="h-4 w-4 text-primary" />
         <div className="h-1 w-24 bg-primary/20 rounded-full" />
         <div className="h-1 w-8 bg-primary/40 rounded-full" />
      </div>
    </div>
  );
}
