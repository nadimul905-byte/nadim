"use client";

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ShieldCheck, KeyRound } from 'lucide-react';
import LadookLogo from '@/components/LadookLogo';
import { useToast } from '@/hooks/use-toast';

export default function VerificationPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [verificationCode, setVerificationCode] = useState('');
  const [selectedRole, setSelectedRole] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const role = localStorage.getItem('selectedRole');
      setSelectedRole(role);
      if (!role) {
        // Redirect if role is not set, perhaps back to role selection or auth
        router.push('/role-selection');
      }
    }
  }, [router]);

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock verification
    if (verificationCode.length < 4) { // Basic validation
      toast({ title: "Verification Error", description: "Please enter a valid code.", variant: "destructive" });
      return;
    }
    console.log('Verification attempt with code:', verificationCode, 'for role:', selectedRole);
    if (typeof window !== 'undefined') {
      localStorage.setItem('isAuthenticated', 'true');
    }
    toast({ title: "Verification Successful!", description: "Your account is now active." });
    if (selectedRole) {
      router.push(`/${selectedRole}`);
    } else {
      router.push('/'); // Fallback
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gradient-to-br from-background to-secondary">
      <LadookLogo className="mb-6" />
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-headline">Verify Your Account</CardTitle>
          <CardDescription>Enter the code sent to your email or phone.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleVerify} className="space-y-6">
            <div className="space-y-1">
              <Label htmlFor="verification-code">Verification Code</Label>
              <div className="relative">
                <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  id="verification-code" 
                  type="text" 
                  placeholder="Enter code" 
                  value={verificationCode} 
                  onChange={(e) => setVerificationCode(e.target.value)} 
                  required 
                  className="pl-10 text-center tracking-[0.5em]"
                  maxLength={6}
                />
              </div>
            </div>
            <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
              <ShieldCheck className="mr-2 h-4 w-4" /> Verify
            </Button>
            <div className="text-center text-sm">
              <Button variant="link" type="button" className="text-primary">Resend Code</Button>
            </div>
          </form>
        </CardContent>
      </Card>
      <Button variant="link" onClick={() => router.push('/auth')} className="mt-6 text-primary">Back to Login/Sign Up</Button>
    </div>
  );
}
