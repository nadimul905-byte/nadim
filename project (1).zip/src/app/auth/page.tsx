
"use client";

import React, { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Mail, Lock, Briefcase, User, Phone, Building, UploadCloud, LogIn, UserPlus, FileText, Shield, ShoppingBag, Loader2 } from 'lucide-react';
import LadookLogo from '@/components/LadookLogo';
import { useToast } from '@/hooks/use-toast';

function AuthContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const [selectedRole, setSelectedRole] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("login");
  const [roleInitiallyLoaded, setRoleInitiallyLoaded] = useState(false);

  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Signup form state (common)
  const [signupName, setSignupName] = useState(''); // For full name
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupPhone, setSignupPhone] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);

  // Retailer specific
  const [retailerCompany, setRetailerCompany] = useState('');
  const [retailerAddress, setRetailerAddress] = useState('');

  // Vendor specific
  const [vendorBusinessName, setVendorBusinessName] = useState('');
  const [vendorBusinessAddress, setVendorBusinessAddress] = useState('');
  const [vendorBusinessRegNo, setVendorBusinessRegNo] = useState('');

  const roleFromQuery = searchParams.get('role');

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const roleFromStorage = localStorage.getItem('selectedRole');
      
      let roleToSet: string | null = null;

      if (roleFromQuery === 'admin') {
        roleToSet = 'admin';
      } else if (roleFromStorage) {
        roleToSet = roleFromStorage;
      }
      
      if (roleToSet) {
        setSelectedRole(roleToSet);
        localStorage.setItem('selectedRole', roleToSet); 
        if (roleToSet === 'admin') {
          setActiveTab('login'); 
        }
      }
      setRoleInitiallyLoaded(true);
    }
  }, [roleFromQuery]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail || !loginPassword) {
      toast({ title: "Login Error", description: "Please fill in all fields.", variant: "destructive" });
      return;
    }
    console.log('Login attempt:', { email: loginEmail, role: selectedRole });
    if (typeof window !== 'undefined') {
      localStorage.setItem('isAuthenticated', 'true');
      localStorage.setItem('userEmail', loginEmail);
    }
    toast({ title: "Login Successful", description: `Welcome back, ${selectedRole || 'user'}!` });
    if (selectedRole) {
     router.push(`/${selectedRole}`);
    } else {
      router.push('/');
    }
  };

  const handleSignup = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!termsAccepted) {
      toast({ title: "Signup Error", description: "You must accept the terms and privacy policy.", variant: "destructive" });
      return;
    }

    if (!signupName || !signupEmail || !signupPassword) {
      toast({ title: "Signup Error", description: "Please fill in Full Name, Email, and Password.", variant: "destructive" });
      return;
    }
    
    if (selectedRole === 'retailer') {
      if (!retailerAddress) {
        toast({ title: "Signup Error", description: "Please provide your store's address.", variant: "destructive" });
        return;
      }
    } else if (selectedRole === 'vendor') {
      if (!vendorBusinessName || !vendorBusinessAddress || !vendorBusinessRegNo) {
        toast({ title: "Signup Error", description: "Please fill in all required business details: Business Name, Address, and Registration Number.", variant: "destructive" });
        return;
      }
      const authDocInput = document.getElementById('vendor-auth-document') as HTMLInputElement;
      if (!authDocInput || !authDocInput.files || authDocInput.files.length === 0) {
        toast({ title: "Signup Error", description: "Please upload the Business Authentication Document.", variant: "destructive" });
        return;
      }
    }

    console.log('Signup attempt for role:', selectedRole, { name: signupName, email: signupEmail });
    toast({ title: "Account Creation Initiated", description: "Please check your email/phone to verify your account." });
    router.push('/auth/verify'); 
  };
  
  const handleRoleButtonClick = (role: string) => {
    setSelectedRole(role);
    if (typeof window !== 'undefined') {
      localStorage.setItem('selectedRole', role);
    }
    setActiveTab('signup'); 
  };
  
  const handleAdminIconClick = () => {
    router.push('/auth?role=admin');
  };

  const getPortalTitle = () => {
    switch (selectedRole) {
      case 'retailer': return 'Buyer/Retailer Portal';
      case 'vendor': return 'Seller/Vendor Portal';
      case 'admin': return 'Admin Portal';
      case 'consumer': return 'Customer Portal';
      default: return 'Welcome';
    }
  };

  const consumerSignupFields = (
    <>
      <div className="space-y-1">
        <Label htmlFor="consumer-signup-name">Full Name</Label>
        <div className="relative">
          <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="consumer-signup-name" placeholder="Your Full Name" value={signupName} onChange={(e) => setSignupName(e.target.value)} required className="pl-10" />
        </div>
      </div>
      <div className="space-y-1">
        <Label htmlFor="consumer-signup-email">Email</Label>
        <div className="relative">
          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="consumer-signup-email" type="email" placeholder="you@example.com" value={signupEmail} onChange={(e) => setSignupEmail(e.target.value)} required className="pl-10" />
        </div>
      </div>
      <div className="space-y-1">
        <Label htmlFor="consumer-signup-password">Password</Label>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="consumer-signup-password" type="password" placeholder="••••••••" value={signupPassword} onChange={(e) => setSignupPassword(e.target.value)} required className="pl-10" />
        </div>
      </div>
    </>
  );


  const retailerSignupFields = (
    <>
       <div className="space-y-1">
        <Label htmlFor="retailer-signup-name">Full Name</Label>
        <div className="relative">
          <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="retailer-signup-name" placeholder="Your Full Name" value={signupName} onChange={(e) => setSignupName(e.target.value)} required className="pl-10" />
        </div>
      </div>
      <div className="space-y-1">
        <Label htmlFor="retailer-signup-email">Email</Label>
        <div className="relative">
          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="retailer-signup-email" type="email" placeholder="you@example.com" value={signupEmail} onChange={(e) => setSignupEmail(e.target.value)} required className="pl-10" />
        </div>
      </div>
      <div className="space-y-1">
        <Label htmlFor="retailer-signup-password">Password</Label>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="retailer-signup-password" type="password" placeholder="••••••••" value={signupPassword} onChange={(e) => setSignupPassword(e.target.value)} required className="pl-10" />
        </div>
      </div>
      <div className="space-y-1">
        <Label htmlFor="retailer-signup-phone">Phone (Optional)</Label>
        <div className="relative">
          <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="retailer-signup-phone" type="tel" placeholder="+1234567890" value={signupPhone} onChange={(e) => setSignupPhone(e.target.value)} className="pl-10" />
        </div>
      </div>
      <div className="space-y-1">
        <Label htmlFor="retailer-company">Company (Optional)</Label>
        <div className="relative">
          <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="retailer-company" placeholder="Your Company Inc." value={retailerCompany} onChange={(e) => setRetailerCompany(e.target.value)} className="pl-10" />
        </div>
      </div>
       <div className="space-y-1">
        <Label htmlFor="retailer-address">Address</Label>
        <div className="relative">
          <Building className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="retailer-address" placeholder="123 Main St, City" value={retailerAddress} onChange={(e) => setRetailerAddress(e.target.value)} required className="pl-10" />
        </div>
      </div>
    </>
  );

  const vendorSignupFields = (
    <>
      <div className="space-y-1">
        <Label htmlFor="vendor-signup-name">Full Name</Label>
        <div className="relative">
          <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="vendor-signup-name" placeholder="Your Full Name" value={signupName} onChange={(e) => setSignupName(e.target.value)} required className="pl-10" />
        </div>
      </div>
      <div className="space-y-1">
        <Label htmlFor="vendor-signup-email">Email</Label>
        <div className="relative">
          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="vendor-signup-email" type="email" placeholder="you@example.com" value={signupEmail} onChange={(e) => setSignupEmail(e.target.value)} required className="pl-10" />
        </div>
      </div>
      <div className="space-y-1">
        <Label htmlFor="vendor-signup-password">Password</Label>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="vendor-signup-password" type="password" placeholder="••••••••" value={signupPassword} onChange={(e) => setSignupPassword(e.target.value)} required className="pl-10" />
        </div>
      </div>
      <div className="space-y-1">
        <Label htmlFor="vendor-signup-phone">Phone (Optional)</Label>
        <div className="relative">
          <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="vendor-signup-phone" type="tel" placeholder="+1234567890" value={signupPhone} onChange={(e) => setSignupPhone(e.target.value)} className="pl-10" />
        </div>
      </div>
      <div className="space-y-1">
        <Label htmlFor="vendor-business-name">Business Name</Label>
         <div className="relative">
          <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="vendor-business-name" placeholder="Your Business Name" value={vendorBusinessName} onChange={(e) => setVendorBusinessName(e.target.value)} required className="pl-10" />
        </div>
      </div>
      <div className="space-y-1">
        <Label htmlFor="vendor-business-address">Business Address</Label>
        <div className="relative">
          <Building className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="vendor-business-address" placeholder="123 Business Rd, City" value={vendorBusinessAddress} onChange={(e) => setVendorBusinessAddress(e.target.value)} required className="pl-10" />
        </div>
      </div>
      <div className="space-y-1">
        <Label htmlFor="vendor-business-reg-no">Business Registration No.</Label>
        <div className="relative">
          <FileText className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="vendor-business-reg-no" placeholder="e.g., 123456789" value={vendorBusinessRegNo} onChange={(e) => setVendorBusinessRegNo(e.target.value)} required className="pl-10" />
        </div>
      </div>
      <div className="space-y-1">
        <Label htmlFor="vendor-auth-document">Business Authentication Document</Label>
        <div className="relative">
          <UploadCloud className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="vendor-auth-document" type="file" required className="pl-10 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20" />
        </div>
         <p className="text-xs text-muted-foreground pl-10 pt-1">Upload your official business registration or license.</p>
      </div>
      <div className="space-y-1">
        <Label htmlFor="vendor-certifications">Additional Certifications (Optional)</Label>
        <div className="relative">
          <UploadCloud className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input id="vendor-certifications" type="file" className="pl-10 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20" />
        </div>
      </div>
    </>
  );

  if (!roleInitiallyLoaded) {
    return <div className="flex items-center justify-center min-h-screen"><LadookLogo className="animate-pulse"/> <p className="ml-3">Loading authentication options...</p></div>;
  }
  
  if (!selectedRole) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gradient-to-br from-background to-secondary">
        <LadookLogo className="mb-8" />
        <Card className="w-full max-w-lg shadow-xl relative">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-headline">Choose Your Role</CardTitle>
            <CardDescription>How will you be using Ladook today?</CardDescription>
          </CardHeader>
           <Button
            variant="ghost"
            size="icon"
            className="absolute top-2 right-2 h-8 w-8 opacity-50 hover:opacity-100 transition-opacity"
            onClick={handleAdminIconClick}
            aria-label="Admin Access"
          >
            <Shield className="h-5 w-5 text-muted-foreground" />
          </Button>
          <CardContent className="space-y-4 pt-4">
            <Button className="w-full py-6 text-lg" onClick={() => handleRoleButtonClick('retailer')}>
              <User className="mr-3 h-6 w-6" /> I'm a Buyer / Retailer
            </Button>
            <Button className="w-full py-6 text-lg" onClick={() => handleRoleButtonClick('vendor')}>
              <Briefcase className="mr-3 h-6 w-6" /> I'm a Seller / Vendor
            </Button>
            <Button className="w-full py-6 text-lg" onClick={() => handleRoleButtonClick('consumer')}>
              <ShoppingBag className="mr-3 h-6 w-6" /> I'm a Customer
            </Button>
          </CardContent>
        </Card>
        <Button variant="link" onClick={() => router.push('/onboarding')} className="mt-6 text-primary">
            Back to Onboarding
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gradient-to-br from-background to-secondary">
      <LadookLogo className="mb-6" />
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-headline capitalize">
            {getPortalTitle()}
          </CardTitle>
          <CardDescription>Access your Ladook account or create a new one.</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="signup" disabled={selectedRole === 'admin'}>Sign Up</TabsTrigger>
            </TabsList>
            <TabsContent value="login">
              <form onSubmit={handleLogin} className="space-y-4 mt-4">
                <div className="space-y-1">
                  <Label htmlFor="login-email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input id="login-email" type="email" placeholder="you@example.com" value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} required className="pl-10" />
                  </div>
                </div>
                <div className="space-y-1">
                  <Label htmlFor="login-password">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input id="login-password" type="password" placeholder="••••••••" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} required className="pl-10" />
                  </div>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <Button variant="link" type="button" className="p-0 h-auto text-primary">Forgot Password?</Button>
                </div>
                <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
                  <LogIn className="mr-2 h-4 w-4" /> Login
                </Button>
                
                <div className="relative py-2">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-background px-2 text-muted-foreground">
                      Or continue with
                    </span>
                  </div>
                </div>
                 <div className="grid grid-cols-2 gap-2">
                    <Button variant="outline" type="button">Google</Button>
                    <Button variant="outline" type="button">Facebook</Button>
                 </div>
              </form>
            </TabsContent>
            <TabsContent value="signup">
              <form onSubmit={handleSignup} className="space-y-4 mt-4">
                {selectedRole === 'retailer' && retailerSignupFields}
                {selectedRole === 'vendor' && vendorSignupFields}
                {selectedRole === 'consumer' && consumerSignupFields}
                
                <div className="flex items-center space-x-2">
                  <Checkbox id="terms" checked={termsAccepted} onCheckedChange={(checked) => setTermsAccepted(checked as boolean)} />
                  <Label htmlFor="terms" className="text-sm font-normal">
                    I agree to the <Button variant="link" type="button" className="p-0 h-auto inline text-primary">Terms</Button> & <Button variant="link" type="button" className="p-0 h-auto inline text-primary">Privacy Policy</Button>.
                  </Label>
                </div>
                <Button type="submit" className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
                  <UserPlus className="mr-2 h-4 w-4" /> Create Account
                </Button>

                <div className="relative py-2">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-background px-2 text-muted-foreground">
                      Or sign up with
                    </span>
                  </div>
                </div>
                 <div className="grid grid-cols-2 gap-2">
                    <Button variant="outline" type="button">Google</Button>
                    <Button variant="outline" type="button">Facebook</Button>
                 </div>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      <Button variant="link" onClick={() => { setSelectedRole(null); if(typeof window !== 'undefined') localStorage.removeItem('selectedRole'); router.push('/auth'); }} className="mt-6 text-primary">
        Choose a different role
      </Button>
    </div>
  );
}

export default function AuthPage() {
  return (
    <Suspense fallback={<div className="flex justify-center items-center min-h-screen"><Loader2 className="animate-spin h-10 w-10 text-primary" /></div>}>
      <AuthContent />
    </Suspense>
  )
}
