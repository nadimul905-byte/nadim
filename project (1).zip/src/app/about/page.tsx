"use client";

import React from 'react';
import { Button } from '@/components/ui/button';
import LadookLogo from '@/components/LadookLogo';
import { Zap, Handshake, BrainCircuit, ShieldCheck, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent } from '@/components/ui/card';

const TeamMemberCard = ({ name, role, description, imageUrl, aiHint }: { name: string, role: string, description: string, imageUrl: string, aiHint: string }) => (
  <div className="text-center">
    <Avatar className="w-32 h-32 mx-auto mb-4 border-4 border-primary/20 shadow-lg">
      <AvatarImage src={imageUrl} alt={name} data-ai-hint={aiHint}/>
      <AvatarFallback>{name.charAt(0)}</AvatarFallback>
    </Avatar>
    <h3 className="text-xl font-semibold">{name}</h3>
    <p className="text-primary font-medium">{role}</p>
    <p className="text-muted-foreground mt-2 text-sm">{description}</p>
  </div>
);

export default function AboutUsPage() {
  return (
    <div className="bg-background text-foreground">
      <div className="container mx-auto py-16 px-4 sm:px-6 lg:px-8">
        
        <header className="text-center mb-20">
          <LadookLogo size="large" className="mb-4" />
          <h1 className="text-4xl font-headline font-bold tracking-tight sm:text-5xl md:text-6xl">
            We're Rebuilding Fashion's <span className="text-primary italic">Broken Supply Chain.</span>
          </h1>
          <p className="mt-6 text-lg max-w-3xl mx-auto text-muted-foreground">
            Ladook is more than a marketplace. It is the single, intelligent operating system that manifests designs into global inventory.
          </p>
           <Button asChild size="lg" className="mt-8 rounded-full px-10">
                <Link href="/auth">Join the Movement</Link>
            </Button>
        </header>

        <section className="mb-20">
            <Card className="rounded-[3rem] bg-zinc-900 text-white border-none shadow-2xl overflow-hidden relative">
                <CardContent className="p-12 text-center space-y-6">
                    <div className="mx-auto h-16 w-16 rounded-2xl bg-primary/20 flex items-center justify-center mb-4">
                        <ShieldCheck className="h-10 w-10 text-primary" />
                    </div>
                    <h2 className="text-3xl font-headline font-black uppercase tracking-tight">The Ladook Edge: The Trust Bridge</h2>
                    <p className="text-xl text-zinc-300 max-w-2xl mx-auto leading-relaxed italic">
                        "The core thing we do that others don't: We turn operational performance into technical collateral."
                    </p>
                    <p className="text-zinc-400 text-sm max-w-xl mx-auto">
                        While others stop at the transaction, we use your real-time fulfillment data to unlock purpose-locked inventory financing. Funds are disbursed directly to vendors against specific purchase orders, eliminating the working capital gap and fraud in one move.
                    </p>
                </CardContent>
            </Card>
        </section>

        <Separator className="my-20" />

        <section className="mb-20">
            <div className="text-center">
                 <h2 className="text-3xl font-headline font-bold mb-4">Our Core Pillars</h2>
            </div>
            <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <div className="flex flex-col items-center p-6 bg-card rounded-3xl border shadow-sm">
                    <div className="h-12 w-12 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
                        <Handshake className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">Direct Procurement</h3>
                    <p className="text-sm text-muted-foreground">
                        We provide a direct, transparent sales channel for factories and a vetted sourcing hub for retailers.
                    </p>
                </div>
                <div className="flex flex-col items-center p-6 bg-card rounded-3xl border shadow-sm">
                    <div className="h-12 w-12 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
                        <BrainCircuit className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">AI Design Studio</h3>
                    <p className="text-sm text-muted-foreground">
                       AI-native tools that shorten the design-to-sample cycle from weeks to minutes.
                    </p>
                </div>
                <div className="flex flex-col items-center p-6 bg-card rounded-3xl border shadow-sm">
                    <div className="h-12 w-12 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
                        <Zap className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">Platform Intelligence</h3>
                    <p className="text-sm text-muted-foreground">
                        Performance-based "Trust Scores" that reward reliable partners with prioritized capital access.
                    </p>
                </div>
            </div>
        </section>

        <Separator className="my-20" />

        <section className="text-center mb-16">
            <h2 className="text-3xl font-headline font-bold mb-4">Our Story is Our Advantage</h2>
            <div className="prose max-w-3xl mx-auto text-lg text-muted-foreground">
                <p>
                    Having grown up with family in the garment factories of Bangladesh, we saw incredible skill shackled by an archaic system. Ladook was born from a simple promise: to build the technology that gives creators control, profit, and a direct voice in the global market.
                </p>
            </div>
            <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
                <TeamMemberCard name="[Your Name]" role="Co-Founder & CEO" description="10+ years in tech. Direct family ties to the garment industry hubs." imageUrl="https://picsum.photos/seed/team1/200/200" aiHint="person ceo" />
                <TeamMemberCard name="[Co-founder Name]" role="Co-Founder & CTO" description="Ex-Shopify/Amazon. Expert in scalable marketplace and fintech architecture." imageUrl="https://picsum.photos/seed/team2/200/200" aiHint="person cto" />
                <TeamMemberCard name="[Co-founder Name]" role="Head of Operations" description="15+ years on the ground in Dhaka. Unmatched supply network access." imageUrl="https://picsum.photos/seed/team3/200/200" aiHint="person operations" />
            </div>
        </section>

      </div>
    </div>
  );
}
