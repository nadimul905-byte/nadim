
"use client";
import React from 'react';
import { Button } from '@/components/ui/button';
import LadookLogo from '@/components/LadookLogo';
import Image from 'next/image';
import { Download, Monitor, Printer } from 'lucide-react';

export default function PitchDeckPage() {

    return (
        <>
            <style jsx global>{`
                @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap');
                
                .pitch-deck-container {
                    font-family: 'Inter', sans-serif;
                    background-color: #F0F0F0;
                    color: #333;
                }

                .pitch-deck-slide {
                    background-color: white;
                    width: 100%;
                    height: 100vh;
                    padding: 4rem;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    border-bottom: 1px solid #e0e0e0;
                    position: relative;
                }
                
                .slide-footer {
                    position: absolute;
                    bottom: 2rem;
                    left: 4rem;
                    font-size: 0.875rem;
                    color: #888;
                }

                .no-print {
                    position: fixed;
                    top: 1rem;
                    right: 1rem;
                    z-index: 100;
                }

                @media print {
                    @page {
                        size: A4 landscape;
                        margin: 0;
                    }
                    html, body {
                        width: 297mm;
                        height: 210mm;
                        margin: 0;
                        padding: 0;
                         -webkit-print-color-adjust: exact;
                        print-color-adjust: exact;
                    }
                    .no-print {
                        display: none;
                    }
                    .pitch-deck-container {
                         background-color: white !important;
                    }
                    .pitch-deck-slide {
                        width: 100%;
                        height: 100vh; /* vh is often better for print contexts */
                        page-break-after: always;
                        padding: 2rem;
                        border-bottom: none;
                        box-shadow: none;
                    }
                }
            `}</style>
             <div className="no-print p-4 bg-background border rounded-lg shadow-lg flex flex-col gap-2">
                <Button onClick={() => window.print()}>
                    <Download className="mr-2 h-4 w-4" /> Download as PDF
                </Button>
                <p className="text-xs text-muted-foreground max-w-xs text-center">Use the print dialog and select 'Save as PDF'.</p>
            </div>

            <div className="pitch-deck-container">

                {/* Slide 1 */}
                <section className="pitch-deck-slide text-center bg-primary text-primary-foreground">
                    <div className="m-auto">
                        <LadookLogo size="large" className="text-primary-foreground" />
                        <h1 className="text-6xl font-bold mt-6 tracking-tight">Ladook</h1>
                        <p className="text-2xl mt-4 opacity-90">The Intelligent Operating System for B2B Fashion.</p>
                    </div>
                    <div className="slide-footer">1</div>
                </section>

                {/* Slide 2 */}
                <section className="pitch-deck-slide">
                    <h2 className="text-5xl font-bold text-destructive mb-8">The Problem</h2>
                    <h3 className="text-3xl font-bold mb-6">The Global Fashion Supply Chain is Broken.</h3>
                    <p className="text-lg mb-6 max-w-4xl">It runs on a chaotic, fragmented system of middlemen, spreadsheets, and personal connections.</p>
                    <div className="grid md:grid-cols-2 gap-8 text-lg">
                        <div className="bg-red-50 p-6 rounded-lg">
                            <h4 className="font-bold text-red-800 mb-2">For Retailers (Boutiques):</h4>
                            <p>Sourcing unique products is a high-risk, time-consuming gamble. They fly to trade shows or navigate massive, untrustworthy directories, with no real way to vet quality or create exclusive lines efficiently.</p>
                        </div>
                        <div className="bg-red-50 p-6 rounded-lg">
                            <h4 className="font-bold text-red-800 mb-2">For Vendors (Factories):</h4>
                            <p>They are completely dependent on middlemen who take huge commissions and squeeze margins. They have no direct access to buyers and are treated as production lines, not creative partners.</p>
                        </div>
                    </div>
                     <p className="text-center text-xl font-semibold mt-10 max-w-4xl mx-auto">This is a multi-trillion dollar industry running on outdated, inefficient technology.</p>
                     <div className="slide-footer">2</div>
                </section>

                {/* Slide 3 */}
                <section className="pitch-deck-slide">
                    <h2 className="text-5xl font-bold mb-6">The Current "Solution" is Chaos</h2>
                    <h3 className="text-3xl mb-8 text-muted-foreground">A Disconnected Nightmare</h3>
                    <div className="text-center mb-8">
                       <Image src="https://picsum.photos/seed/slide3chaos/800/250" width={800} height={250} alt="A messy collage of spreadsheets, WhatsApp chats, and factory floors" className="rounded-lg shadow-lg mx-auto" data-ai-hint="chaos workflow" />
                    </div>
                    <p className="text-xl max-w-4xl mb-6">Today, a single B2B order is managed across a dozen different tools:</p>
                    <ul className="grid grid-cols-2 gap-x-8 gap-y-4 text-lg">
                        <li><strong>Discovery:</strong> Expensive trade shows & generic Alibaba listings.</li>
                        <li><strong>Operations:</strong> Manual order tracking on spreadsheets.</li>
                        <li><strong>Communication:</strong> Scattered WhatsApp messages & endless email threads.</li>
                        <li><strong>Payments:</strong> Complex international wire transfers and invoices.</li>
                    </ul>
                    <p className="text-xl font-semibold mt-8 text-destructive">This leads to costly errors, wasted time, and a complete lack of data-driven decision-making.</p>
                    <div className="slide-footer">3</div>
                </section>
                
                {/* Slide 4 */}
                 <section className="pitch-deck-slide">
                    <h2 className="text-5xl font-bold mb-6 text-primary">Our Solution: The All-in-One Platform</h2>
                     <h3 className="text-3xl mb-8 text-muted-foreground">Ladook replaces the chaos with a single, intelligent ecosystem.</h3>
                    <div className="text-center mb-8">
                        <Image src="https://picsum.photos/seed/slide4dashboard/800/400" width={800} height={400} alt="A clean, unified screenshot of the Ladook Dashboard" className="rounded-lg shadow-xl mx-auto" data-ai-hint="app dashboard"/>
                    </div>
                    <p className="text-center text-xl font-semibold mb-6">We are a <strong className="text-primary">SaaS-enabled B2B Marketplace</strong> that provides the software, network, and financial tools for fashion businesses to thrive.</p>
                    <ul className="grid grid-cols-2 gap-x-8 gap-y-4 text-lg mt-4">
                        <li><strong>Discover & Source:</strong> A curated marketplace to find vetted partners.</li>
                         <li><strong>Operate & Manage:</strong> A unified dashboard for orders and communication.</li>
                        <li><strong>Design & Create:</strong> AI-powered tools to accelerate creation.</li>
                        <li><strong>Finance & Grow:</strong> Integrated capital to fuel business growth.</li>
                    </ul>
                     <div className="slide-footer">4</div>
                </section>

                {/* Slide 5 */}
                <section className="pitch-deck-slide">
                    <h2 className="text-5xl font-bold mb-8">How It Works for Retailers</h2>
                    <h3 className="text-3xl mb-8 font-semibold text-primary">Buy Smarter, Not Harder.</h3>
                    <div className="grid md:grid-cols-2 gap-8 items-center">
                        <div>
                             <Image src="https://picsum.photos/seed/slide5retailer/600/400" width={600} height={400} alt="A retailer browsing the Trends Dashboard or Custom Request feed" className="rounded-lg shadow-lg" data-ai-hint="retailer dashboard" />
                        </div>
                        <ul className="space-y-6 text-xl">
                            <li><strong>Discover with AI:</strong> Our <strong className="text-primary">Market Trends Dashboard</strong> analyzes real-time sales data to show retailers what's selling right now, turning sourcing from a guess into a science.</li>
                            <li><strong>Create Exclusive Lines:</strong> Post a <strong className="text-primary">Custom Request</strong> and receive competitive bids directly from vetted manufacturers, making private label production simple and transparent.</li>
                            <li><strong>Streamlined Operations:</strong> Manage all vendor communications, orders, and payments in one unified and intuitive dashboard.</li>
                        </ul>
                    </div>
                    <div className="slide-footer">5</div>
                </section>
                
                 {/* Slide 6 */}
                <section className="pitch-deck-slide">
                    <h2 className="text-5xl font-bold mb-8">How It Works for Vendors</h2>
                    <h3 className="text-3xl mb-8 font-semibold text-primary">Regain Control, Unleash Creativity.</h3>
                     <div className="grid md:grid-cols-2 gap-8 items-center">
                        <ul className="space-y-6 text-xl">
                            <li><strong>Direct Global Access:</strong> Cut out the middlemen. Our platform provides a direct sales channel to a global network of professional buyers, increasing your profit margins.</li>
                            <li><strong>Become a Design Partner:</strong> Use our <strong className="text-primary">AI Design Studio</strong> to generate new product concepts and marketing materials in minutes. Proactively pitch your ideas instead of just waiting for orders.</li>
                            <li><strong>Effortless Management:</strong> A single dashboard to manage your entire business—from tracking orders to viewing analytics on your best-selling products.</li>
                        </ul>
                         <div>
                             <Image src="https://picsum.photos/seed/slide6vendor/600/400" width={600} height={400} alt="A vendor using the AI Design Studio to generate product concepts" className="rounded-lg shadow-lg" data-ai-hint="vendor design"/>
                        </div>
                    </div>
                    <div className="slide-footer">6</div>
                </section>

                {/* Slide 7 */}
                 <section className="pitch-deck-slide">
                    <h2 className="text-5xl font-bold mb-6">The Ladook Ecosystem</h2>
                    <h3 className="text-3xl mb-8 font-semibold text-primary">We're Not Just a Marketplace. We're an Ecosystem.</h3>
                     <div className="text-center my-8">
                        <Image src="https://picsum.photos/seed/slide7flywheel/800/300" width={800} height={300} alt="A flywheel diagram showing Marketplace -> SaaS -> FinTech" className="rounded-lg mx-auto" data-ai-hint="flywheel diagram"/>
                    </div>
                    <p className="text-xl max-w-4xl mx-auto mb-6 text-center">Our strength lies in the powerful synergy between our three core pillars:</p>
                    <div className="grid grid-cols-3 gap-6 text-lg text-center">
                        <div className="bg-gray-100 p-6 rounded-lg"><strong>1. Marketplace:</strong> The network where retailers and vendors connect.</div>
                        <div className="bg-gray-100 p-6 rounded-lg"><strong>2. SaaS Tools:</strong> AI-powered features like the Design Studio and Trends Dashboard.</div>
                        <div className="bg-gray-100 p-6 rounded-lg"><strong>3. FinTech:</strong> The integrated Microfinance Center solves the critical problem of working capital.</div>
                    </div>
                    <p className="text-xl font-semibold mt-8 text-center">More transactions fuel better AI insights, which drives more value, creating a powerful, self-reinforcing flywheel.</p>
                     <div className="slide-footer">7</div>
                </section>

                {/* Slide 8 */}
                 <section className="pitch-deck-slide">
                    <h2 className="text-5xl font-bold mb-6">Market Opportunity</h2>
                    <h3 className="text-3xl mb-8 font-semibold text-primary">A $1.7 Trillion Industry Begging for Disruption.</h3>
                    <div className="grid grid-cols-3 gap-6">
                        <div className="text-center p-6 bg-blue-50 rounded-lg">
                            <p className="text-lg font-semibold">Total Addressable Market (TAM)</p>
                            <p className="text-4xl font-bold text-blue-800 my-2">$1.7 Trillion</p>
                            <p className="text-sm">Global apparel market</p>
                        </div>
                        <div className="text-center p-6 bg-green-50 rounded-lg">
                            <p className="text-lg font-semibold">Serviceable Addressable Market (SAM)</p>
                            <p className="text-4xl font-bold text-green-800 my-2">$700 Billion</p>
                            <p className="text-sm">B2B segment (manufacturing & wholesale)</p>
                        </div>
                        <div className="text-center p-6 bg-purple-50 rounded-lg">
                            <p className="text-lg font-semibold">Serviceable Obtainable Market (SOM)</p>
                            <p className="text-4xl font-bold text-purple-800 my-2">$50 Billion</p>
                            <p className="text-sm">Ready-Made Garment exports from Bangladesh</p>
                        </div>
                    </div>
                     <p className="text-xl font-semibold mt-10 text-center">We are starting with a key, underserved artery of the global supply chain and expanding from there.</p>
                     <div className="slide-footer">8</div>
                </section>
                
                 {/* Slide 9 */}
                <section className="pitch-deck-slide">
                    <h2 className="text-5xl font-bold mb-6">Business Model</h2>
                    <h3 className="text-3xl mb-8 font-semibold text-primary">Simple, Scalable Revenue Streams.</h3>
                     <p className="text-xl mb-8 max-w-4xl">We have a multi-faceted approach to monetization that grows with our users.</p>
                     <div className="space-y-6">
                        <div className="p-6 border rounded-lg">
                            <h4 className="font-bold text-xl mb-2">1. Commission on Transactions (Marketplace)</h4>
                            <p className="text-lg text-muted-foreground">A small, competitive percentage (e.g., 3-5%) on all orders processed through the platform.</p>
                        </div>
                         <div className="p-6 border rounded-lg">
                            <h4 className="font-bold text-xl mb-2">2. SaaS Subscriptions (Premium Tools)</h4>
                            <p className="text-lg text-muted-foreground">A monthly fee for vendors and retailers to access advanced features like the AI Design Studio and in-depth analytics.</p>
                        </div>
                         <div className="p-6 border rounded-lg">
                            <h4 className="font-bold text-xl mb-2">3. Interest & Fees (FinTech)</h4>
                            <p className="text-lg text-muted-foreground">A percentage on loans facilitated through our Microfinance Center.</p>
                        </div>
                     </div>
                     <div className="slide-footer">9</div>
                </section>
                
                 {/* Slide 10 */}
                <section className="pitch-deck-slide">
                    <h2 className="text-5xl font-bold mb-6">Go-to-Market Strategy</h2>
                    <h3 className="text-3xl mb-8 font-semibold text-primary">Hyper-focus on a Single Trade Corridor.</h3>
                    <p className="text-xl mb-8 max-w-4xl">Our launch strategy is to dominate one critical trade route first: <strong>Bangladesh to the USA/EU.</strong></p>
                     <div className="grid md:grid-cols-3 gap-6 text-lg">
                        <div className="p-4 bg-gray-100 rounded-lg">
                            <h4 className="font-bold mb-2">1. Supply-Side First:</h4>
                            <p>Onboard an initial cohort of 50 high-quality, vetted garment factories in Bangladesh by offering our operational SaaS tools for free.</p>
                        </div>
                        <div className="p-4 bg-gray-100 rounded-lg">
                            <h4 className="font-bold mb-2">2. Targeted Demand Generation:</h4>
                            <p>Use digital marketing and strategic outreach to target independent boutique owners and private-label fashion brands in major US and European cities.</p>
                        </div>
                         <div className="p-4 bg-gray-100 rounded-lg">
                            <h4 className="font-bold mb-2">3. Build the Flywheel:</h4>
                            <p>By showcasing unique, direct-from-factory sourcing, we will drive retailer demand, which attracts more vendors organically.</p>
                        </div>
                    </div>
                     <div className="slide-footer">10</div>
                </section>

                {/* Slide 11 */}
                <section className="pitch-deck-slide">
                    <h2 className="text-5xl font-bold mb-8">The Team</h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                        <div>
                            <Image src="https://picsum.photos/seed/team1/200/200" width={200} height={200} alt="Team member 1" className="rounded-full mx-auto shadow-lg" data-ai-hint="person ceo"/>
                            <h4 className="text-2xl font-bold mt-4">[Your Name], CEO</h4>
                            <p className="text-muted-foreground mt-2">10+ years in tech, direct experience with supply chain challenges through family ties to the garment industry. Vision and product.</p>
                        </div>
                         <div>
                            <Image src="https://picsum.photos/seed/team2/200/200" width={200} height={200} alt="Team member 2" className="rounded-full mx-auto shadow-lg" data-ai-hint="person cto"/>
                            <h4 className="text-2xl font-bold mt-4">[Co-founder Name], CTO</h4>
                            <p className="text-muted-foreground mt-2">Ex-Shopify/Amazon engineer. Expert in building scalable marketplace and fintech platforms.</p>
                        </div>
                         <div>
                            <Image src="https://picsum.photos/seed/team3/200/200" width={200} height={200} alt="Team member 3" className="rounded-full mx-auto shadow-lg" data-ai-hint="person operations"/>
                            <h4 className="text-2xl font-bold mt-4">[Co-founder Name], Head of Ops</h4>
                            <p className="text-muted-foreground mt-2">15+ years on the ground in Dhaka's RMG sector. Deep network of factory owners and understanding of local logistics.</p>
                        </div>
                    </div>
                     <div className="slide-footer">11</div>
                </section>

                 {/* Slide 12 */}
                <section className="pitch-deck-slide">
                    <h2 className="text-5xl font-bold mb-8">The Ask & Vision</h2>
                     <div className="grid md:grid-cols-2 gap-8">
                        <div className="bg-green-50 p-8 rounded-lg">
                            <h3 className="text-3xl font-bold text-green-800 mb-4">The Ask:</h3>
                            <p className="text-2xl mb-4">We are raising a <strong className="text-4xl">$500,000</strong> pre-seed round to achieve the following in the next 12 months:</p>
                             <ul className="space-y-2 text-lg list-disc pl-5">
                                <li>Onboard our first 100 vetted vendors in Bangladesh.</li>
                                <li>Acquire our first 500 active retailers in the US and EU.</li>
                                <li>Facilitate our first $1M in Gross Merchandise Volume (GMV).</li>
                                <li>Launch the beta version of our Microfinance Center.</li>
                            </ul>
                        </div>
                         <div className="bg-blue-50 p-8 rounded-lg">
                            <h3 className="text-3xl font-bold text-blue-800 mb-4">Our Vision:</h3>
                            <p className="text-3xl leading-relaxed">To become the definitive, intelligent, and equitable operating system for the entire global fashion supply chain.</p>
                        </div>
                    </div>
                     <div className="slide-footer">12</div>
                </section>

                {/* Slide 13 */}
                <section className="pitch-deck-slide text-center">
                    <div className="m-auto">
                        <LadookLogo size="large" />
                        <h2 className="text-5xl font-bold mt-8 mb-6">Thank You.</h2>
                        <p className="text-2xl">[Your Name]</p>
                        <p className="text-2xl text-primary hover:underline">[Your Email]</p>
                        <p className="text-2xl text-muted-foreground mt-4">ladook.com</p>
                    </div>
                    <div className="slide-footer">13</div>
                </section>
            </div>
        </>
    );
}
