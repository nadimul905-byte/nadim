// src/app/onboarding/page.tsx
"use client";

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ArrowRight } from 'lucide-react';
import Image from 'next/image';
import LadookLogo from '@/components/LadookLogo';

const slides = [
  {
    image: "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw0fHxmYXNoaW9uJTIwcmV0YWlsfGVufDB8fHx8MTc1MjUyMjYwNHww&ixlib=rb-4.1.0&q=80&w=1080",
    aiHint: "fashion retail",
    title: "Welcome to Ladook!",
    description: "Discover unique fashion. Connect directly with vendors and designers."
  },
  {
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw0fHxwcm9kdWN0fGVufDB8fHx8MTc1MjUyMjYwNHww&ixlib=rb-4.1.0&q=80&w=1080",
    aiHint: "products display",
    title: "For Vendors",
    description: "Showcase your products, manage orders, and grow your business."
  },
  {
    image: "https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw5fHxyZXRhaWxlciUyMHNob3BwaW5nfGVufDB8fHx8MTc1MjYxMTgwMHww&ixlib=rb-4.1.0&q=80&w=1080",
    aiHint: "retailer shopping",
    title: "For Retailers",
    description: "Source unique products, request custom designs, and manage your inventory."
  }
];

export default function OnboardingPage() {
  const router = useRouter();
  const [currentSlide, setCurrentSlide] = useState(0);

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      router.push('/auth');
    }
  };

  const handlePrev = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gradient-to-br from-background to-secondary/70">
      <Card className="w-full max-w-md shadow-2xl overflow-hidden">
         <CardHeader className="p-0">
            <div className="relative w-full h-64">
                 <Image 
                    src={slides[currentSlide].image} 
                    alt={slides[currentSlide].title} 
                    layout="fill" 
                    objectFit="cover"
                    className="transition-opacity duration-500"
                    data-ai-hint={slides[currentSlide].aiHint} 
                />
            </div>
        </CardHeader>
        <CardContent className="flex flex-col items-center text-center p-6">
            <LadookLogo className="mb-2"/>
            <CardTitle className="text-2xl font-headline text-primary">{slides[currentSlide].title}</CardTitle>
            <CardDescription className="text-md mt-1 h-10">{slides[currentSlide].description}</CardDescription>
            
            <div className="flex gap-2 mt-4">
                {slides.map((_, index) => (
                    <div key={index} className={`h-2 w-2 rounded-full ${index === currentSlide ? 'bg-primary' : 'bg-muted'}`} />
                ))}
            </div>

            <div className="w-full mt-6 grid grid-cols-2 gap-3">
              <Button variant="outline" onClick={handlePrev} disabled={currentSlide === 0}>
                Previous
              </Button>
              <Button onClick={handleNext}>
                {currentSlide === slides.length - 1 ? 'Get Started' : 'Next'} <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
        </CardContent>
      </Card>
    </div>
  );
}
