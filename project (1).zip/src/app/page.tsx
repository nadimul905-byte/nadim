"use client";

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import LadookLogo from '@/components/LadookLogo';

export default function SplashScreen() {
  const router = useRouter();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(true); // Trigger fade-in
    const timer = setTimeout(() => {
      setVisible(false); // Trigger fade-out
      setTimeout(() => {
        router.push('/onboarding');
      }, 500); // Wait for fade-out animation
    }, 2500); // Display splash for 2.5 seconds (2000ms display + 500ms fadeout)

    return () => clearTimeout(timer);
  }, [router]);

  return (
    <div className={`flex items-center justify-center min-h-screen bg-primary transition-opacity duration-500 ${visible ? 'opacity-100' : 'opacity-0'}`}>
      <LadookLogo size="large" className="text-primary-foreground animate-pulse" />
    </div>
  );
}
