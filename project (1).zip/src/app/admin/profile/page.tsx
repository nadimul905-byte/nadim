"use client";
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { User, Mail, Shield, Users, FileArchive, BarChart3, Settings, ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

const ProfileItem = ({ icon: Icon, label, value, href }: { icon: React.ElementType, label: string, value?: string | React.ReactNode, href?: string }) => (
  <div className="flex items-center justify-between py-3 border-b last:border-b-0">
    <div className="flex items-center">
      <Icon className="h-5 w-5 text-muted-foreground mr-3" />
      <div>
        <p className="text-sm font-medium">{label}</p>
        {value && typeof value === 'string' ? <p className="text-xs text-muted-foreground">{value}</p> : value}
      </div>
    </div>
    {href && <Button variant="ghost" size="sm" asChild><Link href={href}>View</Link></Button>}
  </div>
);

const QuickLinkCard = ({ title, description, icon: Icon, link }: { title: string, description: string, icon: React.ElementType, link: string }) => (
    <Card className="hover:shadow-lg transition-shadow">
        <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-2">
            <Avatar className="h-10 w-10 rounded-sm bg-primary/10 text-primary">
                <AvatarFallback><Icon className="h-5 w-5"/></AvatarFallback>
            </Avatar>
            <CardTitle className="text-lg font-semibold">{title}</CardTitle>
        </CardHeader>
        <CardContent>
            <p className="text-xs text-muted-foreground mb-3">{description}</p>
            <Button variant="outline" size="sm" asChild className="w-full">
                <Link href={link}>Go to {title}</Link>
            </Button>
        </CardContent>
    </Card>
);


export default function AdminProfilePage() {
  const router = useRouter();
  const [adminName, setAdminName] = useState("Admin User");
  const [adminEmail, setAdminEmail] = useState<string | null>("admin@ladook.com");

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const storedEmail = localStorage.getItem('userEmail');
      if (storedEmail) {
        setAdminEmail(storedEmail);
        setAdminName(storedEmail.split('@')[0] || "Admin"); 
      }
    }
  }, []);

  return (
    <div className="space-y-6">
       <div className="flex items-center justify-between">
            <h1 className="text-3xl font-headline font-semibold">My Admin Profile</h1>
            <Button variant="outline" onClick={() => router.push('/admin')}>
                <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
            </Button>
        </div>

      <Card className="overflow-hidden">
        <CardHeader className="bg-muted/30 p-6 flex flex-col items-center text-center">
           <Avatar className="w-24 h-24 mb-3 border-4 border-background shadow-md">
            <AvatarImage src="https://placehold.co/150x150.png?text=A" alt={adminName} data-ai-hint="admin user"/>
            <AvatarFallback className="text-3xl">{adminName?.charAt(0)?.toUpperCase() || 'A'}</AvatarFallback>
          </Avatar>
          <CardTitle className="text-2xl font-headline">{adminName}</CardTitle>
          <CardDescription>{adminEmail || 'loading...'}</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <ProfileItem icon={Mail} label="Email" value={adminEmail || 'N/A'} />
          <ProfileItem icon={Shield} label="Role" value="Administrator" />
          <ProfileItem icon={User} label="Username" value={adminName.toLowerCase().replace(/\s+/g, '')} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
            <CardTitle>Quick Access</CardTitle>
            <CardDescription>Jump to key administrative areas.</CardDescription>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-4">
            <QuickLinkCard title="User Management" description="Manage all platform users." icon={Users} link="/admin/users" />
            <QuickLinkCard title="Content Moderation" description="Oversee products, reviews, and media." icon={FileArchive} link="/admin/content" />
            <QuickLinkCard title="Platform Reports" description="View analytics and platform data." icon={BarChart3} link="/admin/reports" />
            <QuickLinkCard title="System Settings" description="Configure platform-wide settings." icon={Settings} link="/admin/settings" />
        </CardContent>
      </Card>
    </div>
  );
}
