
"use client";
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Save, Settings, ToggleLeft, Users, FileArchive, BarChart3, ShieldAlert, Zap } from 'lucide-react';
import Link from 'next/link';
import { useToast } from '@/hooks/use-toast';

const SettingItem = ({ title, description, children }: { title: string, description?: string, children: React.ReactNode }) => (
  <div className="flex flex-col sm:flex-row justify-between sm:items-center p-4 border-b last:border-b-0">
    <div className="mb-2 sm:mb-0">
      <h4 className="font-medium">{title}</h4>
      {description && <p className="text-xs text-muted-foreground">{description}</p>}
    </div>
    <div className="flex-shrink-0">{children}</div>
  </div>
);

export default function AdminPlatformSettingsPage() {
  const { toast } = useToast();
  // Mock states for settings
  const [platformName, setPlatformName] = useState("Ladook Mobile");
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [aiRecommendations, setAiRecommendations] = useState(true);
  const [customDesignsEnabled, setCustomDesignsEnabled] = useState(true);
  const [realTimeMessaging, setRealTimeMessaging] = useState(true);
  const [vendorAnalytics, setVendorAnalytics] = useState(true);
  const [maxImageUploadSize, setMaxImageUploadSize] = useState(5); // MB

  const handleSaveChanges = () => {
    toast({
      title: "Settings Saved",
      description: "Platform settings have been updated (mocked).",
    });
    console.log({ platformName, maintenanceMode, aiRecommendations, customDesignsEnabled, realTimeMessaging, vendorAnalytics, maxImageUploadSize });
  };

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-headline font-semibold flex items-center"><Settings className="mr-3 h-8 w-8 text-primary" /> Platform Settings</h1>

      <Card>
        <CardHeader>
          <CardTitle>General Configuration</CardTitle>
          <CardDescription>Basic settings for the platform.</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <SettingItem title="Platform Name">
            <Input className="w-full sm:w-64" value={platformName} onChange={(e) => setPlatformName(e.target.value)} />
          </SettingItem>
          <SettingItem title="Maintenance Mode" description="Temporarily disable access for users except admins.">
            <Switch checked={maintenanceMode} onCheckedChange={setMaintenanceMode} id="maintenance-mode" />
          </SettingItem>
          <SettingItem title="Max Image Upload Size (MB)" description="Set the maximum file size for image uploads.">
             <Input type="number" className="w-24" value={maxImageUploadSize} onChange={(e) => setMaxImageUploadSize(Number(e.target.value))} min="1" />
          </SettingItem>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Feature Management</CardTitle>
          <CardDescription>Enable or disable core platform features.</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <SettingItem title="AI-Driven Recommendations" description="Enable AI product recommendations for retailers.">
            <Switch checked={aiRecommendations} onCheckedChange={setAiRecommendations} id="ai-recommendations" />
          </SettingItem>
          <SettingItem title="Custom Design Requests" description="Allow retailers to post custom requests and vendors to bid.">
            <Switch checked={customDesignsEnabled} onCheckedChange={setCustomDesignsEnabled} id="custom-designs" />
          </SettingItem>
          <SettingItem title="Real-Time Messaging" description="Enable direct chat between retailers and vendors.">
            <Switch checked={realTimeMessaging} onCheckedChange={setRealTimeMessaging} id="realtime-messaging" />
          </SettingItem>
          <SettingItem title="Vendor Analytics Dashboard" description="Provide vendors with their sales and performance analytics.">
            <Switch checked={vendorAnalytics} onCheckedChange={setVendorAnalytics} id="vendor-analytics" />
          </SettingItem>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Quick Access to Management Panels</CardTitle>
          <CardDescription>Jump to specific admin sections.</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <Button variant="outline" asChild className="p-6 justify-start text-left h-auto">
                <Link href="/admin/users">
                    <Users className="mr-3 h-5 w-5 text-primary" />
                    <div>
                        <p className="font-semibold">User Management</p>
                        <p className="text-xs text-muted-foreground">Manage retailers, vendors, and admins.</p>
                    </div>
                </Link>
            </Button>
            <Button variant="outline" asChild className="p-6 justify-start text-left h-auto">
                <Link href="/admin/content">
                    <FileArchive className="mr-3 h-5 w-5 text-primary" />
                     <div>
                        <p className="font-semibold">Content Moderation</p>
                        <p className="text-xs text-muted-foreground">Review products and other content.</p>
                    </div>
                </Link>
            </Button>
             <Button variant="outline" asChild className="p-6 justify-start text-left h-auto">
                <Link href="/admin/disputes">
                    <ShieldAlert className="mr-3 h-5 w-5 text-primary" />
                     <div>
                        <p className="font-semibold">Dispute Resolution</p>
                        <p className="text-xs text-muted-foreground">Oversee and resolve disputes.</p>
                    </div>
                </Link>
            </Button>
            <Button variant="outline" asChild className="p-6 justify-start text-left h-auto">
                <Link href="/admin/reports">
                    <BarChart3 className="mr-3 h-5 w-5 text-primary" />
                    <div>
                        <p className="font-semibold">Platform Reports</p>
                        <p className="text-xs text-muted-foreground">View platform usage and financial data.</p>
                    </div>
                </Link>
            </Button>
            <Button variant="outline" asChild className="p-6 justify-start text-left h-auto">
                <Link href="/admin/integrations">
                    <Zap className="mr-3 h-5 w-5 text-primary" />
                    <div>
                        <p className="font-semibold">Integrations</p>
                        <p className="text-xs text-muted-foreground">Manage third-party service integrations.</p>
                    </div>
                </Link>
            </Button>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button size="lg" onClick={handleSaveChanges}>
          <Save className="mr-2 h-5 w-5" /> Save All Settings
        </Button>
      </div>
    </div>
  );
}
