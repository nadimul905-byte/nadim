
"use client";

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Search, Filter, Eye, Landmark } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';


type LoanStatus = 'Pending Review' | 'Approved' | 'Rejected' | 'Under Review';

export interface LoanApplication {
  id: string;
  applicantName: string;
  applicantType: 'Retailer' | 'Vendor';
  applicantId: string;
  amount: number;
  purpose: string;
  term: number; // in months
  dateApplied: string;
  status: LoanStatus;
  businessInfo: {
      name: string;
      type: string;
      yearsInBusiness: number;
      annualRevenue: number;
  };
  creditScoreRange: string;
}

const initialLoanApplications: LoanApplication[] = [
  { id: 'L101', applicantName: 'Fashion Forward', applicantType: 'Retailer', applicantId: 'ret001', amount: 20000, purpose: 'Inventory for new season', term: 12, dateApplied: '2024-07-30', status: 'Pending Review', businessInfo: { name: "Fashion Forward", type: 'LLC', yearsInBusiness: 3, annualRevenue: 250000 }, creditScoreRange: 'Good (700-749)' },
  { id: 'L102', applicantName: 'Chic Designs Co.', applicantType: 'Vendor', applicantId: 'vendor001', amount: 50000, purpose: 'Purchase new sewing machines', term: 24, dateApplied: '2024-07-29', status: 'Under Review', businessInfo: { name: "Chic Designs Co.", type: 'LLC', yearsInBusiness: 5, annualRevenue: 500000 }, creditScoreRange: 'Excellent (750+)' },
  { id: 'L103', applicantName: 'Style Hub', applicantType: 'Retailer', applicantId: 'ret002', amount: 5000, purpose: 'Marketing campaign for summer sale', term: 6, dateApplied: '2024-07-28', status: 'Approved', businessInfo: { name: "Style Hub", type: 'Sole Proprietorship', yearsInBusiness: 1, annualRevenue: 80000 }, creditScoreRange: 'Fair (650-699)' },
  { id: 'L104', applicantName: 'Artisan Textiles', applicantType: 'Vendor', applicantId: 'vendor003', amount: 15000, purpose: 'Raw material bulk purchase', term: 12, dateApplied: '2024-07-27', status: 'Rejected', businessInfo: { name: "Artisan Textiles", type: 'Partnership', yearsInBusiness: 8, annualRevenue: 350000 }, creditScoreRange: 'Excellent (750+)' },
  { id: 'L105', applicantName: 'The Trendsetter', applicantType: 'Retailer', applicantId: 'ret003', amount: 10000, purpose: 'Store renovation and visual merchandising update', term: 18, dateApplied: '2024-07-26', status: 'Pending Review', businessInfo: { name: "The Trendsetter", type: 'LLC', yearsInBusiness: 2, annualRevenue: 120000 }, creditScoreRange: 'Good (700-749)' },
];

export const getLoanApplicationById = (id: string): LoanApplication | undefined => initialLoanApplications.find(d => d.id === id);


const StatusBadge = ({ status }: { status: LoanStatus }) => {
  let variant: "default" | "secondary" | "destructive" | "outline" = "secondary";
  if (status === 'Approved') variant = 'default';
  else if (status === 'Rejected') variant = 'destructive';
  
  return <Badge variant={variant} className={`text-xs px-1.5 py-0.5 ${status === 'Approved' ? 'bg-green-500/20 text-green-700' : ''}`}>{status}</Badge>;
};


export default function AdminFinancePage() {
  const router = useRouter();
  const [applications, setApplications] = useState<LoanApplication[]>(initialLoanApplications);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<LoanStatus | "All">("All");

  const filteredApplications = applications.filter(app => {
    const matchesSearch = 
      app.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.applicantName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.purpose.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "All" || app.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const loanStatuses: (LoanStatus | "All")[] = ["All", "Pending Review", "Under Review", "Approved", "Rejected"];

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-headline font-semibold flex items-center gap-2"><Landmark/>Finance Center</h1>
      </div>

      <Card>
        <CardHeader className="p-3">
          <CardTitle className="text-lg">Loan Applications</CardTitle>
          <CardDescription className="text-xs">Review and manage loan applications from platform users.</CardDescription>
          <div className="pt-2 flex flex-col sm:flex-row gap-2">
            <div className="relative flex-grow">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input 
                placeholder="Search by ID, applicant, purpose..." 
                className="pl-8 h-8 text-xs" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={filterStatus} onValueChange={(value) => setFilterStatus(value as LoanStatus | "All")}>
              <SelectTrigger className="w-full sm:w-auto min-w-[150px] h-8 text-xs">
                <SelectValue placeholder="Filter by Status" />
              </SelectTrigger>
              <SelectContent>
                {loanStatuses.map(stat => <SelectItem key={stat} value={stat} className="text-xs">{stat}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="p-2 text-xs">App ID</TableHead>
                <TableHead className="p-2 text-xs">Applicant</TableHead>
                <TableHead className="p-2 text-xs">Amount</TableHead>
                <TableHead className="p-2 text-xs">Purpose</TableHead>
                <TableHead className="p-2 text-xs">Date Applied</TableHead>
                <TableHead className="p-2 text-xs text-center">Status</TableHead>
                <TableHead className="p-2 text-xs text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredApplications.length > 0 ? filteredApplications.map((app) => (
                <TableRow key={app.id}>
                  <TableCell className="p-2 text-xs font-medium">{app.id}</TableCell>
                  <TableCell className="p-2 text-xs">
                     <p className="font-medium">{app.applicantName}</p>
                    <p className="text-xs text-muted-foreground">{app.applicantType}</p>
                  </TableCell>
                  <TableCell className="p-2 text-xs font-semibold">${app.amount.toLocaleString()}</TableCell>
                  <TableCell className="p-2 text-xs max-w-[150px] truncate" title={app.purpose}>{app.purpose}</TableCell>
                  <TableCell className="p-2 text-xs">{app.dateApplied}</TableCell>
                  <TableCell className="p-2 text-xs text-center">
                    <StatusBadge status={app.status} />
                  </TableCell>
                  <TableCell className="p-2 text-xs text-right">
                    <Button variant="outline" size="xs" asChild>
                      <Link href={`/admin/finance/${app.id}`}>
                        <Eye className="mr-1 h-3 w-3" /> Review
                      </Link>
                    </Button>
                  </TableCell>
                </TableRow>
              )) : (
                 <TableRow>
                    <TableCell colSpan={7} className="text-center py-6 text-xs text-muted-foreground">
                        {searchTerm || filterStatus !== "All" ? "No applications match criteria." : "No loan applications found."}
                    </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
         <CardFooter className="border-t p-2">
            <p className="text-xs text-muted-foreground">
                Found {filteredApplications.length} application(s).
            </p>
        </CardFooter>
      </Card>
    </div>
  );
}

