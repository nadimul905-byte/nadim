"use client";

import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Briefcase, Calendar, DollarSign, Landmark, Loader2, PieChart, ShieldCheck, User } from 'lucide-react';
import Link from 'next/link';
import { useToast } from '@/hooks/use-toast';
import { getLoanApplicationById, type LoanApplication } from '../page';
import { Separator } from '@/components/ui/separator';

type LoanStatus = 'Pending Review' | 'Approved' | 'Rejected' | 'Under Review';

const StatusBadgeComponent = ({ status }: { status: LoanStatus }) => {
  let variant: "default" | "secondary" | "destructive" | "outline" = "secondary";
  if (status === "Pending Review") { variant = "secondary"; }
  else if (status === "Under Review") { variant = "secondary"; }
  else if (status === 'Approved') { variant = 'default'; }
  else if (status === 'Rejected') { variant = 'destructive'; }
  return <Badge variant={variant} className={`text-xs px-2 py-1 ${status === 'Approved' ? 'bg-green-500/20 text-green-700 border-green-500/30' : ''}`}>{status}</Badge>;
};

export default function AdminFinanceApplicationDetailPage() {
  const router = useRouter();
  const params = useParams();
  const applicationId = params.applicationId as string;
  const { toast } = useToast();

  const [application, setApplication] = useState<LoanApplication | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [newStatus, setNewStatus] = useState<LoanStatus | ''>('');
  const [isUpdating, setIsUpdating] = useState(false);

  useEffect(() => {
    if (applicationId) {
      const foundApp = getLoanApplicationById(applicationId);
      if (foundApp) {
        setApplication(foundApp);
        setNewStatus(foundApp.status);
      } else {
        toast({ title: "Application Not Found", variant: "destructive" });
        router.push('/admin/finance');
      }
    }
    setIsLoading(false);
  }, [applicationId, router, toast]);

  const handleStatusChange = () => {
    if (!newStatus || !application || newStatus === application.status) return;
    setIsUpdating(true);
    setTimeout(() => {
      const updatedApp = { ...application, status: newStatus as LoanStatus };
      setApplication(updatedApp);
      toast({ title: "Status Updated", description: `Application #${application.id} status changed to ${newStatus}.` });
      setIsUpdating(false);
    }, 1000);
  };
  
  if (isLoading) {
    return <div className="flex justify-center items-center min-h-screen"><Loader2 className="h-8 w-8 animate-spin text-primary" /> Loading application...</div>;
  }

  if (!application) {
    return <div className="text-center py-10"><p>Application not found.</p></div>;
  }
  
  const availableStatuses: LoanStatus[] = ["Pending Review", "Under Review", "Approved", "Rejected"];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="outline" size="sm" onClick={() => router.push('/admin/finance')}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Applications
        </Button>
      </div>
      
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
            <CardTitle className="text-2xl font-headline">Loan Application #{application.id}</CardTitle>
            <StatusBadgeComponent status={application.status} />
          </div>
          <CardDescription>Applied on: {application.dateApplied}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
                <Card>
                    <CardHeader><CardTitle className="text-lg flex items-center gap-2"><User/>Applicant Information</CardTitle></CardHeader>
                    <CardContent className="space-y-2">
                        <p><strong>Name:</strong> {application.applicantName}</p>
                        <p><strong>Type:</strong> {application.applicantType}</p>
                        <p><strong>Self-Reported Credit:</strong> {application.creditScoreRange}</p>
                         <Button variant="link" asChild className="p-0 h-auto"><Link href={`/admin/users/${application.applicantType.toLowerCase()}s/${application.applicantId}`}>View Profile</Link></Button>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader><CardTitle className="text-lg flex items-center gap-2"><Briefcase/>Business Information</CardTitle></CardHeader>
                    <CardContent className="space-y-2">
                        <p><strong>Business Name:</strong> {application.businessInfo.name}</p>
                        <p><strong>Business Type:</strong> {application.businessInfo.type}</p>
                        <p><strong>Years in Business:</strong> {application.businessInfo.yearsInBusiness}</p>
                        <p><strong>Annual Revenue:</strong> ${application.businessInfo.annualRevenue.toLocaleString()}</p>
                    </CardContent>
                </Card>
            </div>
             <Separator/>
            <div>
                <h3 className="font-semibold text-lg mb-2">Loan Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                     <p className="flex items-center"><DollarSign className="inline mr-2 h-4 w-4 text-muted-foreground"/><strong>Amount Requested:</strong> ${application.amount.toLocaleString()}</p>
                     <p className="flex items-center"><Calendar className="inline mr-2 h-4 w-4 text-muted-foreground"/><strong>Repayment Term:</strong> {application.term} months</p>
                </div>
                 <div className="mt-4">
                    <h4 className="font-semibold mb-1">Purpose of Loan:</h4>
                    <p className="text-muted-foreground text-sm whitespace-pre-wrap">{application.purpose}</p>
                 </div>
            </div>
        </CardContent>
      </Card>

       <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><ShieldCheck className="mr-2 h-5 w-5 text-primary" /> Admin Actions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
            <div>
                <Label htmlFor="statusSelect">Change Application Status:</Label>
                <div className="flex items-center gap-2 mt-1">
                    <Select value={newStatus} onValueChange={(value) => setNewStatus(value as LoanStatus)}>
                        <SelectTrigger id="statusSelect" className="flex-grow">
                        <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent>
                        {availableStatuses.map(s => <SelectItem key={s} value={s} disabled={s === application.status}>{s}</SelectItem>)}
                        </SelectContent>
                    </Select>
                    <Button onClick={handleStatusChange} disabled={isUpdating || newStatus === application.status || !newStatus}>
                        {isUpdating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ShieldCheck className="mr-2 h-4 w-4" />}
                        Update Status
                    </Button>
                </div>
            </div>
            <div>
                 <Label htmlFor="adminNotes">Internal Notes:</Label>
                 <Textarea id="adminNotes" placeholder="Add internal notes about this application..." rows={3} className="mt-1"/>
                 <Button size="sm" variant="outline" className="mt-2">Save Note</Button>
            </div>
        </CardContent>
      </Card>
    </div>
  );
}
