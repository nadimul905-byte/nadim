
"use client";

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileArchive, MessageSquareText, ImagePlay, ArrowRight, Files, Users } from 'lucide-react';
import Link from 'next/link';
import { Badge } from "@/components/ui/badge";

interface ContentSectionCardProps {
  title: string;
  description: string;
  link: string;
  icon: React.ElementType;
  count?: number;
  countLabel?: string;
}

const ContentSectionCard: React.FC<ContentSectionCardProps> = ({ title, description, link, icon: Icon, count, countLabel }) => (
  <Card className="hover:shadow-lg transition-shadow">
    <CardHeader className="pb-4">
      <div className="flex items-center justify-between">
        <CardTitle className="text-xl font-semibold flex items-center">
          <Icon className="mr-3 h-6 w-6 text-primary" />
          {title}
        </CardTitle>
        {count !== undefined && countLabel && (
          <Badge variant="secondary" className="text-sm px-3 py-1">{count} {countLabel}</Badge>
        )}
      </div>
    </CardHeader>
    <CardContent>
      <p className="text-sm text-muted-foreground mb-4 min-h-[40px]">{description}</p>
      <Button asChild variant="outline" className="w-full">
        <Link href={link}>
          Manage {title} <ArrowRight className="ml-2 h-4 w-4" />
        </Link>
      </Button>
    </CardContent>
  </Card>
);

export default function AdminContentManagementPage() {
  // These counts would ideally come from a backend/database
  const pendingProductsCount = 5; // Example count
  const pendingReviewsCount = 12; // Example count
  const pendingMediaCount = 3; // Example count
  const pendingSocialPosts = 8; // Example count for new card

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-headline font-semibold flex items-center">
          <Files className="mr-3 h-8 w-8 text-primary" /> Content Management
        </h1>
      </div>

      <Card>
        <CardHeader>
            <CardTitle>Overview</CardTitle>
            <CardDescription>Oversee and moderate various types of content generated on the platform to maintain quality and adherence to guidelines.</CardDescription>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ContentSectionCard
                title="Product Moderation"
                description="Review and approve/reject new product submissions and edits to existing products."
                link="/admin/content/products/moderation"
                icon={FileArchive}
                count={pendingProductsCount}
                countLabel="Pending"
            />
            <ContentSectionCard
                title="Review Management"
                description="Moderate customer reviews on products and vendors for authenticity and appropriateness."
                link="/admin/content/reviews" 
                icon={MessageSquareText}
                count={pendingReviewsCount}
                countLabel="To Review"
            />
            <ContentSectionCard
                title="User Media Moderation"
                description="Review user-uploaded images and videos (e.g., in custom requests, vendor profiles)."
                link="/admin/content/media"
                icon={ImagePlay}
                count={pendingMediaCount}
                countLabel="Flagged"
            />
             <ContentSectionCard
                title="Community Feed"
                description="Moderate posts and reels from the community social feed to ensure they meet guidelines."
                link="/admin/social"
                icon={Users}
                count={pendingSocialPosts}
                countLabel="Pending"
            />
        </CardContent>
      </Card>

       <Card>
        <CardHeader>
            <CardTitle>Content Guidelines & Policies</CardTitle>
            <CardDescription>Access and manage the platform's content policies and community guidelines.</CardDescription>
        </CardHeader>
        <CardContent>
            <Button variant="outline" asChild>
                <Link href="/admin/content/policies">
                    View & Edit Policies
                </Link>
            </Button>
        </CardContent>
      </Card>
    </div>
  );
}
