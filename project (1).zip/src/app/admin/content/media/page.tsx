
"use client";

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CheckCircle, XCircle, ImagePlay, Search, Filter, ArrowLeft, UserCircle, CalendarDays, FileText } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';
import { Badge } from '@/components/ui/badge';

type MediaStatus = "Pending Review" | "Approved" | "Rejected" | "Flagged";
type MediaType = "Product Image" | "Custom Request Attachment" | "Vendor Profile Picture" | "Review Image";

interface MediaForModeration {
  id: string;
  uploaderName: string;
  mediaType: MediaType;
  contextLink: string; // Link to the product, request, or profile page
  contextName: string; // Name of product, request, or profile
  dateUploaded: string;
  status: MediaStatus;
  mediaUrl: string;
  aiHint?: string;
  reasonForFlag?: string;
}

const initialMediaForModeration: MediaForModeration[] = [
  { id: 'media001', uploaderName: 'Glitter Glam (Vendor)', mediaType: 'Product Image', contextLink: '/admin/products/modProd001', contextName: 'Super Shiny Top', dateUploaded: '2024-07-29', status: 'Pending Review', mediaUrl: 'https://placehold.co/150x150.png', aiHint: 'shiny top', reasonForFlag: 'Image quality seems low.' },
  { id: 'media002', uploaderName: 'Retailer X', mediaType: 'Custom Request Attachment', contextLink: '/admin/requests/REQ123', contextName: 'Bohemian Wedding Dress', dateUploaded: '2024-07-28', status: 'Pending Review', mediaUrl: 'https://placehold.co/150x150.png', aiHint: 'dress sketch' },
  { id: 'media003', uploaderName: 'Tough Threads (Vendor)', mediaType: 'Vendor Profile Picture', contextLink: '/admin/users/vendors/tough-threads', contextName: 'Tough Threads Profile', dateUploaded: '2024-07-27', status: 'Flagged', mediaUrl: 'https://placehold.co/150x150.png', aiHint: 'brand logo', reasonForFlag: 'Potentially inappropriate logo.' },
  { id: 'media004', uploaderName: 'Happy Shopper', mediaType: 'Review Image', contextLink: '/admin/content/reviews/rev006', contextName: 'Review for Leather Handbag', dateUploaded: '2024-07-26', status: 'Pending Review', mediaUrl: 'https://placehold.co/150x150.png', aiHint: 'damaged handbag' },
  { id: 'media005', uploaderName: 'Chic Designs Co.', mediaType: 'Product Image', contextLink: '/admin/products/modProd002', contextName: 'Elegant Summer Dress', dateUploaded: '2024-07-25', status: 'Approved', mediaUrl: 'https://placehold.co/150x150.png', aiHint: 'summer dress' },
  { id: 'media006', uploaderName: 'Retailer B', mediaType: 'Custom Request Attachment', contextLink: '/admin/requests/REQ124', contextName: 'Kids Play Tent Design', dateUploaded: '2024-07-24', status: 'Pending Review', mediaUrl: 'https://placehold.co/150x150.png', aiHint: 'play tent' },
  { id: 'media007', uploaderName: 'Urban Wears (Vendor)', mediaType: 'Vendor Profile Picture', contextLink: '/admin/users/vendors/urban-wears', contextName: 'Urban Wears HQ', dateUploaded: '2024-07-23', status: 'Pending Review', mediaUrl: 'https://placehold.co/150x150.png', aiHint: 'store front' },
  { id: 'media008', uploaderName: 'John Doe (Retailer)', mediaType: 'Review Image', contextLink: '/admin/content/reviews/rev007', contextName: 'Review for Running Shoes', dateUploaded: '2024-07-22', status: 'Rejected', mediaUrl: 'https://placehold.co/150x150.png', aiHint: 'worn shoes', reasonForFlag: 'Irrelevant image.' },
  { id: 'media009', uploaderName: 'Silken Dreams (Vendor)', mediaType: 'Product Image', contextLink: '/admin/products/modProd003', contextName: 'Luxury Silk Scarf', dateUploaded: '2024-07-21', status: 'Pending Review', mediaUrl: 'https://placehold.co/150x150.png', aiHint: 'silk scarf' },
  { id: 'media010', uploaderName: 'Artisan Crafts (Vendor)', mediaType: 'Vendor Profile Picture', contextLink: '/admin/users/vendors/artisan-crafts', contextName: 'Artisan Crafts Workshop', dateUploaded: '2024-07-20', status: 'Flagged', mediaUrl: 'https://placehold.co/150x150.png', aiHint: 'craft workshop', reasonForFlag: 'Contains text overlay not allowed.' },
  { id: 'media011', uploaderName: 'Buyer Pro', mediaType: 'Custom Request Attachment', contextLink: '/admin/requests/REQ125', contextName: 'Tech Gadget Casing', dateUploaded: '2024-07-19', status: 'Pending Review', mediaUrl: 'https://placehold.co/150x150.png', aiHint: 'gadget case' },
  { id: 'media012', uploaderName: 'The Shoe Place (Vendor)', mediaType: 'Product Image', contextLink: '/admin/products/modProd004', contextName: 'Leather Boots', dateUploaded: '2024-07-18', status: 'Approved', mediaUrl: 'https://placehold.co/150x150.png', aiHint: 'leather boots' },
  { id: 'media013', uploaderName: 'Design Requestor', mediaType: 'Custom Request Attachment', contextLink: '/admin/requests/REQ126', contextName: 'Minimalist Watch Design', dateUploaded: '2024-07-17', status: 'Pending Review', mediaUrl: 'https://placehold.co/150x150.png', aiHint: 'watch design' },
  { id: 'media014', uploaderName: 'Gamer Gear (Vendor)', mediaType: 'Vendor Profile Picture', contextLink: '/admin/users/vendors/gamer-gear', contextName: 'Gamer Gear Logo', dateUploaded: '2024-07-16', status: 'Pending Review', mediaUrl: 'https://placehold.co/150x150.png', aiHint: 'gaming logo' },
  { id: 'media015', uploaderName: 'Fashionista Jane', mediaType: 'Review Image', contextLink: '/admin/content/reviews/rev008', contextName: 'Review for Hand-Stitched Bag', dateUploaded: '2024-07-15', status: 'Rejected', mediaUrl: 'https://placehold.co/150x150.png', aiHint: 'selfie mirror', reasonForFlag: 'Not an image of the product.' },
];

const MediaStatusBadge = ({ status }: { status: MediaStatus }) => {
  let variant: "default" | "secondary" | "destructive" | "outline" = "default";
  if (status === "Pending Review") variant = "secondary";
  else if (status === "Approved") variant = "default";
  else if (status === "Rejected") variant = "destructive";
  else if (status === "Flagged") variant = "destructive";

  return <Badge variant={variant} className={`text-xs ${status === "Approved" ? "bg-green-500/10 text-green-700 border-green-500/30" : status === "Flagged" ? "bg-orange-500/10 text-orange-700 border-orange-500/30" : ""}`}>{status}</Badge>;
};

export default function AdminMediaModerationPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [mediaItems, setMediaItems] = useState<MediaForModeration[]>(initialMediaForModeration);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<MediaStatus | "All">("All");
  const [filterType, setFilterType] = useState<MediaType | "All">("All");

  const filteredMediaItems = mediaItems.filter(item => {
    const matchesSearch =
      item.uploaderName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.contextName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.mediaType.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.reasonForFlag && item.reasonForFlag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesStatus = filterStatus === "All" || item.status === filterStatus;
    const matchesType = filterType === "All" || item.mediaType === filterType;
    return matchesSearch && matchesStatus && matchesType;
  });

  const mediaStatuses: (MediaStatus | "All")[] = ["All", "Pending Review", "Approved", "Rejected", "Flagged"];
  const mediaTypes: (MediaType | "All")[] = ["All", "Product Image", "Custom Request Attachment", "Vendor Profile Picture", "Review Image"];

  const handleMediaAction = (itemId: string, newStatus: "Approved" | "Rejected") => {
    setMediaItems(prev =>
        prev.map(m => m.id === itemId ? {...m, status: newStatus} : m)
    );
    const item = mediaItems.find(m => m.id === itemId);
    toast({title: `Media Item ${newStatus}`, description: `Media for "${item?.contextName}" has been ${newStatus.toLowerCase()}.`});
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-headline font-semibold flex items-center">
            <ImagePlay className="mr-3 h-7 w-7 text-primary"/> User Media Moderation
        </h1>
        <Button variant="outline" size="sm" onClick={() => router.back()}>
          <ArrowLeft className="mr-1.5 h-3.5 w-3.5" /> Back to Content Management
        </Button>
      </div>

      <Card>
        <CardHeader className="p-3 border-b">
          <CardTitle className="text-lg">Media Queue</CardTitle>
          <CardDescription className="text-xs">Review and approve or reject user-uploaded media files.</CardDescription>
          <div className="pt-2 flex flex-col sm:flex-row gap-2">
            <div className="relative flex-grow">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search media by uploader, context, type..."
                className="pl-8 h-9 text-xs"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={filterType} onValueChange={(value) => setFilterType(value as MediaType | "All")}>
              <SelectTrigger className="w-full sm:w-auto min-w-[180px] h-9 text-xs">
                <SelectValue placeholder="Filter by Type" />
              </SelectTrigger>
              <SelectContent>
                {mediaTypes.map(type => <SelectItem key={type} value={type} className="text-xs">{type}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={(value) => setFilterStatus(value as MediaStatus | "All")}>
              <SelectTrigger className="w-full sm:w-auto min-w-[160px] h-9 text-xs">
                <SelectValue placeholder="Filter by Status" />
              </SelectTrigger>
              <SelectContent>
                {mediaStatuses.map(stat => <SelectItem key={stat} value={stat} className="text-xs">{stat}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
            {filteredMediaItems.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 p-4">
                    {filteredMediaItems.map((item) => (
                        <Card key={item.id} className="overflow-hidden">
                             <CardHeader className="p-3">
                                <div className="flex items-center justify-between">
                                    <MediaStatusBadge status={item.status} />
                                    <Badge variant="outline" className="text-xs">{item.mediaType}</Badge>
                                </div>
                            </CardHeader>
                            <CardContent className="p-3 space-y-2">
                                <div className="relative aspect-video bg-muted rounded-md overflow-hidden">
                                     <Image src={item.mediaUrl} alt={`Media for ${item.contextName}`} layout="fill" objectFit="cover" data-ai-hint={item.aiHint} />
                                </div>
                                <div className="text-xs">
                                    <p className="font-medium text-foreground truncate" title={item.contextName}>
                                        <Link href={item.contextLink} className="hover:underline text-primary">{item.contextName}</Link>
                                    </p>
                                    <p className="text-muted-foreground flex items-center"><UserCircle className="h-3 w-3 mr-1"/>{item.uploaderName}</p>
                                    <p className="text-muted-foreground flex items-center"><CalendarDays className="h-3 w-3 mr-1"/>{item.dateUploaded}</p>
                                    {item.reasonForFlag && <p className="text-orange-600 truncate" title={item.reasonForFlag}><FileText className="h-3 w-3 mr-1 inline"/>{item.reasonForFlag}</p>}
                                </div>
                            </CardContent>
                            <CardFooter className="p-3 border-t flex gap-2">
                                 {(item.status === 'Pending Review' || item.status === 'Flagged') && (
                                 <>
                                  <Button variant="ghost" size="sm" onClick={() => handleMediaAction(item.id, 'Approved')} className="text-green-600 hover:text-green-700 flex-1">
                                    <CheckCircle className="mr-1.5 h-4 w-4" /> Approve
                                  </Button>
                                   <Button variant="ghost" size="sm" onClick={() => handleMediaAction(item.id, 'Rejected')} className="text-red-600 hover:text-red-700 flex-1">
                                     <XCircle className="mr-1.5 h-4 w-4" /> Reject
                                   </Button>
                                 </>
                               )}
                               {(item.status === 'Approved' || item.status === 'Rejected') && (
                                 <Button variant="ghost" size="sm" disabled className="w-full">Processed</Button>
                               )}
                            </CardFooter>
                        </Card>
                    ))}
                </div>
            ) : (
                <div className="text-center py-10 text-muted-foreground">
                    {searchTerm || filterStatus !== "All" || filterType !== "All" ? "No media items match your criteria." : "No media items currently require moderation."}
                </div>
            )}
        </CardContent>
         <CardFooter className="border-t p-3">
            <p className="text-xs text-muted-foreground">
                Found {filteredMediaItems.length} media item(s).
            </p>
        </CardFooter>
      </Card>
    </div>
  );
}
