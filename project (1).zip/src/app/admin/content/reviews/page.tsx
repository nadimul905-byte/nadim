
"use client";

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CheckCircle, XCircle, MessageSquareText, Search, Filter, ArrowLeft, Star } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';

type ReviewStatus = "Pending" | "Approved" | "Rejected" | "Flagged";

interface ReviewForModeration {
  id: string;
  productOrVendorName: string; // Name of the product or vendor being reviewed
  reviewerName: string;
  rating: number; // 1-5 stars
  comment: string;
  dateSubmitted: string;
  status: ReviewStatus;
  reasonForFlag?: string;
  targetType: 'Product' | 'Vendor'; // To differentiate review types
}

const initialReviewsForModeration: ReviewForModeration[] = [
  { id: 'rev001', productOrVendorName: 'Elegant Evening Gown', reviewerName: 'Retailer A', rating: 5, comment: 'Excellent quality, beautiful design!', dateSubmitted: '2024-07-30', status: 'Pending', targetType: 'Product' },
  { id: 'rev002', productOrVendorName: 'Chic Designs Co.', reviewerName: 'Store B', rating: 2, comment: 'Late delivery and poor communication. Product was okay.', dateSubmitted: '2024-07-29', status: 'Pending', reasonForFlag: 'Potentially unfair rating due to shipping.', targetType: 'Vendor' },
  { id: 'rev003', productOrVendorName: 'Stylish Sneakers', reviewerName: 'Fashion Outlet', rating: 4, comment: 'Good value for money, customers like them.', dateSubmitted: '2024-07-28', status: 'Approved', targetType: 'Product' },
  { id: 'rev004', productOrVendorName: 'Glitter Glam', reviewerName: 'Anonymous User', rating: 1, comment: 'This is spam and makes no sense!! sdfgsdfg sdfgsdfg.', dateSubmitted: '2024-07-27', status: 'Rejected', reasonForFlag: 'Spam/Irrelevant', targetType: 'Vendor' },
  { id: 'rev005', productOrVendorName: 'Leather Handbag', reviewerName: 'Luxury Finds', rating: 5, comment: 'Absolutely stunning craftsmanship. A bestseller.', dateSubmitted: '2024-07-26', status: 'Pending', targetType: 'Product' },
];

const ReviewStatusBadge = ({ status }: { status: ReviewStatus }) => {
  let variant: "default" | "secondary" | "destructive" | "outline" = "default";
  if (status === "Pending") variant = "secondary";
  else if (status === "Approved") variant = "default"; // Green for success
  else if (status === "Rejected") variant = "destructive";
  else if (status === "Flagged") variant = "destructive"; 

  return <Badge variant={variant} className={`text-xs ${status === "Approved" ? "bg-green-500/10 text-green-700 border-green-500/30" : status === "Flagged" ? "bg-orange-500/10 text-orange-700 border-orange-500/30" : ""}`}>{status}</Badge>;
};

const RatingStars = ({ rating }: { rating: number }) => (
  <div className="flex">
    {[...Array(5)].map((_, i) => (
      <Star key={i} className={`h-3.5 w-3.5 ${i < rating ? 'fill-yellow-400 text-yellow-400' : 'fill-muted text-muted-foreground'}`} />
    ))}
  </div>
);

export default function AdminReviewManagementPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [reviews, setReviews] = useState<ReviewForModeration[]>(initialReviewsForModeration);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<ReviewStatus | "All">("All");

  const filteredReviews = reviews.filter(review => {
    const matchesSearch = 
      review.productOrVendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      review.reviewerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      review.comment.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (review.reasonForFlag && review.reasonForFlag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesStatus = filterStatus === "All" || review.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const reviewStatuses: (ReviewStatus | "All")[] = ["All", "Pending", "Approved", "Rejected", "Flagged"];

  const handleReviewAction = (reviewId: string, newStatus: "Approved" | "Rejected") => {
    setReviews(prev => 
        prev.map(r => r.id === reviewId ? {...r, status: newStatus} : r)
    );
    const review = reviews.find(r => r.id === reviewId);
    toast({title: `Review ${newStatus}`, description: `Review for "${review?.productOrVendorName}" has been ${newStatus.toLowerCase()}.`});
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-headline font-semibold flex items-center">
            <MessageSquareText className="mr-3 h-7 w-7 text-primary"/> Review Management Queue
        </h1>
        <Button variant="outline" size="sm" onClick={() => router.back()}>
          <ArrowLeft className="mr-1.5 h-3.5 w-3.5" /> Back to Content Management
        </Button>
      </div>

      <Card>
        <CardHeader className="p-3 border-b">
          <CardTitle className="text-lg">Reviews Awaiting Moderation</CardTitle>
          <CardDescription className="text-xs">Review and approve or reject user-submitted reviews for products and vendors.</CardDescription>
          <div className="pt-2 flex flex-col sm:flex-row gap-2">
            <div className="relative flex-grow">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search reviews by product/vendor, reviewer, comment..." 
                className="pl-8 h-9 text-xs" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={filterStatus} onValueChange={(value) => setFilterStatus(value as ReviewStatus | "All")}>
              <SelectTrigger className="w-full sm:w-auto min-w-[160px] h-9 text-xs">
                <SelectValue placeholder="Filter by Status" />
              </SelectTrigger>
              <SelectContent>
                {reviewStatuses.map(stat => <SelectItem key={stat} value={stat} className="text-xs">{stat}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="p-2 text-xs w-[20%]">Target</TableHead>
                <TableHead className="p-2 text-xs w-[15%]">Reviewer</TableHead>
                <TableHead className="p-2 text-xs w-[30%]">Comment</TableHead>
                <TableHead className="p-2 text-xs text-center">Rating</TableHead>
                <TableHead className="p-2 text-xs text-center">Status</TableHead>
                <TableHead className="p-2 text-xs text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredReviews.length > 0 ? filteredReviews.map((review) => (
                <TableRow key={review.id}>
                  <TableCell className="p-2 text-xs font-medium">
                    <Link href={review.targetType === 'Product' ? `/admin/products/${review.productOrVendorName.toLowerCase().replace(/\s+/g, '-')}` : `/admin/vendors/${review.productOrVendorName.toLowerCase().replace(/\s+/g, '-')}`} className="hover:underline text-primary">
                      {review.productOrVendorName}
                    </Link>
                    <p className="text-xs text-muted-foreground">({review.targetType})</p>
                  </TableCell>
                  <TableCell className="p-2 text-xs">{review.reviewerName}</TableCell>
                  <TableCell className="p-2 text-xs max-w-xs">
                    <p className="truncate" title={review.comment}>{review.comment}</p>
                    {review.reasonForFlag && <p className="text-xs text-orange-600 mt-1">Flag: {review.reasonForFlag}</p>}
                  </TableCell>
                  <TableCell className="p-2 text-xs text-center"><RatingStars rating={review.rating} /></TableCell>
                  <TableCell className="p-2 text-xs text-center">
                    <ReviewStatusBadge status={review.status} />
                  </TableCell>
                  <TableCell className="p-2 text-xs text-right">
                    <div className="flex gap-1 justify-end">
                       {(review.status === 'Pending' || review.status === 'Flagged') && (
                         <>
                          <Button variant="ghost" size="xs" onClick={() => handleReviewAction(review.id, 'Approved')} className="text-green-600 hover:text-green-700">
                            <CheckCircle className="mr-1 h-3.5 w-3.5" /> Approve
                          </Button>
                           <Button variant="ghost" size="xs" onClick={() => handleReviewAction(review.id, 'Rejected')} className="text-red-600 hover:text-red-700">
                             <XCircle className="mr-1 h-3.5 w-3.5" /> Reject
                           </Button>
                         </>
                       )}
                       {(review.status === 'Approved' || review.status === 'Rejected') && (
                         <Button variant="ghost" size="xs" disabled>Processed</Button>
                       )}
                    </div>
                  </TableCell>
                </TableRow>
              )) : (
                 <TableRow>
                    <TableCell colSpan={6} className="text-center py-6 text-xs text-muted-foreground">
                        {searchTerm || filterStatus !== "All" ? "No reviews match your criteria." : "No reviews currently require moderation."}
                    </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
         <CardFooter className="border-t p-2">
            <p className="text-xs text-muted-foreground">
                Found {filteredReviews.length} review(s).
            </p>
        </CardFooter>
      </Card>
    </div>
  );
}
