
"use client";

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CheckCircle, XCircle, Eye, Search, Filter, FileArchive, ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';

type ProductStatus = "Pending Review" | "Approved" | "Rejected" | "Action Required";

interface ProductForModeration {
  id: string;
  name: string;
  vendorName: string;
  category: string;
  dateSubmitted: string;
  status: ProductStatus;
  imageUrl: string;
  aiHint?: string;
  reasonForFlag?: string; 
}

const initialProductsForModeration: ProductForModeration[] = [
  { id: 'modProd001', name: 'Super Shiny Top', vendorName: 'Glitter Glam', category: "Women's Apparel", dateSubmitted: '2024-07-29', status: 'Pending Review', imageUrl: 'https://placehold.co/60x60.png?text=Top', aiHint: 'shiny top', reasonForFlag: 'Potentially misleading description.' },
  { id: 'modProd002', name: 'Rustic Wooden Chair', vendorName: 'Home Comforts', category: 'Furniture', dateSubmitted: '2024-07-28', status: 'Pending Review', imageUrl: 'https://placehold.co/60x60.png?text=Chair', aiHint: 'wooden chair' },
  { id: 'modProd003', name: 'Kids Toy Blaster V.2', vendorName: 'ToyJoy', category: 'Toys', dateSubmitted: '2024-07-27', status: 'Approved', imageUrl: 'https://placehold.co/60x60.png?text=Toy', aiHint: 'kids toy' },
  { id: 'modProd004', name: 'Miracle Hair Growth Serum', vendorName: 'BeautySecrets', category: 'Cosmetics', dateSubmitted: '2024-07-26', status: 'Rejected', imageUrl: 'https://placehold.co/60x60.png?text=Serum', aiHint: 'hair serum', reasonForFlag: 'Unsubstantiated claims.' },
  { id: 'modProd005', name: 'Leather Biker Jacket', vendorName: 'Tough Threads', category: "Men's Apparel", dateSubmitted: '2024-07-25', status: 'Pending Review', imageUrl: 'https://placehold.co/60x60.png?text=Jacket', aiHint: 'leather jacket' },
  { id: 'modProd006', name: 'Smart Watch Series X', vendorName: 'Tech Gizmos', category: 'Electronics', dateSubmitted: '2024-07-24', status: 'Pending Review', imageUrl: 'https://placehold.co/60x60.png?text=Watch', aiHint: 'smart watch' },
  { id: 'modProd007', name: 'Organic Dog Treats', vendorName: 'Pawsome Pets', category: 'Pet Supplies', dateSubmitted: '2024-07-23', status: 'Approved', imageUrl: 'https://placehold.co/60x60.png?text=Treats', aiHint: 'dog treats' },
  { id: 'modProd008', name: 'Handmade Pottery Vase', vendorName: 'Artisan Crafts', category: 'Home Decor', dateSubmitted: '2024-07-22', status: 'Pending Review', imageUrl: 'https://placehold.co/60x60.png?text=Vase', aiHint: 'pottery vase', reasonForFlag: 'Image quality low.' },
  { id: 'modProd009', name: 'Gourmet Coffee Beans', vendorName: 'The Coffee Co.', category: 'Groceries', dateSubmitted: '2024-07-21', status: 'Rejected', imageUrl: 'https://placehold.co/60x60.png?text=Coffee', aiHint: 'coffee beans', reasonForFlag: 'Prohibited item category.' },
  { id: 'modProd010', name: 'Yoga Mat Premium', vendorName: 'ZenFit', category: 'Sports & Outdoors', dateSubmitted: '2024-07-20', status: 'Pending Review', imageUrl: 'https://placehold.co/60x60.png?text=Mat', aiHint: 'yoga mat' },
  { id: 'modProd011', name: 'Silk Pillowcase Set', vendorName: 'Luxury Linens', category: 'Bedding', dateSubmitted: '2024-07-19', status: 'Pending Review', imageUrl: 'https://placehold.co/60x60.png?text=Pillow', aiHint: 'silk pillowcase' },
  { id: 'modProd012', name: 'Bluetooth Earbuds Pro', vendorName: 'SoundWave', category: 'Electronics', dateSubmitted: '2024-07-18', status: 'Approved', imageUrl: 'https://placehold.co/60x60.png?text=Earbuds', aiHint: 'bluetooth earbuds' },
  { id: 'modProd013', name: 'Designer Sunglasses', vendorName: 'Shady Business', category: 'Accessories', dateSubmitted: '2024-07-17', status: 'Pending Review', imageUrl: 'https://placehold.co/60x60.png?text=Shades', aiHint: 'sunglasses fashion' },
  { id: 'modProd014', name: 'Novelty Socks Collection', vendorName: 'Happy Feet Inc.', category: "Men's Apparel", dateSubmitted: '2024-07-16', status: 'Rejected', imageUrl: 'https://placehold.co/60x60.png?text=Socks', aiHint: 'novelty socks', reasonForFlag: 'Copyright concern on design.'},
  { id: 'modProd015', name: 'Childrens Story Book', vendorName: 'ReadMore Publishing', category: 'Books', dateSubmitted: '2024-07-15', status: 'Pending Review', imageUrl: 'https://placehold.co/60x60.png?text=Book', aiHint: 'story book' },
  { id: 'modProd016', name: 'Wireless Gaming Mouse', vendorName: 'GameOn Gear', category: 'Electronics', dateSubmitted: '2024-07-14', status: 'Pending Review', imageUrl: 'https://placehold.co/60x60.png?text=Mouse', aiHint: 'gaming mouse', reasonForFlag: 'Claims seem exaggerated.' },
  { id: 'modProd017', name: 'Fitness Tracker Band', vendorName: 'ActiveLife', category: 'Sports & Outdoors', dateSubmitted: '2024-07-13', status: 'Approved', imageUrl: 'https://placehold.co/60x60.png?text=Band', aiHint: 'fitness band' },
  { id: 'modProd018', name: 'Artisanal Chocolate Box', vendorName: 'Sweet Delights', category: 'Groceries', dateSubmitted: '2024-07-12', status: 'Pending Review', imageUrl: 'https://placehold.co/60x60.png?text=Choco', aiHint: 'chocolate box' },
  { id: 'modProd019', name: 'Electric Toothbrush V2', vendorName: 'CleanSmile', category: 'Health & Beauty', dateSubmitted: '2024-07-11', status: 'Rejected', imageUrl: 'https://placehold.co/60x60.png?text=Brush', aiHint: 'electric toothbrush', reasonForFlag: 'Safety certifications missing.' },
  { id: 'modProd020', name: 'Stainless Steel Water Bottle', vendorName: 'HydrateNow', category: 'Kitchen', dateSubmitted: '2024-07-10', status: 'Pending Review', imageUrl: 'https://placehold.co/60x60.png?text=Bottle', aiHint: 'water bottle' },
];

const ProductStatusBadge = ({ status }: { status: ProductStatus }) => {
  let variant: "default" | "secondary" | "destructive" | "outline" = "default";
  if (status === "Pending Review") variant = "secondary";
  else if (status === "Approved") variant = "default"; // Green for success
  else if (status === "Rejected") variant = "destructive";
  else if (status === "Action Required") variant = "destructive"; // Can use orange/yellow via custom styling

  return <Badge variant={variant} className={`text-xs ${status === "Approved" ? "bg-green-500/10 text-green-700 border-green-500/30" : ""}`}>{status}</Badge>;
};

export default function AdminProductModerationPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [products, setProducts] = useState<ProductForModeration[]>(initialProductsForModeration);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<ProductStatus | "All">("All");

  const filteredProducts = products.filter(product => {
    const matchesSearch = 
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (product.reasonForFlag && product.reasonForFlag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesStatus = filterStatus === "All" || product.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const productStatuses: (ProductStatus | "All")[] = ["All", "Pending Review", "Approved", "Rejected", "Action Required"];

  const handleProductAction = (productId: string, newStatus: "Approved" | "Rejected") => {
    setProducts(prev => 
        prev.map(p => p.id === productId ? {...p, status: newStatus} : p)
    );
    const product = products.find(p => p.id === productId);
    toast({title: `Product ${newStatus}`, description: `Product "${product?.name}" has been ${newStatus.toLowerCase()}.`});
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-headline font-semibold flex items-center">
            <FileArchive className="mr-3 h-7 w-7 text-primary"/> Product Moderation Queue
        </h1>
        <Button variant="outline" size="sm" onClick={() => router.back()}>
          <ArrowLeft className="mr-1.5 h-3.5 w-3.5" /> Back
        </Button>
      </div>

      <Card>
        <CardHeader className="p-3 border-b">
          <CardTitle className="text-lg">Products Awaiting Review</CardTitle>
          <CardDescription className="text-xs">Review and approve or reject product submissions.</CardDescription>
          <div className="pt-2 flex flex-col sm:flex-row gap-2">
            <div className="relative flex-grow">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search products by name, vendor, category, reason..." 
                className="pl-8 h-9 text-xs" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={filterStatus} onValueChange={(value) => setFilterStatus(value as ProductStatus | "All")}>
              <SelectTrigger className="w-full sm:w-auto min-w-[160px] h-9 text-xs">
                <SelectValue placeholder="Filter by Status" />
              </SelectTrigger>
              <SelectContent>
                {productStatuses.map(stat => <SelectItem key={stat} value={stat} className="text-xs">{stat}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="p-2 text-xs">Product</TableHead>
                <TableHead className="p-2 text-xs">Vendor</TableHead>
                <TableHead className="p-2 text-xs">Category</TableHead>
                <TableHead className="p-2 text-xs">Submitted</TableHead>
                <TableHead className="p-2 text-xs">Flag Reason</TableHead>
                <TableHead className="p-2 text-xs text-center">Status</TableHead>
                <TableHead className="p-2 text-xs text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredProducts.length > 0 ? filteredProducts.map((product) => (
                <TableRow key={product.id}>
                  <TableCell className="p-2 text-xs font-medium">
                    <div className="flex items-center gap-2">
                        <Image src={product.imageUrl} alt={product.name} width={32} height={32} className="rounded-sm object-cover" data-ai-hint={product.aiHint}/>
                        {product.name}
                    </div>
                  </TableCell>
                  <TableCell className="p-2 text-xs">{product.vendorName}</TableCell>
                  <TableCell className="p-2 text-xs">{product.category}</TableCell>
                  <TableCell className="p-2 text-xs">{product.dateSubmitted}</TableCell>
                  <TableCell className="p-2 text-xs text-muted-foreground max-w-[150px] truncate" title={product.reasonForFlag}>
                    {product.reasonForFlag || 'N/A'}
                  </TableCell>
                  <TableCell className="p-2 text-xs text-center">
                    <ProductStatusBadge status={product.status} />
                  </TableCell>
                  <TableCell className="p-2 text-xs text-right">
                    <div className="flex gap-1 justify-end">
                      {/* <Button variant="outline" size="xs" asChild>
                        <Link href={`/admin/content/products/moderation/${product.id}`}>
                          <Eye className="mr-1 h-3 w-3" /> View
                        </Link>
                      </Button> */}
                       {(product.status === 'Pending Review' || product.status === 'Action Required') && (
                         <>
                          <Button variant="ghost" size="xs" onClick={() => handleProductAction(product.id, 'Approved')} className="text-green-600 hover:text-green-700">
                            <CheckCircle className="mr-1 h-3.5 w-3.5" /> Approve
                          </Button>
                           <Button variant="ghost" size="xs" onClick={() => handleProductAction(product.id, 'Rejected')} className="text-red-600 hover:text-red-700">
                             <XCircle className="mr-1 h-3.5 w-3.5" /> Reject
                           </Button>
                         </>
                       )}
                       {(product.status === 'Approved' || product.status === 'Rejected') && (
                         <Button variant="ghost" size="xs" disabled>Processed</Button>
                       )}
                    </div>
                  </TableCell>
                </TableRow>
              )) : (
                 <TableRow>
                    <TableCell colSpan={7} className="text-center py-6 text-xs text-muted-foreground">
                        {searchTerm || filterStatus !== "All" ? "No products match your criteria." : "No products currently require moderation."}
                    </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
         <CardFooter className="border-t p-2">
            <p className="text-xs text-muted-foreground">
                Found {filteredProducts.length} product(s).
            </p>
        </CardFooter>
      </Card>
    </div>
  );
}
