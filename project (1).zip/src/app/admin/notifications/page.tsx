
"use client";
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BellRing, UserCheck, AlertTriangle, FileArchive, BarChart3, ShieldAlert } from 'lucide-react';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { useRouter } from 'next/navigation';

interface AdminNotification {
  id: string;
  type: "Vendor Approval" | "New Dispute" | "Content Flagged" | "System Alert" | "Report Ready";
  title: string;
  message: string;
  time: string;
  icon: React.ElementType;
  read: boolean;
  link?: string;
  variant?: "default" | "destructive" | "warning";
}

export const adminNotifications: AdminNotification[] = [
  { id: 'an001', type: "Vendor Approval", title: "New Vendor: 'EcoCrafts Ltd.'", message: "A new vendor application from 'EcoCrafts Ltd.' requires your review.", time: "15m ago", icon: UserCheck, read: false, link: "/admin/users/vendors/approvals", variant: "default" },
  { id: 'an002', type: "New Dispute", title: "Dispute #D105 Opened", message: "A new dispute has been opened between Retailer 'Fashion Forward' and Vendor 'Silk Dreams'.", time: "1h ago", icon: ShieldAlert, read: false, link: "/admin/disputes/D105", variant: "destructive" },
  { id: 'an003', type: "Content Flagged", title: "Product Flagged: 'Miracle Hair Serum'", message: "Product 'Miracle Hair Serum' by Vendor 'BeautySecrets' has been flagged for unsubstantiated claims.", time: "3h ago", icon: FileArchive, read: false, link: "/admin/content/products/moderation", variant: "warning" },
  { id: 'an004', type: "System Alert", title: "Scheduled Maintenance Upcoming", message: "Platform maintenance is scheduled for Aug 5, 02:00 AM - 03:00 AM UTC.", time: "1d ago", icon: AlertTriangle, read: true, variant: "warning" },
  { id: 'an005', type: "Report Ready", title: "July Sales Report Available", message: "The monthly sales report for July 2024 is now available for review.", time: "2d ago", icon: BarChart3, read: true, link: "/admin/reports/sales-overview-details" },
  { id: 'an006', type: "Content Flagged", title: "Review Flagged: Order #ORD002", message: "A user review for order #ORD002 has been flagged as inappropriate.", time: "4h ago", icon: FileArchive, read: false, link: "/admin/content/reviews", variant: "warning" },
  { id: 'an007', type: "Vendor Approval", title: "New Vendor: 'Urban Threads'", message: "Application from 'Urban Threads' is pending review.", time: "6h ago", icon: UserCheck, read: true, link: "/admin/users/vendors/approvals" },
];

export default function AdminNotificationsPage() {
  const router = useRouter();
  // In a real app, you'd manage the 'read' state
  const unreadCount = adminNotifications.filter(n => !n.read).length;

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-headline font-semibold">Admin Notifications</h1>
        <Button variant="outline" onClick={() => router.back()}>
            <ArrowLeft className="mr-2 h-4 w-4"/> Back
        </Button>
      </div>
      <CardDescription>
        You have {unreadCount} unread notification{unreadCount !== 1 ? 's' : ''}.
      </CardDescription>
      
      {adminNotifications.length > 0 ? (
        adminNotifications.map(notif => {
          const Icon = notif.icon;
          let cardBorderClass = "";
          if (!notif.read) {
            if (notif.variant === "destructive") cardBorderClass = "border-destructive border-2";
            else if (notif.variant === "warning") cardBorderClass = "border-yellow-500 border-2";
            else cardBorderClass = "border-primary border-2";
          }

          return (
            <Card key={notif.id} className={`hover:shadow-lg transition-shadow ${cardBorderClass}`}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <Icon className={`h-6 w-6 ${notif.variant === "destructive" ? "text-destructive" : notif.variant === "warning" ? "text-yellow-500" : "text-primary"}`} />
                    <CardTitle className="text-lg">
                        {notif.link ? <Link href={notif.link} className="hover:underline">{notif.title}</Link> : notif.title}
                    </CardTitle>
                  </div>
                  {!notif.read && <Badge variant={notif.variant || "default"} className="text-xs">New</Badge>}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-1">{notif.message}</p>
                <p className="text-xs text-muted-foreground/70">{notif.time}</p>
              </CardContent>
            </Card>
          );
        })
      ) : (
        <Card>
          <CardContent className="py-12 text-center">
            <BellRing className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold">No New Notifications</h3>
            <p className="text-muted-foreground">You're all caught up!</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
