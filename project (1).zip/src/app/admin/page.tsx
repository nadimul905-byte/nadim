
"use client";
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, DollarSign, ShieldAlert, PackageCheck, UserCheck, FileArchive, AlertTriangle, BarChart3, Landmark } from 'lucide-react';
import Link from 'next/link';

const MetricCard = ({ title, value, icon: Icon, description, link, linkText, variant }: { title: string, value: string, icon: React.ElementType, description: string, link?: string, linkText?: string, variant?: "default" | "warning" | "success" }) => {
  let valueColor = "text-foreground";
  if (variant === "warning") valueColor = "text-orange-500";
  if (variant === "success") valueColor = "text-green-500";
  
  return (
  <Card>
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium">{title}</CardTitle>
      <Icon className="h-5 w-5 text-muted-foreground" />
    </CardHeader>
    <CardContent>
      <div className={`text-2xl font-bold ${valueColor}`}>{value}</div>
      <p className="text-xs text-muted-foreground">{description}</p>
      {link && linkText && (
        <Button variant="link" asChild className="px-0 pt-2 text-primary">
          <Link href={link}>{linkText}</Link>
        </Button>
      )}
    </CardContent>
  </Card>
  );
};

const recentAdminActivities = [
  { id: 1, type: "New Vendor Signup", description: "Creative Designs Co. applied", actionText: "Approve", link: "/admin/users/vendors/approvals", icon: UserCheck, color: "text-blue-500" },
  { id: 2, type: "Flagged Product", description: "Product 'Super Shiny Top' needs review", actionText: "Review", link: "/admin/content/products/moderation", icon: FileArchive, color: "text-yellow-500" },
  { id: 3, type: "High Value Order", description: "Order #HV9876 for $5,250 placed", actionText: "View Order", link: "/admin/orders/HV9876", icon: DollarSign, color: "text-green-500" },
  { id: 4, type: "Dispute Opened", description: "Dispute #D102 on Order #ORD555", actionText: "Resolve", link: "/admin/disputes/D102", icon: AlertTriangle, color: "text-red-500" },
];

export default function AdminDashboardPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-headline font-semibold">Admin Dashboard</h1>
      
      {/* Top Metrics Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <MetricCard title="Total Active Users" value="1,234" icon={Users} description="Retailers & Vendors" />
        <MetricCard title="GMV Today" value="$25,670" icon={DollarSign} description="+5.2% from yesterday" variant="success" />
        <MetricCard title="Pending Vendor Approvals" value="5" icon={UserCheck} description="Require review" link="/admin/users/vendors/approvals" linkText="Review Now" variant="warning" />
        <MetricCard title="Pending Loans" value="4" icon={Landmark} description="Awaiting review" link="/admin/finance" linkText="View Applications" variant="warning"/>
      </div>

      {/* Quick Actions */}
       <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Button asChild size="lg" className="py-6 text-base bg-primary hover:bg-primary/90">
          <Link href="/admin/users/vendors/approvals"><UserCheck className="mr-2 h-5 w-5" /> Review Vendors</Link>
        </Button>
        <Button asChild variant="outline" size="lg" className="py-6 text-base">
          <Link href="/admin/content/products/moderation"><FileArchive className="mr-2 h-5 w-5" /> Review Products</Link>
        </Button>
         <Button asChild variant="outline" size="lg" className="py-6 text-base">
          <Link href="/admin/finance"><Landmark className="mr-2 h-5 w-5" /> Review Loans</Link>
        </Button>
        <Button asChild variant="outline" size="lg" className="py-6 text-base">
          <Link href="/admin/reports"><BarChart3 className="mr-2 h-5 w-5" /> View Reports</Link>
        </Button>
      </div>


      {/* Recent Activity Feed */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Platform Activity</CardTitle>
          <CardDescription>Key events requiring admin attention.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {recentAdminActivities.map(activity => {
            const IconComponent = activity.icon;
            return (
              <div key={activity.id} className="flex items-start space-x-3 p-3 border rounded-lg hover:bg-muted/50">
                <IconComponent className={`h-6 w-6 mt-1 ${activity.color}`} />
                <div className="flex-1">
                  <p className="font-medium text-sm">{activity.type}</p>
                  <p className="text-xs text-muted-foreground">{activity.description}</p>
                </div>
                <Button variant="ghost" size="sm" asChild>
                  <Link href={activity.link}>{activity.actionText}</Link>
                </Button>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}
