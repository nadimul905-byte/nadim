"use client";

import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, MessageSquare, Package, Send, ShieldCheck, User, DollarSign, CalendarDays, Loader2 } from 'lucide-react';
import Link from 'next/link';
import { useToast } from '@/hooks/use-toast';
import { getDisputeById } from '../page';

type DisputeStatus = "Open" | "Under Review" | "Resolved - Retailer Favored" | "Resolved - Vendor Favored" | "Closed";
interface Communication {
  user: string;
  message: string;
  timestamp: string;
}
interface Dispute {
  id: string;
  orderId: string;
  retailerName: string;
  vendorName: string;
  dateOpened: string;
  reason: string;
  status: DisputeStatus;
  lastUpdate: string;
  details?: string;
  communications?: Communication[];
}

const StatusBadgeComponent = ({ status }: { status: DisputeStatus }) => {
  let variant: "default" | "secondary" | "destructive" | "outline" = "default";
  let textColor = "text-foreground";
  if (status === "Open") { variant = "destructive"; textColor = "text-destructive-foreground"; }
  else if (status === "Under Review") { variant = "secondary"; textColor = "text-secondary-foreground"; }
  else if (status.startsWith("Resolved")) { variant = "default"; textColor = "text-primary-foreground"; }
  else if (status === "Closed") { variant = "outline"; textColor = "text-muted-foreground"; }
  return <Badge variant={variant} className={`px-2 py-1 text-xs ${textColor}`}>{status}</Badge>;
};

export default function AdminDisputeDetailPage() {
  const router = useRouter();
  const params = useParams();
  const disputeId = params.disputeId as string;
  const { toast } = useToast();

  const [dispute, setDispute] = useState<Dispute | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [newMessage, setNewMessage] = useState('');
  const [newStatus, setNewStatus] = useState<DisputeStatus | ''>('');
  const [isUpdating, setIsUpdating] = useState(false);

  useEffect(() => {
    if (disputeId) {
      const foundDispute = getDisputeById(disputeId);
      if (foundDispute) {
        setDispute(foundDispute);
        setNewStatus(foundDispute.status);
      } else {
        toast({ title: "Dispute Not Found", variant: "destructive" });
        router.push('/admin/disputes');
      }
    }
    setIsLoading(false);
  }, [disputeId, router, toast]);

  const handleAddMessage = () => {
    if (!newMessage.trim() || !dispute) return;
    const updatedDispute = {
      ...dispute,
      communications: [
        ...(dispute.communications || []),
        { user: "Admin", message: newMessage, timestamp: new Date().toLocaleString() }
      ],
      lastUpdate: new Date().toISOString().split('T')[0]
    };
    setDispute(updatedDispute);
    setNewMessage('');
    toast({ title: "Message Sent" });
  };

  const handleStatusChange = () => {
    if (!newStatus || !dispute || newStatus === dispute.status) return;
    setIsUpdating(true);
    // Simulate API call
    setTimeout(() => {
      const updatedDispute = { ...dispute, status: newStatus, lastUpdate: new Date().toISOString().split('T')[0] };
      setDispute(updatedDispute);
      toast({ title: "Status Updated", description: `Dispute status changed to ${newStatus}.` });
      setIsUpdating(false);
    }, 1000);
  };

  if (isLoading) {
    return <div className="flex justify-center items-center min-h-screen"><Loader2 className="h-8 w-8 animate-spin text-primary" /> Loading dispute...</div>;
  }

  if (!dispute) {
    return <div className="text-center py-10"><p>Dispute not found.</p></div>;
  }

  const availableStatuses: DisputeStatus[] = ["Open", "Under Review", "Resolved - Retailer Favored", "Resolved - Vendor Favored", "Closed"];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="outline" size="sm" onClick={() => router.push('/admin/disputes')}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Disputes List
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
            <CardTitle className="text-2xl font-headline">Dispute #{dispute.id}</CardTitle>
            <StatusBadgeComponent status={dispute.status} />
          </div>
          <CardDescription>Order ID: <Link href={`/admin/orders/${dispute.orderId}`} className="text-primary hover:underline">{dispute.orderId}</Link></CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="font-semibold mb-1">Involved Parties:</h4>
              <p><User className="inline mr-1.5 h-4 w-4 text-muted-foreground" />Retailer: {dispute.retailerName}</p>
              <p><User className="inline mr-1.5 h-4 w-4 text-muted-foreground" />Vendor: {dispute.vendorName}</p>
            </div>
            <div>
              <h4 className="font-semibold mb-1">Key Dates:</h4>
              <p><CalendarDays className="inline mr-1.5 h-4 w-4 text-muted-foreground" />Opened: {dispute.dateOpened}</p>
              <p><CalendarDays className="inline mr-1.5 h-4 w-4 text-muted-foreground" />Last Update: {dispute.lastUpdate}</p>
            </div>
          </div>
          <div>
            <h4 className="font-semibold mb-1">Reason for Dispute:</h4>
            <p className="text-muted-foreground text-sm">{dispute.reason}</p>
          </div>
          {dispute.details && (
            <div>
              <h4 className="font-semibold mb-1">Details:</h4>
              <p className="text-muted-foreground text-sm whitespace-pre-wrap">{dispute.details}</p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><MessageSquare className="mr-2 h-5 w-5 text-primary" /> Communication Log</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="max-h-60 overflow-y-auto space-y-3 pr-2">
            {dispute.communications && dispute.communications.length > 0 ? (
              dispute.communications.map((comm, index) => (
                <div key={index} className={`p-2 rounded-md text-sm ${comm.user === 'Admin' ? 'bg-blue-50 text-blue-800' : 'bg-gray-50 text-gray-700'}`}>
                  <p><span className="font-semibold">{comm.user}:</span> {comm.message}</p>
                  <p className="text-xs text-muted-foreground/80 mt-0.5">{comm.timestamp}</p>
                </div>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">No communication history.</p>
            )}
          </div>
          <div className="space-y-2 pt-3 border-t">
            <Label htmlFor="newMessage">Add Admin Note / Message:</Label>
            <Textarea id="newMessage" value={newMessage} onChange={(e) => setNewMessage(e.target.value)} placeholder="Type your message or internal note..." rows={3}/>
            <Button onClick={handleAddMessage} size="sm" disabled={!newMessage.trim()}>
              <Send className="mr-2 h-4 w-4"/> Post Message
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><ShieldCheck className="mr-2 h-5 w-5 text-primary" /> Admin Actions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
            <div>
                <Label htmlFor="statusSelect">Change Dispute Status:</Label>
                <div className="flex items-center gap-2 mt-1">
                    <Select value={newStatus} onValueChange={(value) => setNewStatus(value as DisputeStatus)}>
                        <SelectTrigger id="statusSelect" className="flex-grow">
                        <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent>
                        {availableStatuses.map(s => <SelectItem key={s} value={s} disabled={s === dispute.status}>{s}</SelectItem>)}
                        </SelectContent>
                    </Select>
                    <Button onClick={handleStatusChange} disabled={isUpdating || newStatus === dispute.status || !newStatus}>
                        {isUpdating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ShieldCheck className="mr-2 h-4 w-4" />}
                        Update Status
                    </Button>
                </div>
            </div>
        </CardContent>
      </Card>
    </div>
  );
}
