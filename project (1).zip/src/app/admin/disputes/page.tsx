
"use client";

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Search, Filter, Eye, ShieldCheck, MessageSquare } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';

type DisputeStatus = "Open" | "Under Review" | "Resolved - Retailer Favored" | "Resolved - Vendor Favored" | "Closed";

interface Dispute {
  id: string;
  orderId: string;
  retailerName: string;
  vendorName: string;
  dateOpened: string;
  reason: string;
  status: DisputeStatus;
  lastUpdate: string;
  details?: string; // Added for detail page
  communications?: { user: string; message: string; timestamp: string }[]; // Added for detail page
}

const initialDisputes: Dispute[] = [
  { id: 'D101', orderId: 'ORD001', retailerName: 'Fashion Forward', vendorName: 'Chic Designs Co.', dateOpened: '2024-07-25', reason: 'Item not as described, fabric quality is significantly different from the sample provided.', status: 'Open', lastUpdate: '2024-07-28', details: "Retailer claims the fabric quality is significantly different from the sample provided. Vendor states the fabric is from the same batch.", communications: [{user: "Admin", message: "Initial review started.", timestamp: "2024-07-28 10:00"}] },
  { id: 'D102', orderId: 'ORD002', retailerName: 'Style Hub', vendorName: 'Modern Attire', dateOpened: '2024-07-22', reason: 'Late delivery, order was due on 2024-07-20 but arrived on 2024-07-25.', status: 'Under Review', lastUpdate: '2024-07-29', details: "Order was due on 2024-07-20, arrived on 2024-07-25. Retailer missed a sales event.", communications: [{user: "Retailer", message: "This delay cost us sales!", timestamp: "2024-07-25 14:00"}, {user: "Vendor", message: "Shipping carrier delays were unexpected.", timestamp: "2024-07-26 09:30"}] },
  { id: 'D103', orderId: 'ORD003', retailerName: 'The Trendsetter', vendorName: 'Classic Wears', dateOpened: '2024-07-15', reason: 'Damaged goods received, half of the shipment arrived with water damage.', status: 'Resolved - Retailer Favored', lastUpdate: '2024-07-20', details: "Half of the shipment arrived with water damage. Photos provided.", communications: [] },
  { id: 'D104', orderId: 'ORD004', retailerName: 'Urban Outfitters', vendorName: 'StreetStyle Kings', dateOpened: '2024-07-10', reason: 'Payment issue, retailer claimed double charge.', status: 'Closed', lastUpdate: '2024-07-18', details: "Retailer claimed double charge, resolved after bank statement review.", communications: [] },
];

// Export initialDisputes to be used by the detail page
export const getDisputeById = (id: string): Dispute | undefined => initialDisputes.find(d => d.id === id);


const StatusBadgeComponent = ({ status }: { status: DisputeStatus }) => {
  let variant: "default" | "secondary" | "destructive" | "outline" = "default";
  if (status === "Open") variant = "destructive";
  else if (status === "Under Review") variant = "secondary"; 
  else if (status.startsWith("Resolved")) variant = "default"; 
  else if (status === "Closed") variant = "outline";

  return <Badge variant={variant} className="text-xs px-1.5 py-0.5">{status}</Badge>;
};


export default function AdminDisputesPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [disputes, setDisputes] = useState<Dispute[]>(initialDisputes);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<DisputeStatus | "All">("All");

  const filteredDisputes = disputes.filter(dispute => {
    const matchesSearch = 
      dispute.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dispute.orderId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dispute.retailerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dispute.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dispute.reason.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "All" || dispute.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const disputeStatuses: (DisputeStatus | "All")[] = ["All", "Open", "Under Review", "Resolved - Retailer Favored", "Resolved - Vendor Favored", "Closed"];

  const handleResolve = (disputeId: string, resolution: "Retailer Favored" | "Vendor Favored") => {
    setDisputes(prev => 
        prev.map(d => d.id === disputeId ? {...d, status: `Resolved - ${resolution}`, lastUpdate: new Date().toISOString().split('T')[0]} : d)
    );
    toast({title: "Dispute Resolved", description: `Dispute ${disputeId} has been marked as resolved.`});
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-headline font-semibold">Dispute Resolution Center</h1>
        <Button variant="outline" size="sm" onClick={() => router.back()}>
          <ArrowLeft className="mr-1 h-3.5 w-3.5" /> Back
        </Button>
      </div>

      <Card>
        <CardHeader className="p-3">
          <CardTitle className="text-lg">Dispute Management</CardTitle>
          <CardDescription className="text-xs">Oversee and manage platform disputes.</CardDescription>
          <div className="pt-2 flex flex-col sm:flex-row gap-2">
            <div className="relative flex-grow">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
              <Input 
                placeholder="Search disputes..." 
                className="pl-8 h-8 text-xs" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={filterStatus} onValueChange={(value) => setFilterStatus(value as DisputeStatus | "All")}>
              <SelectTrigger className="w-full sm:w-auto min-w-[150px] h-8 text-xs">
                <SelectValue placeholder="Filter by Status" />
              </SelectTrigger>
              <SelectContent>
                {disputeStatuses.map(stat => <SelectItem key={stat} value={stat} className="text-xs">{stat}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="p-2 text-xs">ID</TableHead>
                <TableHead className="p-2 text-xs">Order</TableHead>
                <TableHead className="p-2 text-xs">Parties</TableHead>
                <TableHead className="p-2 text-xs">Reason</TableHead>
                <TableHead className="p-2 text-xs">Opened</TableHead>
                <TableHead className="p-2 text-xs">Status</TableHead>
                <TableHead className="p-2 text-xs text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredDisputes.length > 0 ? filteredDisputes.map((dispute) => (
                <TableRow key={dispute.id}>
                  <TableCell className="p-2 text-xs font-medium">{dispute.id}</TableCell>
                  <TableCell className="p-2 text-xs">
                    <Link href={`/admin/orders/${dispute.orderId}`} className="text-primary hover:underline">
                        {dispute.orderId}
                    </Link>
                  </TableCell>
                  <TableCell className="p-2 text-xs">
                    <p className="font-medium">{dispute.retailerName} (R)</p>
                    <p className="text-xs text-muted-foreground">vs. {dispute.vendorName} (V)</p>
                  </TableCell>
                  <TableCell className="p-2 text-xs max-w-[150px] truncate" title={dispute.reason}>{dispute.reason}</TableCell>
                  <TableCell className="p-2 text-xs">{dispute.dateOpened}</TableCell>
                  <TableCell className="p-2 text-xs">
                    <StatusBadgeComponent status={dispute.status} />
                  </TableCell>
                  <TableCell className="p-2 text-xs text-right">
                    <div className="flex gap-1 justify-end">
                      <Button variant="outline" size="xs" asChild>
                        <Link href={`/admin/disputes/${dispute.id}`}>
                          <Eye className="mr-1 h-3 w-3" /> View
                        </Link>
                      </Button>
                       {(dispute.status === 'Open' || dispute.status === 'Under Review') && (
                         <>
                          <Button variant="ghost" size="xs" onClick={() => handleResolve(dispute.id, 'Retailer Favored')} className="text-blue-600 hover:text-blue-700">
                            <ShieldCheck className="mr-1 h-3 w-3" /> R
                          </Button>
                           <Button variant="ghost" size="xs" onClick={() => handleResolve(dispute.id, 'Vendor Favored')} className="text-green-600 hover:text-green-700">
                             <ShieldCheck className="mr-1 h-3 w-3" /> V
                           </Button>
                         </>
                       )}
                       {(dispute.status !== 'Open' && dispute.status !== 'Under Review') && (
                         <Button variant="ghost" size="xs" disabled>Done</Button>
                       )}
                    </div>
                  </TableCell>
                </TableRow>
              )) : (
                 <TableRow>
                    <TableCell colSpan={7} className="text-center py-6 text-xs text-muted-foreground">
                        {searchTerm || filterStatus !== "All" ? "No disputes match criteria." : "No open disputes."}
                    </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
         <CardFooter className="border-t p-2">
            <p className="text-xs text-muted-foreground">
                Found {filteredDisputes.length} dispute(s).
            </p>
        </CardFooter>
      </Card>
    </div>
  );
}
