"use client";

import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Package, Truck, CheckCircle, XCircle, ShoppingBag, CreditCard, MapPin, FileText, UserCircle, Store, Hourglass, DollarSign, Edit } from 'lucide-react';
import { mockVendorOrderData, type VendorOrderDetail, type OrderStatusVendor as AdminOrderStatus } from '@/app/vendor/orders/mockOrderData';

type OrderStatusAdmin = AdminOrderStatus;

const StatusBadge = ({ status }: { status: OrderStatusAdmin }) => {
  let IconComponent = Package;
  let colorClasses = "bg-gray-100 text-gray-700";

  switch (status) {
    case "Pending": IconComponent = Hourglass; colorClasses = "bg-yellow-100 text-yellow-800"; break;
    case "Processing": IconComponent = Truck; colorClasses = "bg-blue-100 text-blue-800"; break;
    case "Shipped": IconComponent = Truck; colorClasses = "bg-purple-100 text-purple-800"; break;
    case "Delivered": IconComponent = CheckCircle; colorClasses = "bg-green-100 text-green-800"; break;
    case "Awaiting Payment": IconComponent = DollarSign; colorClasses = "bg-orange-100 text-orange-700"; break;
    case "Cancelled": IconComponent = XCircle; colorClasses = "bg-red-100 text-red-700"; break;
    default: IconComponent = Package;
  }

  return (
    <Badge className={`text-sm px-3 py-1.5 ${colorClasses}`}>
      <IconComponent className="h-4 w-4 mr-2" />
      {status}
    </Badge>
  );
};

const OrderItemCard = ({ item }: { item: VendorOrderDetail['items'][0] }) => (
  <Card className="overflow-hidden shadow-sm">
    <CardContent className="flex flex-col sm:flex-row items-center gap-4 p-4">
      <Image src={item.image} alt={item.name} width={80} height={100} className="rounded-md object-cover bg-muted flex-shrink-0" data-ai-hint={item.aiHint}/>
      <div className="flex-1">
        <h4 className="font-semibold text-base">{item.name}</h4>
        <p className="text-sm text-muted-foreground">SKU: {item.sku}</p>
        {item.variant && <p className="text-xs text-muted-foreground">Variant: {item.variant}</p>}
      </div>
      <div className="text-sm text-right">
        <p>{item.quantity} x ${item.unitPrice.toFixed(2)}</p>
        <p className="font-semibold text-primary">${item.totalPrice.toFixed(2)}</p>
      </div>
    </CardContent>
  </Card>
);

export default function AdminOrderDetailPage() {
  const router = useRouter();
  const params = useParams();
  const orderId = params.orderId as string;
  const { toast } = useToast();

  const [order, setOrder] = useState<VendorOrderDetail | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!orderId) return;
    const foundOrder = mockVendorOrderData.find(o => o.id === orderId);
    if (foundOrder) {
      setOrder(foundOrder);
    } else {
      toast({ title: "Order Not Found", description: "The requested order could not be found.", variant: "destructive" });
      router.back();
    }
    setIsLoading(false);
  }, [orderId, router, toast]);

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen"><p>Loading order details...</p></div>;
  }

  if (!order) {
    return null; 
  }
  
  const subtotal = order.items.reduce((sum, item) => sum + item.totalPrice, 0);
  const tax = order.totalAmount * 0.08;
  const shippingCost = (order.totalAmount - subtotal - tax > 0) ? (order.totalAmount - subtotal - tax) : 15.00;
  const vendorSlug = order.items[0]?.sku.split('-')[0].toLowerCase() || 'unknown-vendor';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={() => router.back()}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back
        </Button>
         <Button variant="outline">
            <Edit className="mr-2 h-4 w-4" /> Edit Order (Admin)
        </Button>
      </div>

      <Card>
        <CardHeader className="flex flex-col md:flex-row justify-between md:items-start gap-2">
          <div>
            <CardTitle className="text-2xl font-headline">Order Details: #{order.id}</CardTitle>
            <CardDescription>
              Placed on: {order.datePlaced}
            </CardDescription>
          </div>
          <StatusBadge status={order.status} />
        </CardHeader>
      </Card>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
            <Card>
                <CardHeader><CardTitle>Items in Order ({order.items.length})</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                {order.items.map(item => <OrderItemCard key={item.id} item={item} />)}
                </CardContent>
            </Card>

             <Card>
                <CardHeader><CardTitle>Financial Summary</CardTitle></CardHeader>
                <CardContent className="space-y-2 text-sm">
                    <div className="flex justify-between"><span>Subtotal:</span> <span>${subtotal.toFixed(2)}</span></div>
                    <div className="flex justify-between"><span>Shipping:</span> <span>${shippingCost.toFixed(2)}</span></div>
                    <div className="flex justify-between"><span>Tax (est.):</span> <span>${tax.toFixed(2)}</span></div>
                    <Separator className="my-2"/>
                    <div className="flex justify-between font-bold text-lg text-primary"><span>Grand Total:</span> <span>${order.totalAmount.toFixed(2)}</span></div>
                </CardContent>
            </Card>

        </div>
        <div className="md:col-span-1 space-y-6">
            <Card>
                <CardHeader><CardTitle>Retailer Information</CardTitle></CardHeader>
                <CardContent className="text-sm space-y-1">
                    <p className="font-semibold flex items-center"><UserCircle className="mr-2 h-4 w-4 text-muted-foreground" />{order.retailerName}</p>
                    <Link href={`/admin/users/retailers/${order.retailerName.toLowerCase().replace(/\s+/g, '-')}`} className="text-primary hover:underline text-xs">View Retailer Profile</Link>
                    <Separator className="my-2"/>
                    <h4 className="font-medium mt-2">Shipping Address:</h4>
                    <p>{order.shippingAddress.name}</p>
                    <p>{order.shippingAddress.addressLine1}</p>
                    {order.shippingAddress.addressLine2 && <p>{order.shippingAddress.addressLine2}</p>}
                    <p>{order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zip}</p>
                    <p>{order.shippingAddress.country}</p>
                    {order.shippingAddress.phone && <p>Phone: {order.shippingAddress.phone}</p>}
                </CardContent>
            </Card>
            <Card>
                <CardHeader><CardTitle>Vendor Information</CardTitle></CardHeader>
                <CardContent className="text-sm space-y-1">
                    <p className="font-semibold flex items-center"><Store className="mr-2 h-4 w-4 text-muted-foreground" />{order.vendorName}</p>
                    <Link href={`/admin/users/vendors/${vendorSlug}`} className="text-primary hover:underline text-xs">View Vendor Profile</Link>
                </CardContent>
            
             <Card>
                <CardHeader><CardTitle>Payment & Shipping</CardTitle></CardHeader>
                <CardContent className="text-sm space-y-2">
                    <p className="flex items-center"><CreditCard className="mr-2 h-4 w-4 text-muted-foreground"/>{order.paymentMethod}</p>
                    <p className="flex items-center"><Truck className="mr-2 h-4 w-4 text-muted-foreground"/>Shipping: {order.shippingMethod}</p>
                    {order.trackingNumber && (
                        <p><span className="text-muted-foreground">Tracking:</span> <a href={`https://www.google.com/search?q=${order.trackingNumber}`} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{order.trackingNumber}</a></p>
                    )}
                </CardContent>
            </Card>
            
            {order.notesToVendor && (
                <Card>
                    <CardHeader><CardTitle>Notes to Vendor</CardTitle></CardHeader>
                    <CardContent><p className="text-sm italic text-muted-foreground">"{order.notesToVendor}"</p></CardContent>
                </Card>
            )}
        </div>
      </div>
    </div>
  );
}
