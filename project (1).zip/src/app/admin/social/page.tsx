
"use client";
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Heart, MessageCircle, Send, ShieldCheck, PlayCircle, Filter, Search, CheckCircle, XCircle } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { mockSocialFeed, mockReels, type SocialPost, type SocialReel } from '@/lib/mockSocialData';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';


type ContentStatus = "Pending" | "Approved" | "Rejected";

// Badge component for status
const StatusBadge = ({ status }: { status: ContentStatus }) => {
  let variant: "default" | "secondary" | "destructive" | "outline" = "default";
  if (status === "Pending") variant = "secondary";
  else if (status === "Approved") variant = "default";
  else if (status === "Rejected") variant = "destructive";

  return <Badge variant={variant} className={`text-xs ${status === "Approved" ? "bg-green-500/10 text-green-700 border-green-500/30" : ""}`}>{status}</Badge>;
};

const SocialPostCard = ({ post, onAction }: { post: SocialPost; onAction: (postId: string, newStatus: 'Approved' | 'Rejected') => void; }) => {
  return (
    <Card className="w-full max-w-xl mx-auto">
      <CardHeader className="flex flex-row items-start justify-between gap-4 p-4">
        <div className="flex items-center gap-3">
            <Link href={`/admin/users/vendors/${post.vendorSlug}`}>
                <Avatar>
                <AvatarImage src={post.vendorAvatar} alt={post.vendorName} data-ai-hint={post.vendorAvatarAiHint}/>
                <AvatarFallback>{post.vendorName.charAt(0)}</AvatarFallback>
                </Avatar>
            </Link>
            <div>
            <Link href={`/admin/users/vendors/${post.vendorSlug}`} className="font-semibold hover:underline">
                {post.vendorName}
            </Link>
            <p className="text-xs text-muted-foreground">{post.timestamp}</p>
            </div>
        </div>
         <StatusBadge status={post.status} />
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <p className="mb-4 text-sm">{post.postText}</p>
        {post.postImage && (
          <div className="relative aspect-video w-full overflow-hidden rounded-lg border">
            <Image src={post.postImage} alt="Post image" layout="fill" objectFit="cover" data-ai-hint={post.postImageAiHint} />
          </div>
        )}
      </CardContent>
      <CardFooter className="flex flex-col items-start gap-3 p-4 border-t">
        <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1.5"><Heart className="h-4 w-4"/> {post.likes}</span>
                <span className="flex items-center gap-1.5"><MessageCircle className="h-4 w-4"/> {post.comments}</span>
            </div>
            {post.productId && (
                 <Button asChild size="sm" variant="outline">
                    <Link href={`/admin/content/products/moderation?search=${post.productId}`}>
                        <ShieldCheck className="mr-2 h-4 w-4" /> Moderate Product
                    </Link>
                </Button>
            )}
        </div>
        {(post.status === 'Pending') && (
            <div className="w-full grid grid-cols-2 gap-2 border-t pt-3">
                 <Button variant="ghost" size="sm" onClick={() => onAction(post.id, 'Approved')} className="text-green-600 hover:text-green-700">
                    <CheckCircle className="mr-1.5 h-4 w-4" /> Approve
                </Button>
                <Button variant="ghost" size="sm" onClick={() => onAction(post.id, 'Rejected')} className="text-red-600 hover:text-red-700">
                    <XCircle className="mr-1.5 h-4 w-4" /> Reject
                </Button>
            </div>
        )}
      </CardFooter>
    </Card>
  );
};


const ReelCard = ({ reel, onAction }: { reel: SocialReel; onAction: (reelId: string, newStatus: 'Approved' | 'Rejected') => void; }) => (
    <Card className="relative aspect-[9/16] w-full overflow-hidden rounded-2xl group snap-center">
        <Image 
            src={reel.reelCoverImage} 
            alt={reel.caption} 
            layout="fill" 
            objectFit="cover" 
            data-ai-hint={reel.reelCoverImageAiHint}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
        
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
             <PlayCircle className="h-20 w-20 text-white/50 opacity-70" />
        </div>

        <div className="absolute top-3 left-3">
            <StatusBadge status={reel.status} />
        </div>

        <div className="absolute bottom-4 right-2 flex flex-col items-center gap-4 text-white">
            <div className="flex flex-col items-center gap-1"><Heart className="h-7 w-7"/><span className="text-xs font-bold">{reel.likes.toLocaleString()}</span></div>
            <div className="flex flex-col items-center gap-1"><MessageCircle className="h-7 w-7"/><span className="text-xs font-bold">{reel.comments.toLocaleString()}</span></div>
            {reel.productId && (
                <Button asChild variant="ghost" className="flex flex-col h-auto p-1 gap-1 text-white hover:bg-white/20 hover:text-white" onClick={(e) => e.stopPropagation()}>
                    <Link href={`/admin/content/products/moderation?search=${reel.productId}`}>
                        <ShieldCheck className="h-7 w-7"/>
                        <span className="text-xs font-bold">Product</span>
                    </Link>
                </Button>
            )}
        </div>

        <div className="absolute bottom-0 left-0 p-4 text-white w-full">
            <Link href={`/admin/users/vendors/${reel.vendorSlug}`} onClick={(e) => e.stopPropagation()} className="block">
                <div className="flex items-center gap-2">
                    <Avatar className="h-9 w-9 border-2 border-white/80">
                      <AvatarImage src={reel.vendorAvatar} alt={reel.vendorName} data-ai-hint={reel.vendorAvatarAiHint}/>
                      <AvatarFallback>{reel.vendorName.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <p className="font-semibold text-sm hover:underline">{reel.vendorName}</p>
                </div>
            </Link>
            <p className="text-sm mt-2 line-clamp-2">{reel.caption}</p>
            {reel.status === 'Pending' && (
                <div className="w-full grid grid-cols-2 gap-2 border-t border-white/20 pt-3 mt-3">
                    <Button variant="ghost" size="sm" onClick={() => onAction(reel.id, 'Approved')} className="text-green-400 hover:text-green-300 hover:bg-white/20">Approve</Button>
                    <Button variant="ghost" size="sm" onClick={() => onAction(reel.id, 'Rejected')} className="text-red-400 hover:text-red-300 hover:bg-white/20">Reject</Button>
                </div>
            )}
        </div>
    </Card>
);

export default function AdminSocialFeedPage() {
    const { toast } = useToast();
    const [posts, setPosts] = useState<SocialPost[]>(mockSocialFeed);
    const [reels, setReels] = useState<SocialReel[]>(mockReels);
    const [filterStatus, setFilterStatus] = useState<ContentStatus | "All">("All");
    const [searchTerm, setSearchTerm] = useState('');

    const filteredPosts = posts.filter(p => {
        const matchesStatus = filterStatus === 'All' || p.status === filterStatus;
        const matchesSearch = searchTerm === '' || p.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) || p.postText.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesStatus && matchesSearch;
    });

    const filteredReels = reels.filter(r => {
        const matchesStatus = filterStatus === 'All' || r.status === filterStatus;
        const matchesSearch = searchTerm === '' || r.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) || r.caption.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesStatus && matchesSearch;
    });

    const handleAction = (id: string, newStatus: ContentStatus, type: 'post' | 'reel') => {
        if (type === 'post') {
            setPosts(prev => prev.map(item => item.id === id ? { ...item, status: newStatus } : item));
        } else {
            setReels(prev => prev.map(item => item.id === id ? { ...item, status: newStatus } : item));
        }
        toast({ title: `Content ${newStatus}`, description: `The item has been ${newStatus.toLowerCase()}.` });
    };
    
    const contentStatuses: (ContentStatus | "All")[] = ["All", "Pending", "Approved", "Rejected"];

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-headline font-semibold">Community Feed Moderation</h1>
      
      <Card>
        <CardHeader className="p-3 border-b">
            <CardTitle className="text-lg">Moderation Queue</CardTitle>
            <CardDescription className="text-xs">Review posts and reels from the community.</CardDescription>
            <div className="pt-2 flex flex-col sm:flex-row gap-2">
                <div className="relative flex-grow">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input placeholder="Search by vendor or content..." className="pl-8 h-9 text-xs" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
                </div>
                <Select value={filterStatus} onValueChange={(value) => setFilterStatus(value as ContentStatus | "All")}>
                    <SelectTrigger className="w-full sm:w-auto min-w-[160px] h-9 text-xs">
                        <SelectValue placeholder="Filter by Status" />
                    </SelectTrigger>
                    <SelectContent>
                        {contentStatuses.map(stat => <SelectItem key={stat} value={stat} className="text-xs">{stat}</SelectItem>)}
                    </SelectContent>
                </Select>
            </div>
        </CardHeader>
      </Card>

      <Tabs defaultValue="feed" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="feed">Posts</TabsTrigger>
            <TabsTrigger value="reels">Reels</TabsTrigger>
        </TabsList>
        <TabsContent value="feed" className="mt-6">
            <div className="space-y-6">
                {filteredPosts.length > 0 ? filteredPosts.map(post => (
                    <SocialPostCard key={post.id} post={post} onAction={(id, status) => handleAction(id, status, 'post')} />
                )) : <p className="text-center text-muted-foreground py-10">No posts match your criteria.</p>}
            </div>
        </TabsContent>
        <TabsContent value="reels" className="mt-6">
            <div className="max-w-md mx-auto space-y-12">
                {filteredReels.length > 0 ? filteredReels.map(reel => (
                    <ReelCard key={reel.id} reel={reel} onAction={(id, status) => handleAction(id, status, 'reel')} />
                )) : <p className="text-center text-muted-foreground py-10">No reels match your criteria.</p>}
            </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
