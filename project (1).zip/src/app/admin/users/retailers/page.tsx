
"use client";

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Eye, Search, Filter, ArrowLeft, CheckCircle, XCircle, Store } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';

type RetailerStatus = "Active" | "Pending Approval" | "Suspended";

interface Retailer {
  id: string;
  name: string;
  email: string;
  companyName: string;
  dateJoined: string;
  status: RetailerStatus;
  avatarUrl?: string;
  avatarAiHint?: string;
  totalOrders?: number;
  lastLogin?: string;
}

const initialRetailers: Retailer[] = [
  { id: 'ret001', name: 'Alice Wonderland', email: 'alice@wonderland.com', companyName: 'Wonderland Boutique', dateJoined: '2024-01-15', status: 'Active', avatarUrl: 'https://placehold.co/40x40.png?text=AW', avatarAiHint: 'person boutique', totalOrders: 25, lastLogin: '2024-07-30' },
  { id: 'ret002', name: 'Bob The Builder', email: 'bob@builder.com', companyName: 'Bob\'s Fashion Emporium', dateJoined: '2024-02-20', status: 'Active', avatarUrl: 'https://placehold.co/40x40.png?text=BB', avatarAiHint: 'man fashion', totalOrders: 15, lastLogin: '2024-07-28' },
  { id: 'ret003', name: 'Carol Danvers', email: 'carol@marvel.com', companyName: 'Captain Style', dateJoined: '2024-03-10', status: 'Suspended', avatarUrl: 'https://placehold.co/40x40.png?text=CD', avatarAiHint: 'woman hero', totalOrders: 5, lastLogin: '2024-06-01' },
  { id: 'ret004', name: 'David Copperfield', email: 'david@magic.com', companyName: 'Illusory Apparel', dateJoined: '2024-04-05', status: 'Pending Approval', avatarUrl: 'https://placehold.co/40x40.png?text=DC', avatarAiHint: 'magician style', totalOrders: 0, lastLogin: 'N/A' },
  { id: 'ret005', name: 'Eve Green', email: 'eve@garden.com', companyName: 'Eden Boutique', dateJoined: '2024-05-12', status: 'Active', avatarUrl: 'https://placehold.co/40x40.png?text=EG', avatarAiHint: 'woman nature', totalOrders: 30, lastLogin: '2024-07-29' },
  { id: 'ret006', name: 'Frank Castle', email: 'frank@punisher.net', companyName: 'Vengeance Wear', dateJoined: '2024-06-18', status: 'Active', avatarUrl: 'https://placehold.co/40x40.png?text=FC', avatarAiHint: 'man serious', totalOrders: 8, lastLogin: '2024-07-25' },
  { id: 'ret007', name: 'Grace Hopper', email: 'grace@navy.mil', companyName: 'Code & Couture', dateJoined: '2024-07-01', status: 'Pending Approval', avatarUrl: 'https://placehold.co/40x40.png?text=GH', avatarAiHint: 'woman tech', totalOrders: 0, lastLogin: 'N/A' },
];

const RetailerStatusBadge = ({ status }: { status: RetailerStatus }) => {
  let variant: "default" | "secondary" | "destructive" | "outline" = "default";
  if (status === "Pending Approval") variant = "secondary";
  else if (status === "Active") variant = "default";
  else if (status === "Suspended") variant = "destructive";

  return <Badge variant={variant} className={`text-xs ${status === "Active" ? "bg-green-500/10 text-green-700 border-green-500/30" : ""}`}>{status}</Badge>;
};

export default function AdminManageRetailersPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [retailers, setRetailers] = useState<Retailer[]>(initialRetailers);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<RetailerStatus | "All">("All");

  const filteredRetailers = retailers.filter(retailer => {
    const matchesSearch =
      retailer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      retailer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      retailer.companyName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "All" || retailer.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const retailerStatuses: (RetailerStatus | "All")[] = ["All", "Active", "Pending Approval", "Suspended"];

  const handleRetailerAction = (retailerId: string, newStatus: RetailerStatus) => {
    setRetailers(prev =>
        prev.map(r => r.id === retailerId ? {...r, status: newStatus} : r)
    );
    const retailer = retailers.find(r => r.id === retailerId);
    toast({title: `Retailer Status Updated`, description: `Retailer "${retailer?.name}" is now ${newStatus.toLowerCase()}.`});
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-headline font-semibold flex items-center">
            <Store className="mr-3 h-7 w-7 text-primary"/> Manage Retailers
        </h1>
        <Button variant="outline" size="sm" onClick={() => router.push('/admin/users')}>
          <ArrowLeft className="mr-1.5 h-3.5 w-3.5" /> Back to User Management
        </Button>
      </div>

      <Card>
        <CardHeader className="p-3 border-b">
          <CardTitle className="text-lg">Retailer Accounts</CardTitle>
          <CardDescription className="text-xs">View, manage, and moderate retailer accounts on the platform.</CardDescription>
          <div className="pt-2 flex flex-col sm:flex-row gap-2">
            <div className="relative flex-grow">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name, email, company..."
                className="pl-8 h-9 text-xs"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={filterStatus} onValueChange={(value) => setFilterStatus(value as RetailerStatus | "All")}>
              <SelectTrigger className="w-full sm:w-auto min-w-[160px] h-9 text-xs">
                <SelectValue placeholder="Filter by Status" />
              </SelectTrigger>
              <SelectContent>
                {retailerStatuses.map(stat => <SelectItem key={stat} value={stat} className="text-xs">{stat}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="p-2 text-xs">Retailer</TableHead>
                <TableHead className="p-2 text-xs">Company</TableHead>
                <TableHead className="p-2 text-xs">Joined</TableHead>
                <TableHead className="p-2 text-xs">Orders</TableHead>
                <TableHead className="p-2 text-xs">Last Login</TableHead>
                <TableHead className="p-2 text-xs text-center">Status</TableHead>
                <TableHead className="p-2 text-xs text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRetailers.length > 0 ? filteredRetailers.map((retailer) => (
                <TableRow key={retailer.id}>
                  <TableCell className="p-2 text-xs font-medium">
                    <div className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                            <AvatarImage src={retailer.avatarUrl} alt={retailer.name} data-ai-hint={retailer.avatarAiHint}/>
                            <AvatarFallback>{retailer.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                            {retailer.name}
                            <p className="text-xs text-muted-foreground">{retailer.email}</p>
                        </div>
                    </div>
                  </TableCell>
                  <TableCell className="p-2 text-xs">{retailer.companyName}</TableCell>
                  <TableCell className="p-2 text-xs">{retailer.dateJoined}</TableCell>
                  <TableCell className="p-2 text-xs">{retailer.totalOrders ?? 'N/A'}</TableCell>
                  <TableCell className="p-2 text-xs">{retailer.lastLogin ?? 'N/A'}</TableCell>
                  <TableCell className="p-2 text-xs text-center">
                    <RetailerStatusBadge status={retailer.status} />
                  </TableCell>
                  <TableCell className="p-2 text-xs text-right">
                    <div className="flex gap-1 justify-end">
                       <Button variant="outline" size="xs" asChild>
                         <Link href={`/admin/users/retailers/${retailer.id}`}>
                           <Eye className="mr-1 h-3 w-3" /> View
                         </Link>
                       </Button>
                       {retailer.status === 'Pending Approval' && (
                         <Button variant="ghost" size="xs" onClick={() => handleRetailerAction(retailer.id, 'Active')} className="text-green-600 hover:text-green-700">
                           <CheckCircle className="mr-1 h-3.5 w-3.5" /> Approve
                         </Button>
                       )}
                       {retailer.status === 'Active' && (
                         <Button variant="ghost" size="xs" onClick={() => handleRetailerAction(retailer.id, 'Suspended')} className="text-red-600 hover:text-red-700">
                           <XCircle className="mr-1 h-3.5 w-3.5" /> Suspend
                         </Button>
                       )}
                        {retailer.status === 'Suspended' && (
                         <Button variant="ghost" size="xs" onClick={() => handleRetailerAction(retailer.id, 'Active')} className="text-green-600 hover:text-green-700">
                           <CheckCircle className="mr-1 h-3.5 w-3.5" /> Activate
                         </Button>
                       )}
                    </div>
                  </TableCell>
                </TableRow>
              )) : (
                 <TableRow>
                    <TableCell colSpan={7} className="text-center py-6 text-xs text-muted-foreground">
                        {searchTerm || filterStatus !== "All" ? "No retailers match your criteria." : "No retailers found."}
                    </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
         <CardFooter className="border-t p-2">
            <p className="text-xs text-muted-foreground">
                Found {filteredRetailers.length} retailer(s).
            </p>
        </CardFooter>
      </Card>
    </div>
  );
}


