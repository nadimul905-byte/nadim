
"use client";

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, UserCheck, Shield, Store, ArrowRight, Briefcase } from 'lucide-react'; // Added Briefcase
import Link from 'next/link';
import { Badge } from "@/components/ui/badge";

interface UserSectionCardProps {
  title: string;
  description: string;
  link: string;
  icon: React.ElementType;
  count?: number;
  countLabel?: string;
  actionText?: string;
}

const UserSectionCard: React.FC<UserSectionCardProps> = ({ title, description, link, icon: Icon, count, countLabel, actionText = "Manage" }) => (
  <Card className="hover:shadow-lg transition-shadow">
    <CardHeader className="pb-4">
      <div className="flex items-center justify-between">
        <CardTitle className="text-xl font-semibold flex items-center">
          <Icon className="mr-3 h-6 w-6 text-primary" />
          {title}
        </CardTitle>
        {count !== undefined && countLabel && (
          <Badge variant="secondary" className="text-sm px-3 py-1">{count} {countLabel}</Badge>
        )}
      </div>
    </CardHeader>
    <CardContent>
      <p className="text-sm text-muted-foreground mb-4 min-h-[40px]">{description}</p>
      <Button asChild variant="outline" className="w-full">
        <Link href={link}>
          {actionText} {title} <ArrowRight className="ml-2 h-4 w-4" />
        </Link>
      </Button>
    </CardContent>
  </Card>
);

export default function AdminUserManagementPage() {
  // These counts would ideally come from a backend/database
  const totalRetailers = 1250;
  const totalVendors = 350;
  const pendingVendorApprovals = 5; // From Admin Dashboard example
  const totalAdmins = 5;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-headline font-semibold flex items-center">
          <Users className="mr-3 h-8 w-8 text-primary" /> User Management
        </h1>
      </div>

      <Card>
        <CardHeader>
            <CardTitle>User Roles Overview</CardTitle>
            <CardDescription>Manage all user accounts, roles, and permissions across the platform.</CardDescription>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <UserSectionCard
                title="Retailers"
                description="View, edit, and manage retailer accounts on the platform."
                link="/admin/users/retailers" // Placeholder link
                icon={Store}
                count={totalRetailers}
                countLabel="Active"
            />
            <UserSectionCard
                title="Vendors"
                description="Oversee vendor accounts, profiles, and product listings."
                link="/admin/users/vendors" // Placeholder link
                icon={Briefcase}
                count={totalVendors}
                countLabel="Active"
            />
            <UserSectionCard
                title="Vendor Approvals"
                description="Review and approve or reject new vendor applications."
                link="/admin/users/vendors/approvals" // Existing link
                icon={UserCheck}
                count={pendingVendorApprovals}
                countLabel="Pending"
                actionText="Review"
            />
            <UserSectionCard
                title="Administrators"
                description="Manage administrator accounts and platform-wide permissions."
                link="/admin/users/admins" // Placeholder link
                icon={Shield}
                count={totalAdmins}
                countLabel="Active"
            />
        </CardContent>
      </Card>

       <Card>
        <CardHeader>
            <CardTitle>User Activity & Security</CardTitle>
            <CardDescription>Monitor user activity logs, manage security settings, and handle account issues.</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-4">
            <Button variant="outline" asChild>
                <Link href="/admin/users/activity-log"> {/* Placeholder link */}
                    View Activity Log
                </Link>
            </Button>
            <Button variant="outline" asChild>
                <Link href="/admin/users/permissions"> {/* Placeholder link */}
                    Manage Roles & Permissions
                </Link>
            </Button>
             <Button variant="destructive" asChild>
                <Link href="/admin/users/banned"> {/* Placeholder link */}
                    View Banned Users
                </Link>
            </Button>
        </CardContent>
      </Card>
    </div>
  );
}


