
"use client";
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent } from "@/components/ui/chart";
import { BarChart, CartesianGrid, XAxis, YAxis, Bar, Tooltip as RechartsTooltip, Legend as RechartsLegend, Cell, PieChart, Pie } from 'recharts';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

// Re-using mock data from the main reports page
const salesOverviewData = [
  { name: 'Q1 Sales', value: 120000, year: 2024 },
  { name: 'Q2 Sales', value: 150000, year: 2024 },
  { name: 'Q3 Sales', value: 135000, year: 2024 },
  { name: 'Q4 Sales (Est.)', value: 160000, year: 2024 },
  { name: 'Q1 Sales', value: 110000, year: 2023 }, // Added previous year data
  { name: 'Q2 Sales', value: 140000, year: 2023 },
  { name: 'Q3 Sales', value: 125000, year: 2023 },
  { name: 'Q4 Sales', value: 155000, year: 2023 },
];
const salesCOLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))', 'hsl(var(--primary))', 'hsl(var(--accent))', 'hsl(var(--secondary))'];


const chartConfigSales = {
  value: { label: "Sales ($)" },
};

export default function SalesOverviewDetailsPage() {
  const currentYearData = salesOverviewData.filter(d => d.year === 2024);
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-headline font-semibold">Detailed Sales Overview</h1>
        <Button variant="outline" asChild>
          <Link href="/admin/reports">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Reports
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Quarterly Sales Performance ({currentYearData[0].year})</CardTitle>
          <CardDescription>Gross Merchandise Volume (GMV) per quarter for the current year.</CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center">
            <ChartContainer config={chartConfigSales} className="h-[350px] w-full aspect-square">
              <PieChart>
                <RechartsTooltip content={<ChartTooltipContent hideLabel formatter={(value) => `$${Number(value).toLocaleString()}`} />} />
                <Pie data={currentYearData} dataKey="value" nameKey="name" labelLine={false} label={({name, percent}) => `${name} (${(percent * 100).toFixed(0)}%)`}>
                    {currentYearData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={salesCOLORS[index % salesCOLORS.length]} />
                    ))}
                </Pie>
                <RechartsLegend content={<ChartLegendContent nameKey="name" />} />
              </PieChart>
            </ChartContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
            <CardTitle>Sales Data Table (All Years)</CardTitle>
            <CardDescription>Tabular representation of quarterly sales data.</CardDescription>
        </CardHeader>
        <CardContent>
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Year</TableHead>
                        <TableHead>Quarter</TableHead>
                        <TableHead className="text-right">Revenue ($)</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {salesOverviewData.map((data, index) => (
                        <TableRow key={index}>
                            <TableCell>{data.year}</TableCell>
                            <TableCell className="font-medium">{data.name.replace(' Sales', '').replace(' (Est.)', ' Est.')}</TableCell>
                            <TableCell className="text-right">${data.value.toLocaleString()}</TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </CardContent>
      </Card>
    </div>
  );
}
