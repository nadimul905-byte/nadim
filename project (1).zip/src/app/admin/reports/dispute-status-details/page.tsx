
"use client";
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent } from "@/components/ui/chart";
import { BarChart, CartesianGrid, XAxis, YAxis, Bar, Tooltip as RechartsTooltip, Legend as RechartsLegend, Cell, PieChart, Pie } from 'recharts';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

// Re-using mock data from the main reports page
const disputeStatusData = [
  { name: 'Open', value: 15, fill: 'hsl(var(--chart-1))', description: "Disputes actively being investigated or awaiting initial response." },
  { name: 'Resolved', value: 120, fill: 'hsl(var(--chart-2))', description: "Disputes that have reached a final resolution." },
  { name: 'Under Review', value: 25, fill: 'hsl(var(--chart-3))', description: "Disputes currently under active review by admin team." },
  { name: 'Closed', value: 60, fill: 'hsl(var(--chart-4))', description: "Disputes closed after resolution or other reasons." }, // Added more data
  { name: 'Awaiting User Response', value: 10, fill: 'hsl(var(--chart-5))', description: "Disputes pending information from involved parties." },
];

const chartConfigDisputes = {
  value: { label: "Disputes" },
};

export default function DisputeStatusDetailsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-headline font-semibold">Detailed Dispute Status</h1>
        <Button variant="outline" asChild>
          <Link href="/admin/reports">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Reports
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Dispute Status Distribution</CardTitle>
          <CardDescription>Breakdown of all platform disputes by their current status.</CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center">
             <ChartContainer config={chartConfigDisputes} className="h-[350px] w-full aspect-square">
                <PieChart>
                <RechartsTooltip content={<ChartTooltipContent hideLabel />} />
                <Pie data={disputeStatusData} dataKey="value" nameKey="name" label={({name, percent}) => `${name} (${(percent * 100).toFixed(0)}%)`}>
                    {disputeStatusData.map((entry) => (
                        <Cell key={`cell-${entry.name}`} fill={entry.fill} />
                    ))}
                </Pie>
                <RechartsLegend content={<ChartLegendContent nameKey="name" />} />
                </PieChart>
            </ChartContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
            <CardTitle>Dispute Status Data Table</CardTitle>
            <CardDescription>Tabular representation of dispute counts by status.</CardDescription>
        </CardHeader>
        <CardContent>
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Count</TableHead>
                        <TableHead>Description</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {disputeStatusData.map((data) => (
                        <TableRow key={data.name}>
                            <TableCell className="font-medium">{data.name}</TableCell>
                            <TableCell className="text-right">{data.value}</TableCell>
                            <TableCell className="text-xs text-muted-foreground">{data.description}</TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </CardContent>
      </Card>
    </div>
  );
}
