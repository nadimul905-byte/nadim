
"use client";
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent } from "@/components/ui/chart";
import { LineChart, CartesianGrid, XAxis, YAxis, Line, Tooltip as RechartsTooltip, Legend as RechartsLegend } from 'recharts';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

// Re-using mock data from the main reports page and expanding it
const platformActivityData = [
    { date: '2024-07-01', listings: 150, customRequests: 20 },
    { date: '2024-07-08', listings: 120, customRequests: 15 },
    { date: '2024-07-15', listings: 180, customRequests: 25 },
    { date: '2024-07-22', listings: 160, customRequests: 18 },
    { date: '2024-07-29', listings: 200, customRequests: 30 },
    { date: '2024-08-05', listings: 210, customRequests: 35 }, // Added more data
    { date: '2024-08-12', listings: 190, customRequests: 28 },
];

const chartConfigActivity = {
  listings: { label: "New Listings", color: "hsl(var(--chart-4))" },
  customRequests: { label: "Custom Requests", color: "hsl(var(--chart-5))" },
};

export default function PlatformActivityDetailsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-headline font-semibold">Detailed Platform Activity</h1>
        <Button variant="outline" asChild>
          <Link href="/admin/reports">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Reports
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Platform Activity Trends</CardTitle>
          <CardDescription>Weekly new product listings and custom design requests.</CardDescription>
        </CardHeader>
        <CardContent>
             <ChartContainer config={chartConfigActivity} className="h-[400px] w-full">
                <LineChart data={platformActivityData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}/>
                    <YAxis />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <ChartLegend content={<ChartLegendContent />} />
                    <Line type="monotone" dataKey="listings" stroke="var(--color-listings)" strokeWidth={2} dot={{r:4}} activeDot={{r:6}}/>
                    <Line type="monotone" dataKey="customRequests" stroke="var(--color-customRequests)" strokeWidth={2} dot={{r:4}} activeDot={{r:6}} />
                </LineChart>
            </ChartContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
            <CardTitle>Platform Activity Data Table</CardTitle>
            <CardDescription>Tabular representation of weekly platform activity.</CardDescription>
        </CardHeader>
        <CardContent>
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Week Ending</TableHead>
                        <TableHead className="text-right">New Listings</TableHead>
                        <TableHead className="text-right">Custom Requests</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {platformActivityData.map((data) => (
                        <TableRow key={data.date}>
                            <TableCell className="font-medium">{new Date(data.date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}</TableCell>
                            <TableCell className="text-right">{data.listings}</TableCell>
                            <TableCell className="text-right">{data.customRequests}</TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </CardContent>
      </Card>
    </div>
  );
}
