
"use client";
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent } from "@/components/ui/chart";
import { BarChart, CartesianGrid, XAxis, YAxis, Bar } from 'recharts';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

// Re-using mock data from the main reports page
const userGrowthData = [
  { month: 'Jan', newRetailers: 50, newVendors: 20, totalNew: 70 },
  { month: 'Feb', newRetailers: 60, newVendors: 25, totalNew: 85 },
  { month: 'Mar', newRetailers: 75, newVendors: 30, totalNew: 105 },
  { month: 'Apr', newRetailers: 80, newVendors: 35, totalNew: 115 },
  { month: 'May', newRetailers: 95, newVendors: 40, totalNew: 135 },
  { month: 'Jun', newRetailers: 110, newVendors: 45, totalNew: 155 },
  { month: 'Jul', newRetailers: 120, newVendors: 50, totalNew: 170 }, // Added more data
  { month: 'Aug', newRetailers: 130, newVendors: 55, totalNew: 185 },
];

const chartConfigUsers = {
  newRetailers: { label: "New Retailers", color: "hsl(var(--chart-1))" },
  newVendors: { label: "New Vendors", color: "hsl(var(--chart-2))" },
};

export default function UserGrowthDetailsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-headline font-semibold">Detailed User Growth</h1>
        <Button variant="outline" asChild>
          <Link href="/admin/reports">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Reports
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>User Growth Over Time</CardTitle>
          <CardDescription>Monthly breakdown of new retailer and vendor sign-ups.</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfigUsers} className="h-[400px] w-full">
            <BarChart data={userGrowthData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <ChartTooltip content={<ChartTooltipContent />} />
              <ChartLegend content={<ChartLegendContent />} />
              <Bar dataKey="newRetailers" fill="var(--color-newRetailers)" radius={4} name="New Retailers" />
              <Bar dataKey="newVendors" fill="var(--color-newVendors)" radius={4} name="New Vendors" />
            </BarChart>
          </ChartContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
            <CardTitle>User Growth Data Table</CardTitle>
            <CardDescription>Tabular representation of new user sign-ups.</CardDescription>
        </CardHeader>
        <CardContent>
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Month</TableHead>
                        <TableHead className="text-right">New Retailers</TableHead>
                        <TableHead className="text-right">New Vendors</TableHead>
                        <TableHead className="text-right">Total New Users</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {userGrowthData.map((data) => (
                        <TableRow key={data.month}>
                            <TableCell className="font-medium">{data.month}</TableCell>
                            <TableCell className="text-right">{data.newRetailers}</TableCell>
                            <TableCell className="text-right">{data.newVendors}</TableCell>
                            <TableCell className="text-right">{data.totalNew}</TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </CardContent>
      </Card>
    </div>
  );
}
