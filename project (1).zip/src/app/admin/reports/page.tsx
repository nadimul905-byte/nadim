
"use client";

import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { ArrowLeft, Users, DollarSign, Package, ShoppingBag, AlertTriangle, BarChart3, ListFilter, Download, ArrowRight } from 'lucide-react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent } from "@/components/ui/chart";
import { BarChart, LineChart, PieChart, Bar, Line, Pie, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend as RechartsLegend, ResponsiveContainer, Cell } from 'recharts';

const userGrowthData = [
  { month: 'Jan', newRetailers: 50, newVendors: 20 },
  { month: 'Feb', newRetailers: 60, newVendors: 25 },
  { month: 'Mar', newRetailers: 75, newVendors: 30 },
  { month: 'Apr', newRetailers: 80, newVendors: 35 },
  { month: 'May', newRetailers: 95, newVendors: 40 },
  { month: 'Jun', newRetailers: 110, newVendors: 45 },
];

const salesOverviewData = [
  { name: 'Q1 Sales', value: 120000 },
  { name: 'Q2 Sales', value: 150000 },
  { name: 'Q3 Sales', value: 135000 },
  { name: 'Q4 Sales (Est.)', value: 160000 },
];
const salesCOLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))'];


const disputeStatusData = [
  { name: 'Open', value: 15, fill: 'hsl(var(--chart-1))' },
  { name: 'Resolved', value: 120, fill: 'hsl(var(--chart-2))' },
  { name: 'Under Review', value: 25, fill: 'hsl(var(--chart-3))' },
];

const platformActivityData = [
    { date: '2024-07-01', listings: 150, customRequests: 20 },
    { date: '2024-07-08', listings: 120, customRequests: 15 },
    { date: '2024-07-15', listings: 180, customRequests: 25 },
    { date: '2024-07-22', listings: 160, customRequests: 18 },
    { date: '2024-07-29', listings: 200, customRequests: 30 },
];

const chartConfigUsers = {
  newRetailers: { label: "New Retailers", color: "hsl(var(--chart-1))" },
  newVendors: { label: "New Vendors", color: "hsl(var(--chart-2))" },
};
const chartConfigSales = {
  value: { label: "Sales ($)" },
};
const chartConfigDisputes = {
  value: { label: "Disputes" },
};
const chartConfigActivity = {
  listings: { label: "New Listings", color: "hsl(var(--chart-4))" },
  customRequests: { label: "Custom Requests", color: "hsl(var(--chart-5))" },
};


export default function AdminReportsPage() {
  const router = useRouter();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
             <Button variant="outline" size="icon" onClick={() => router.back()} aria-label="Back">
                <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-3xl font-headline font-semibold flex items-center">
                <BarChart3 className="mr-3 h-8 w-8 text-primary"/> Platform Reports
            </h1>
        </div>
        <div className="flex items-center gap-2">
            <Button variant="outline"><ListFilter className="mr-2 h-4 w-4"/>Filter by Date</Button>
            <Button><Download className="mr-2 h-4 w-4"/>Download Reports</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
            <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Total Users</CardTitle></CardHeader>
            <CardContent><div className="text-2xl font-bold">1,234</div><p className="text-xs text-muted-foreground">+150 this month</p></CardContent>
        </Card>
        <Card>
            <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Total GMV</CardTitle></CardHeader>
            <CardContent><div className="text-2xl font-bold">$1.25M</div><p className="text-xs text-muted-foreground">+5.2% this quarter</p></CardContent>
        </Card>
        <Card>
            <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Active Listings</CardTitle></CardHeader>
            <CardContent><div className="text-2xl font-bold">5,678</div><p className="text-xs text-muted-foreground">+200 new today</p></CardContent>
        </Card>
         <Card>
            <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Resolved Disputes</CardTitle></CardHeader>
            <CardContent><div className="text-2xl font-bold">120</div><p className="text-xs text-muted-foreground">85% success rate</p></CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>User Growth</CardTitle>
            <CardDescription>New Retailers vs. New Vendors Over Time</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer config={chartConfigUsers} className="h-[300px] w-full">
              <BarChart data={userGrowthData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <RechartsTooltip content={<ChartTooltipContent />} />
                <RechartsLegend content={<ChartLegendContent />} />
                <Bar dataKey="newRetailers" fill="var(--color-newRetailers)" radius={4} />
                <Bar dataKey="newVendors" fill="var(--color-newVendors)" radius={4} />
              </BarChart>
            </ChartContainer>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button variant="outline" size="sm" asChild>
              <Link href="/admin/reports/user-growth-details">
                See Details <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Sales Overview (Quarterly)</CardTitle>
            <CardDescription>Gross Merchandise Volume per Quarter</CardDescription>
          </CardHeader>
          <CardContent className="flex items-center justify-center">
            <ChartContainer config={chartConfigSales} className="h-[300px] w-full aspect-square">
              <PieChart>
                <RechartsTooltip content={<ChartTooltipContent hideLabel formatter={(value) => `$${Number(value).toLocaleString()}`} />} />
                <Pie data={salesOverviewData} dataKey="value" nameKey="name" labelLine={false} label={({name, percent}) => `${name} (${(percent * 100).toFixed(0)}%)`}>
                    {salesOverviewData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={salesCOLORS[index % salesCOLORS.length]} />
                    ))}
                </Pie>
                <RechartsLegend content={<ChartLegendContent nameKey="name" />} />
              </PieChart>
            </ChartContainer>
          </CardContent>
           <CardFooter className="flex justify-end">
            <Button variant="outline" size="sm" asChild>
              <Link href="/admin/reports/sales-overview-details">
                See Details <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Dispute Status Distribution</CardTitle>
            <CardDescription>Current status of all platform disputes.</CardDescription>
          </CardHeader>
          <CardContent className="flex items-center justify-center">
             <ChartContainer config={chartConfigDisputes} className="h-[300px] w-full aspect-square">
                <PieChart>
                <RechartsTooltip content={<ChartTooltipContent hideLabel />} />
                <Pie data={disputeStatusData} dataKey="value" nameKey="name" label={({name, percent}) => `${name} (${(percent * 100).toFixed(0)}%)`}>
                    {disputeStatusData.map((entry) => (
                        <Cell key={`cell-${entry.name}`} fill={entry.fill} />
                    ))}
                </Pie>
                <RechartsLegend content={<ChartLegendContent nameKey="name" />} />
                </PieChart>
            </ChartContainer>
          </CardContent>
           <CardFooter className="flex justify-end">
            <Button variant="outline" size="sm" asChild>
              <Link href="/admin/reports/dispute-status-details">
                See Details <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardFooter>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Platform Activity Trends</CardTitle>
            <CardDescription>New Product Listings and Custom Design Requests per week.</CardDescription>
          </CardHeader>
          <CardContent>
             <ChartContainer config={chartConfigActivity} className="h-[300px] w-full">
                <LineChart data={platformActivityData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}/>
                    <YAxis />
                    <RechartsTooltip content={<ChartTooltipContent />} />
                    <RechartsLegend content={<ChartLegendContent />} />
                    <Line type="monotone" dataKey="listings" stroke="var(--color-listings)" strokeWidth={2} dot={{r:4}}/>
                    <Line type="monotone" dataKey="customRequests" stroke="var(--color-customRequests)" strokeWidth={2} dot={{r:4}} />
                </LineChart>
            </ChartContainer>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button variant="outline" size="sm" asChild>
              <Link href="/admin/reports/platform-activity-details">
                See Details <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}

