
"use client";

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { ArrowLeft, Save, BarChartHorizontalBig, AlertTriangle, Loader2 } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import Link from 'next/link';

export default function GoogleAnalyticsIntegrationPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [trackingId, setTrackingId] = useState('G-**********'); // Partially masked
  const [enableEnhancedEcommerce, setEnableEnhancedEcommerce] = useState(true);
  const [anonymizeIp, setAnonymizeIp] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  const handleSaveChanges = async () => {
    setIsSaving(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    toast({
      title: "Google Analytics Settings Saved",
      description: "Your Google Analytics integration settings have been updated (mocked).",
    });
    console.log({ trackingId, enableEnhancedEcommerce, anonymizeIp });
    setIsSaving(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-headline font-semibold flex items-center">
          <BarChartHorizontalBig className="mr-3 h-7 w-7 text-primary" /> Google Analytics Integration
        </h1>
        <Button variant="outline" size="sm" asChild>
          <Link href="/admin/integrations">
            <ArrowLeft className="mr-1.5 h-3.5 w-3.5" /> Back to Integrations
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Google Analytics Configuration</CardTitle>
          <CardDescription>Set up your Google Analytics tracking ID and other preferences.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-md flex items-start">
            <AlertTriangle className="h-5 w-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
            <p className="text-sm text-blue-700">
              Ensure your Google Analytics property is set up correctly and that you are using the Measurement ID (e.g., G-XXXXXXXXXX).
            </p>
          </div>
          <div>
            <Label htmlFor="trackingId">Google Analytics Measurement ID</Label>
            <Input id="trackingId" value={trackingId} onChange={(e) => setTrackingId(e.target.value)} placeholder="G-XXXXXXXXXX" />
          </div>
          <div className="flex items-center space-x-2">
            <Switch id="enhancedEcommerce" checked={enableEnhancedEcommerce} onCheckedChange={setEnableEnhancedEcommerce} />
            <Label htmlFor="enhancedEcommerce">Enable Enhanced Ecommerce Tracking</Label>
          </div>
          <div className="flex items-center space-x-2">
            <Switch id="anonymizeIp" checked={anonymizeIp} onCheckedChange={setAnonymizeIp} />
            <Label htmlFor="anonymizeIp">Anonymize IP Addresses</Label>
          </div>
        </CardContent>
        <CardFooter className="border-t pt-6">
          <Button onClick={handleSaveChanges} disabled={isSaving}>
            {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            Save GA Settings
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
