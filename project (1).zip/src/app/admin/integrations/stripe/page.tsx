
"use client";

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { ArrowLeft, Save, CreditCard, AlertTriangle, Loader2 } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import Link from 'next/link';

export default function StripeIntegrationPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [apiKey, setApiKey] = useState('sk_test_************************'); // Partially masked
  const [webhookSecret, setWebhookSecret] = useState('whsec_************************'); // Partially masked
  const [isLiveMode, setIsLiveMode] = useState(false);
  const [enableAutomaticTax, setEnableAutomaticTax] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  const handleSaveChanges = async () => {
    setIsSaving(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    toast({
      title: "Stripe Settings Saved",
      description: "Your Stripe integration settings have been updated (mocked).",
    });
    console.log({ apiKey, webhookSecret, isLiveMode, enableAutomaticTax });
    setIsSaving(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-headline font-semibold flex items-center">
          <CreditCard className="mr-3 h-7 w-7 text-primary" /> Stripe Integration
        </h1>
        <Button variant="outline" size="sm" asChild>
          <Link href="/admin/integrations">
            <ArrowLeft className="mr-1.5 h-3.5 w-3.5" /> Back to Integrations
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Stripe Configuration</CardTitle>
          <CardDescription>Manage your Stripe API keys and settings for payment processing.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-md flex items-start">
            <AlertTriangle className="h-5 w-5 text-yellow-600 mr-3 mt-0.5 flex-shrink-0" />
            <p className="text-sm text-yellow-700">
              <strong>Warning:</strong> Modifying API keys can affect your payment processing. Ensure you are using the correct keys for your environment.
            </p>
          </div>
          <div>
            <Label htmlFor="apiKey">Stripe API Key (Secret)</Label>
            <Input id="apiKey" type="password" value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder="sk_test_..." />
          </div>
          <div>
            <Label htmlFor="webhookSecret">Stripe Webhook Signing Secret</Label>
            <Input id="webhookSecret" type="password" value={webhookSecret} onChange={(e) => setWebhookSecret(e.target.value)} placeholder="whsec_..." />
          </div>
          <div className="flex items-center space-x-2">
            <Switch id="liveMode" checked={isLiveMode} onCheckedChange={setIsLiveMode} />
            <Label htmlFor="liveMode">Enable Live Mode</Label>
          </div>
           <div className="flex items-center space-x-2">
            <Switch id="automaticTax" checked={enableAutomaticTax} onCheckedChange={setEnableAutomaticTax} />
            <Label htmlFor="automaticTax">Enable Stripe Tax (Automatic Tax Calculation)</Label>
          </div>
        </CardContent>
        <CardFooter className="border-t pt-6">
          <Button onClick={handleSaveChanges} disabled={isSaving}>
            {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            Save Stripe Settings
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
