
"use client";

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { ArrowLeft, Zap, Settings, MessageCircle, CreditCard, Truck, BarChartHorizontalBig, Palette, ShieldCheck } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';

interface Integration {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  status: 'Connected' | 'Disconnected' | 'Requires Attention';
  category: 'Payment' | 'Shipping' | 'Analytics' | 'Communication' | 'Security' | 'Design';
  manageLink?: string;
}

const initialIntegrations: Integration[] = [
  { id: 'stripe', name: 'Stripe', description: 'Payment processing for online transactions.', icon: CreditCard, status: 'Connected', category: 'Payment', manageLink: '/admin/integrations/stripe' },
  { id: 'sendgrid', name: 'SendGrid', description: 'Email delivery service for notifications and marketing.', icon: MessageCircle, status: 'Connected', category: 'Communication' },
  { id: 'shippo', name: 'Shippo', description: 'Multi-carrier shipping API.', icon: Truck, status: 'Disconnected', category: 'Shipping' },
  { id: 'google-analytics', name: 'Google Analytics', description: 'Track website traffic and user behavior.', icon: BarChartHorizontalBig, status: 'Connected', category: 'Analytics', manageLink: '/admin/integrations/google-analytics' },
  { id: 'unsplash', name: 'Unsplash', description: 'Access to free high-quality images.', icon: Palette, status: 'Connected', category: 'Design' },
  { id: 'auth0', name: 'Auth0', description: 'Identity and access management.', icon: ShieldCheck, status: 'Requires Attention', category: 'Security' },
];

const IntegrationStatusBadge = ({ status }: { status: Integration['status'] }) => {
  let variant: "default" | "secondary" | "destructive" | "outline" = "secondary";
  if (status === "Connected") variant = "default";
  else if (status === "Requires Attention") variant = "destructive";
  else if (status === "Disconnected") variant = "outline";

  return <Badge variant={variant} className={`text-xs ${status === "Connected" ? "bg-green-500/10 text-green-700 border-green-500/30" : ""}`}>{status}</Badge>;
}

export default function AdminIntegrationsPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [integrations, setIntegrations] = useState<Integration[]>(initialIntegrations);

  const handleToggleIntegration = (id: string) => {
    setIntegrations(prev => 
      prev.map(int => 
        int.id === id ? { ...int, status: int.status === 'Connected' ? 'Disconnected' : 'Connected' } : int
      )
    );
    const integration = integrations.find(int => int.id === id);
    toast({
      title: `Integration ${integration?.status === 'Connected' ? 'Disconnected' : 'Connected'}`,
      description: `${integration?.name} has been ${integration?.status === 'Connected' ? 'disconnected' : 'connected'}. (Mocked)`,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-headline font-semibold flex items-center">
          <Zap className="mr-3 h-8 w-8 text-primary" /> Third-Party Integrations
        </h1>
        <Button variant="outline" size="sm" onClick={() => router.back()}>
          <ArrowLeft className="mr-1.5 h-3.5 w-3.5" /> Back
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Manage Connected Services</CardTitle>
          <CardDescription>
            Connect and configure third-party services to extend platform functionality.
          </CardDescription>
        </CardHeader>
        <CardContent className="divide-y divide-border p-0">
          {integrations.map((integration) => {
            const Icon = integration.icon;
            return (
              <div key={integration.id} className="p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between hover:bg-muted/50 transition-colors">
                <div className="flex items-start gap-4 mb-3 sm:mb-0">
                  <Icon className="h-8 w-8 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold">{integration.name} <IntegrationStatusBadge status={integration.status}/></h3>
                    <p className="text-sm text-muted-foreground">{integration.description}</p>
                    <Badge variant="outline" className="mt-1 text-xs">{integration.category}</Badge>
                  </div>
                </div>
                <div className="flex items-center gap-2 self-end sm:self-center">
                  <Switch
                    checked={integration.status === 'Connected'}
                    onCheckedChange={() => handleToggleIntegration(integration.id)}
                    id={`switch-${integration.id}`}
                  />
                  {integration.manageLink ? (
                    <Button variant="outline" size="sm" asChild>
                      <Link href={integration.manageLink}>
                        <Settings className="mr-1.5 h-3.5 w-3.5" /> Manage
                      </Link>
                    </Button>
                  ) : (
                    <Button variant="outline" size="sm" disabled>
                       <Settings className="mr-1.5 h-3.5 w-3.5" /> Configure
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </CardContent>
        <CardFooter className="p-4 border-t">
            <p className="text-xs text-muted-foreground">
                Found {integrations.length} integration(s). Some integrations may require additional setup.
            </p>
        </CardFooter>
      </Card>
    </div>
  );
}
