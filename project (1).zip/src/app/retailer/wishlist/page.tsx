
"use client";
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Heart, ShoppingCart, Trash2, PackageOpen, ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import { useRouter } from 'next/navigation'; // Import useRouter

interface WishlistItem {
  id: string;
  productId: string; 
  name: string;
  price: string;
  image: string;
  aiHint: string;
  vendorName: string;
  dateAdded: string;
  stockStatus: "In Stock" | "Low Stock" | "Out of Stock";
}

// Mock data for wishlist items
const initialWishlistItems: WishlistItem[] = [
  { 
    id: 'wish1', 
    productId: 'trend1', 
    name: 'Elegant Evening Gown', 
    price: '$129.99', 
    image: 'https://images.unsplash.com/photo-1562292817-58d294c3a7e3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw4fHxldmVuaW5nJTIwZ293bnxlbnwwfHx8fDE3NDkxMjUyMTh8MA&ixlib=rb-4.1.0&q=80&w=1080', 
    aiHint: 'evening gown', 
    vendorName: 'Glamour Wear', 
    dateAdded: '2024-07-20',
    stockStatus: "In Stock"
  },
  { 
    id: 'wish2', 
    productId: 'new2', 
    name: 'Vintage Graphic Tee', 
    price: '$34.99', 
    image: 'https://images.unsplash.com/photo-1621446510984-2c854aafd6c0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxMHx8Z3JhcGhpYyUyMHRlZXxlbnwwfHx8fDE3NDkxMjY2NjF8MA&ixlib.rb-4.1.0&q=80&w=1080', 
    aiHint: 'graphic tee', 
    vendorName: 'Retro Threads', 
    dateAdded: '2024-07-15',
    stockStatus: "Low Stock"
  },
  { 
    id: 'wish3', 
    productId: 'view2', 
    name: 'Leather Ankle Boots', 
    price: '$129.99', 
    image: 'https://images.unsplash.com/photo-1516762689617-e1cffcef479d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw4fHxhbmtsZSUyMGJvb3RzfGVufDB8fHx8MTc0OTEyNjY2MXww&ixlib.rb-4.1.0&q=80&w=1080', 
    aiHint: 'ankle boots', 
    vendorName: 'Step Right', 
    dateAdded: '2024-07-10',
    stockStatus: "Out of Stock"
  },
];

const StockStatusBadge = ({ status }: { status: WishlistItem['stockStatus']}) => {
  let variant: "default" | "secondary" | "destructive" | "outline" = "default";
  if (status === "Low Stock") variant = "destructive"; // Use destructive for low stock for visibility
  if (status === "Out of Stock") variant = "outline";
  
  return <Badge variant={variant} className="text-xs">{status}</Badge>;
}


export default function RetailerWishlistPage() {
  const { toast } = useToast();
  const router = useRouter(); // Initialize useRouter
  const [wishlistItems, setWishlistItems] = useState<WishlistItem[]>(initialWishlistItems);

  const handleRemoveFromWishlist = (itemId: string, itemName: string) => {
    setWishlistItems(prevItems => prevItems.filter(item => item.id !== itemId));
    toast({
      title: "Removed from Wishlist",
      description: `${itemName} has been removed from your wishlist.`,
    });
  };

  const handleAddToCart = (itemName: string) => {
    toast({
      title: "Added to Cart",
      description: `${itemName} has been added to your cart. (Mock action)`,
    });
  }

  if (wishlistItems.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <Heart className="w-24 h-24 text-muted-foreground mb-6" />
        <h2 className="text-2xl font-semibold mb-2">Your wishlist is empty</h2>
        <p className="text-muted-foreground mb-6">Start adding products you love!</p>
        <Button asChild size="lg">
          <Link href="/retailer">Browse Products</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-headline font-semibold">My Wishlist ({wishlistItems.length})</h1>
        <Button variant="outline" onClick={() => router.back()}>
            <ArrowLeft className="mr-2 h-4 w-4"/> Back
        </Button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {wishlistItems.map(item => (
          <Card key={item.id} className="overflow-hidden flex flex-col">
            <CardHeader className="p-0 relative">
                <Link href={`/retailer/products/${item.productId}`} className="block">
                    <div className="aspect-[4/3] w-full relative bg-muted">
                        <Image src={item.image} alt={item.name} layout="fill" objectFit="cover" data-ai-hint={item.aiHint}/>
                    </div>
                </Link>
            </CardHeader>
            <CardContent className="p-4 flex-grow">
              <Link href={`/retailer/products/${item.productId}`} className="block">
                <CardTitle className="text-lg font-semibold mb-1 hover:text-primary transition-colors">{item.name}</CardTitle>
              </Link>
              <CardDescription className="text-sm text-muted-foreground">
                By: <Link href={`/retailer/vendors/${item.vendorName.toLowerCase().replace(/\s+/g, '-')}`} className="text-primary hover:underline">{item.vendorName}</Link>
              </CardDescription>
              <p className="text-xl font-bold text-primary my-2">{item.price}</p>
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>Added: {item.dateAdded}</span>
                <StockStatusBadge status={item.stockStatus} />
              </div>
            </CardContent>
            <CardFooter className="p-3 border-t bg-muted/20 grid grid-cols-2 gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => handleRemoveFromWishlist(item.id, item.name)}
                className="w-full"
              >
                <Trash2 className="mr-2 h-4 w-4" /> Remove
              </Button>
              <Button 
                size="sm" 
                className="w-full bg-accent hover:bg-accent/90 text-accent-foreground" 
                onClick={() => handleAddToCart(item.name)}
                disabled={item.stockStatus === "Out of Stock"}
              >
                <ShoppingCart className="mr-2 h-4 w-4" /> 
                {item.stockStatus === "Out of Stock" ? "Out of Stock" : "Add to Cart"}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}
