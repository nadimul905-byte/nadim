
"use client";

import React, { Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ShoppingCart, ArrowLeft, Zap, Loader2 } from 'lucide-react';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'; 
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export interface Product {
  id: string;
  name: string;
  shortDescription: string;
  price: string;
  minOrderQuantity: number;
  image: string;
  categorySlug: string;
  aiHint: string;
  vendorName: string;
  vendorAvatar: string;
  vendorAvatarAiHint: string;
  subCategory?: string;
}

export const allMockProducts: Product[] = [
  // Sale Items
  { id: 'sale01', name: 'Premium Cotton Hoodie (Sale)', shortDescription: 'Heavyweight fleece for ultimate comfort. End of season clearance.', price: '$35.00', minOrderQuantity: 10, image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwzfHxob29kaWV8ZW58MHx8fHwxNzUyNDIwNjY5fDA&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'sale', aiHint: 'hoodie sale', vendorName: 'Street Style Kings', vendorAvatar: 'https://placehold.co/40x40.png?text=SSK', vendorAvatarAiHint: 'streetwear logo', subCategory: "Tops" },
  { id: 'sale02', name: 'Summer Linen Shorts (Sale)', shortDescription: 'Breathable linen blend for warm weather.', price: '$20.00', minOrderQuantity: 20, image: 'https://images.unsplash.com/photo-1591195853828-11db59a44f6b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxzaG9ydHN8ZW58MHx8fHwxNzUyNDIwNjY5fDA&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'sale', aiHint: 'linen shorts', vendorName: 'Summer Styles', vendorAvatar: 'https://images.unsplash.com/photo-1623288516140-47a0a17cec7c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxzdW1tZXIlMjBmYXNoaW9ufGVufDB8fHx8MTc1MjQyMDY2OXww&ixlib=rb-4.1.0&q=80&w=1080', vendorAvatarAiHint: 'summer fashion', subCategory: "Bottoms" },
  { id: 'sale03', name: 'Canvas Slip-Ons (Sale)', shortDescription: 'Easy-wear casual footwear in durable canvas.', price: '$15.00', minOrderQuantity: 30, image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxNHx8c2hvZXN8ZW58MHx8fHwxNzUyNDIwNjY5fDA&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'sale', aiHint: 'canvas shoes', vendorName: 'Footwear Express', vendorAvatar: 'https://images.unsplash.com/photo-1582482020958-b838acfd9b66?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxzaG9lJTIwc3RvcmV8ZW58MHx8fHwxNzQ5MjE1NzAwfDA&ixlib.rb-4.1.0&q=80&w=1080', vendorAvatarAiHint: 'shoe store', subCategory: "Shoes" },

  // Women's Apparel
  { id: 'rp1', name: 'Classic White Tee', shortDescription: 'Soft 100% cotton, perfect for everyday.', price: '$25.00', minOrderQuantity: 12, image: 'https://images.unsplash.com/photo-1637448096758-95360e65e72f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw2fHx3aGl0ZSUyMHRlZXxlbnwwfHx8fDE3NTI0MjA2Njl8MA&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'womens-apparel', aiHint: 'white tee', vendorName: 'Apparel Co.', vendorAvatar: 'https://images.unsplash.com/photo-1730740505098-29964984eb51?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxMHx8YXBwYXJlbCUyMGNvbXBhbnl8ZW58MHx8fHwxNzUyNDIwNjY5fDA&ixlib=rb-4.1.0&q=80&w=1080', vendorAvatarAiHint: 'apparel company', subCategory: "Tops" },
  { id: 'vprod4', name: 'Luxury Silk Blouse', shortDescription: 'Elegant silk blouse with fine craftsmanship.', price: '$90.00', minOrderQuantity: 5, image: 'https://images.unsplash.com/photo-1717777917505-5401ba591fe3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw3fHxzaWxrJTIwYmxvdXNlfGVufDB8fHx8MTc0ODgxNjUyOXww&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'womens-apparel', aiHint: 'silk blouse', vendorName: 'Chic Designs Co.', vendorAvatar: 'https://images.unsplash.com/photo-1590874315261-788881621f7a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwbG9nb3xlbnwwfHx8fDE3NDg4NjUyODl8MA&ixlib=rb-4.1.0&q=80&w=1080', vendorAvatarAiHint: 'fashion logo', subCategory: "Tops" },
  { id: 'rp7', name: 'Floral Sundress', shortDescription: 'Lightweight rayon, ideal for summer days.', price: '$60.00', minOrderQuantity: 8, image: 'https://images.unsplash.com/photo-1667088527671-6ddf12919f2c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxmb3JtYWwlMjBzdW5kcmVzc3xlbnwwfHx8fDE3NTI0MjA2Njl8MA&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'womens-apparel', aiHint: 'floral sundress', vendorName: 'Summer Styles', vendorAvatar: 'https://images.unsplash.com/photo-1623288516140-47a0a17cec7c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxzdW1tZXIlMjBmYXNoaW9ufGVufDB8fHx8MTc1MjQyMDY2OXww&ixlib=rb-4.1.0&q=80&w=1080', vendorAvatarAiHint: 'summer fashion', subCategory: "Dresses" },
  
  // Men's Apparel
  { id: 'rp2', name: 'Slim Fit Jeans - Dark Wash', shortDescription: 'Comfortable stretch denim for a modern look.', price: '$70.00', minOrderQuantity: 10, image: 'https://images.unsplash.com/photo-1551024559-d69bcf67d8d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw0fHxzbGltJTIwamVhbnN8ZW58MHx8fHwxNzQ5MjE1NzAwfDA&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'mens-apparel', aiHint: 'slim jeans', vendorName: 'Denim Dreams', vendorAvatar: 'https://images.unsplash.com/photo-1459173422306-0ce3fb37f832?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw2fHxkZW5pbSUyMGJyYW5kfGVufDB8fHx8MTc0OTIxNTcwMHww&ixlib=rb-4.1.0&q=80&w=1080', vendorAvatarAiHint: 'denim brand', subCategory: "Pants" },
  { id: 'vprod5', name: 'Summer Linen Shirt', shortDescription: 'Breathable linen, perfect for beach weather.', price: '$65.00', minOrderQuantity: 15, image: 'https://images.unsplash.com/photo-1721098122739-1892d7a2b399?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxMHx8bGluZW4lMjBzaGlydHxlbnwwfHx8fDE3NTExMTgyNjR8MA&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'mens-apparel', aiHint: 'linen shirt', vendorName: 'Summer Styles', vendorAvatar: 'https://images.unsplash.com/photo-1623288516140-47a0a17cec7c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxzdW1tZXIlMjBmYXNoaW9ufGVufDB8fHx8MTc1MjQyMDY2OXww&ixlib=rb-4.1.0&q=80&w=1080', vendorAvatarAiHint: 'summer fashion', subCategory: "Tops" },

  // Kids' Apparel
  { id: 'kids01', name: 'Toddler Organic Onesie', shortDescription: 'Hypoallergenic organic cotton for baby skin.', price: '$18.00', minOrderQuantity: 24, image: 'https://images.unsplash.com/photo-1522771935876-2497116a7a9e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxiYWJ5JTIwb25lc2llfGVufDB8fHx8MTc1MzA1NTA3Mnww&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'kids-apparel', aiHint: 'baby onesie', vendorName: 'Apparel Co.', vendorAvatar: 'https://images.unsplash.com/photo-1730740505098-29964984eb51?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxMHx8YXBwYXJlbCUyMGNvbXBhbnl8ZW58MHx8fHwxNzUyNDIwNjY5fDA&ixlib=rb-4.1.0&q=80&w=1080', vendorAvatarAiHint: 'apparel company', subCategory: "Baby" },

  // Shoes
  { id: 'rp3', name: 'Comfort Running Sneakers', shortDescription: 'Lightweight and breathable for optimal performance.', price: '$90.00', minOrderQuantity: 5, image: 'https://images.unsplash.com/photo-1571008887538-b36bb32f4571?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw3fHxydW5uaW5nJTIwc2hvZXN8ZW58MHx8fHwxNzQ5MjE1NzAwfDA&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'shoes', aiHint: 'running shoes', vendorName: 'Footwear Express', vendorAvatar: 'https://images.unsplash.com/photo-1582482020958-b838acfd9b66?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxzaG9lJTIwc3RvcmV8ZW58MHx8fHwxNzQ5MjE1NzAwfDA&ixlib.rb-4.1.0&q=80&w=1080', vendorAvatarAiHint: 'shoe store', subCategory: "Sneakers" },

  // Accessories
  { id: 'rp4', name: 'Minimalist Leather Watch', shortDescription: 'Elegant design with a genuine leather strap.', price: '$150.00', minOrderQuantity: 3, image: 'https://images.unsplash.com/photo-1667854792753-26ec904c0295?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw3fHxsZWF0aGVyJTIwd2F0Y2h8ZW58MHx8fHwxNzQ5MjE1NzAwfDA&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'accessories', aiHint: 'leather watch', vendorName: 'Timepiece Trends', vendorAvatar: 'https://images.unsplash.com/photo-1434493651957-4ec11beae249?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw0fHx3YXRjaCUyMGNvbXBhbnl8ZW58MHx8fHwxNzQ5MjE1NzAwfDA&ixlib.rb-4.1.0&q=80&w=1080', vendorAvatarAiHint: 'watch company', subCategory: "Watches" },
  { id: 'vprod1', name: 'Handcrafted Leather Wallet', shortDescription: 'Premium full-grain leather wallet.', price: '$75.00', minOrderQuantity: 10, image: 'https://images.unsplash.com/photo-1629958513881-a086d21383cd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxsZWF0aGVyJTIwd2FsbGV0fGVufDB8fHx8MTc1MExExODI2NHww&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'accessories', aiHint: 'leather wallet', vendorName: 'Artisan Leather', vendorAvatar: 'https://placehold.co/40x40.png?text=AL', vendorAvatarAiHint: 'leather goods', subCategory: 'Wallets' },

  // Bags
  { id: 'bag001', name: 'Recycled Canvas Tote', shortDescription: 'Durable, sustainable, and high-capacity.', price: '$45.00', minOrderQuantity: 50, image: 'https://images.unsplash.com/photo-1544816155-12df9643f363?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxjYW52YXMlMjB0b3RlfGVufDB8fHx8MTc1MzA1NTA3Mnww&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'bags', aiHint: 'canvas tote', vendorName: 'Artisan Goods Ltd.', vendorAvatar: 'https://placehold.co/40x40.png?text=AG', vendorAvatarAiHint: 'artisan logo', subCategory: "Totes" },

  // Jewelry
  { id: 'rp5', name: 'Delicate Gold Necklace', shortDescription: '14k gold plated, perfect for layering.', price: '$200.00', minOrderQuantity: 2, image: 'https://images.unsplash.com/photo-1599459183200-59c7687a0275?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw4fHxnb2xkJTIwbmVja2xhY2V8ZW58MHx8fHwxNzQ5MjE1NzAxfDA&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'jewelry', aiHint: 'gold necklace', vendorName: 'Glimmer Gems', vendorAvatar: 'https://images.unsplash.com/photo-1574582242931-e2b1d1f65d4b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxqZXdlbHJ5JTIwc2hvcHxlbnwwfHx8fDE3NDkyMTU3MDF8MA&ixlib.rb-4.1.0&q=80&w=1080', vendorAvatarAiHint: 'jewelry shop', subCategory: "Necklaces" },

  // Cosmetics
  { id: 'rp6', name: 'Velvet Matte Lipstick', shortDescription: 'Long-lasting, vibrant color with a smooth finish.', price: '$15.00', minOrderQuantity: 24, image: 'https://images.unsplash.com/photo-1492707892479-7bc8d5a4ee93?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw3fHxsaXBzdGljayUyMG1ha2V1cHxlbnwwfHx8fDE3NDkyMTU3MDF8MA&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'cosmetics', aiHint: 'lipstick makeup', vendorName: 'Beauty Blend', vendorAvatar: 'https://images.unsplash.com/photo-1631214564867-f1aa6d638afc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw4fHxiZWF1dHklMjBicmFuZHxlbnwwfHx8fDE3NDkyMTU3MDB8MA&ixlib.rb-4.1.0&q=80&w=1080', vendorAvatarAiHint: 'beauty brand', subCategory: "Makeup" },
  { id: 'rp12', name: 'Eyeshadow Palette - Nudes', shortDescription: '12 versatile shades for day to night looks.', price: '$35.00', minOrderQuantity: 20, image: 'https://images.unsplash.com/photo-1625094640367-05f84293fe42?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxleWVzaGFkb3clMjBwYWxldHRlfGVufDB8fHx8MTc0OTIxNTcwMHww&ixlib.rb-4.1.0&q=80&w=1080', categorySlug: 'cosmetics', aiHint: 'eyeshadow palette', vendorName: 'Palette Perfect', vendorAvatar: 'https://images.unsplash.com/photo-1591375462469-62f189694738?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxjb3NtZXRpY3MlMjBicmFuZHxlbnwwfHx8fDE3NDkyMTU3MDB8MA&ixlib.rb-4.1.0&q=80&w=1080', vendorAvatarAiHint: 'cosmetics brand', subCategory: "Makeup" },

  // Outerwear
  { id: 'outer01', name: 'Tech Windbreaker', shortDescription: 'Waterproof technical shell for urban utility.', price: '$120.00', minOrderQuantity: 10, image: 'https://images.unsplash.com/photo-1616150840617-a0124ea42a1f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw3fHxqYWNrZXRzJTIwY29hdHN8ZW58MHx8fHwxNzQ5NTU5NDU0fDA&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'outerwear', aiHint: 'windbreaker jacket', vendorName: 'Modern Threads', vendorAvatar: 'https://placehold.co/40x40.png?text=MT', vendorAvatarAiHint: 'modern brand', subCategory: "Jackets" },

  // Formal Wear
  { id: 'formal01', name: 'Bespoke Silk Tuxedo', shortDescription: 'Precision tailored for premium events.', price: '$450.00', minOrderQuantity: 5, image: 'https://images.unsplash.com/photo-1601653311133-9789564fa789?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw5fHxmb3JtYWwlMjBkcmVzc3xlbnwwfHx8fDE3NDk1NTk0NTR8MA&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'formal-wear', aiHint: 'formal tuxedo', vendorName: 'The Dapper Gentleman', vendorAvatar: 'https://placehold.co/40x40.png?text=DG', vendorAvatarAiHint: 'dapper logo', subCategory: "Suits" },

  // Activewear
  { id: 'active01', name: 'Seamless Compression Leggings', shortDescription: '4-way stretch, moisture-wicking technology.', price: '$55.00', minOrderQuantity: 25, image: 'https://images.unsplash.com/photo-1637666544359-0e88de7b3206?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw4fHxhY3RpdmV3ZWFyJTIwc3BvcnRzd2VhcnxlbnwwfHx8fDE3NDk1NTk0NTN8MA&ixlib.rb-4.1.0&q=80&w=1080', categorySlug: 'activewear', aiHint: 'yoga leggings', vendorName: 'Fit & Fab Co.', vendorAvatar: 'https://placehold.co/40x40.png?text=FF', vendorAvatarAiHint: 'fitness logo', subCategory: "Leggings" },

  // Raw Materials
  { id: 'raw01', name: 'Pima Cotton Bolt (Bulk)', shortDescription: 'Premium Egyptian cotton, 180GSM.', price: '$12.50', minOrderQuantity: 100, image: 'https://images.unsplash.com/photo-1705493253575-e911888621ff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw1fHx0ZXh0aWxlJTIwZmFicmljc3xlbnwwfHx8fDE3NTA5NDUxMjZ8MA&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'raw-materials', aiHint: 'cotton fabric', vendorName: 'Textile Supply Co.', vendorAvatar: 'https://placehold.co/40x40.png?text=TS', vendorAvatarAiHint: 'textile logo', subCategory: "Fabrics" },
  { id: 'raw02', name: 'Vegetable Tanned Leather', shortDescription: 'Full-grain cowhide for luxury goods.', price: '$85.00', minOrderQuantity: 10, image: 'https://images.unsplash.com/photo-1585314062604-1a357de8b000?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxMHx8bGVhdGhlciUyMHRleHR1cmV8ZW58MHx8fHwxNzUwOTQ1MTI2fDA&ixlib=rb-4.1.0&q=80&w=1080', categorySlug: 'raw-materials', aiHint: 'leather hide', vendorName: 'Artisan Leather', vendorAvatar: 'https://placehold.co/40x40.png?text=AL', vendorAvatarAiHint: 'leather logo', subCategory: "Leather" },
  { id: 'raw03', name: 'Brass Zipper Spools', shortDescription: 'Heavy-duty YKK standard brass zips.', price: '$1.50', minOrderQuantity: 500, image: 'https://images.unsplash.com/photo-1563891510473-18923cd29239?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw1fHxzZXdpbmclMjBidXR0b25zfGVufDB8fHx8MTc1MDk0NTEyNnww&ixlib.rb-4.1.0&q=80&w=1080', categorySlug: 'raw-materials', aiHint: 'zipper spool', vendorName: 'Notion Hub', vendorAvatar: 'https://placehold.co/40x40.png?text=NH', vendorAvatarAiHint: 'notion logo', subCategory: "Notions" },
];

const categoryDisplayNames: { [slug: string]: string } = {
  'womens-apparel': "Women's Apparel",
  'mens-apparel': "Men's Apparel",
  'kids-apparel': "Kids' Apparel",
  'outerwear': "Outerwear",
  'shoes': "Shoes",
  'accessories': "Accessories",
  'bags': "Bags",
  'jewelry': "Jewelry",
  'cosmetics': "Cosmetics",
  'activewear': "Activewear",
  'formal-wear': "Formal Wear",
  'sale': "On Sale",
  'new': "New Arrivals",
  'raw-materials': "Raw Materials",
};

export const ProductItemCard = ({ product }: { product: Product }) => {
  const router = useRouter();
  const { toast } = useToast();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    toast({ title: "Added to Cart", description: `${product.name} has been added.` });
  };

  const handleBuyNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    router.push('/retailer/checkout');
  };
  
  const vendorSlug = product.vendorName.toLowerCase().trim().replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-').replace(/^-+|-+$/g, '');

  return (
    <Card className="w-full overflow-hidden group flex flex-col rounded-3xl border shadow-sm hover:shadow-lg transition-all">
      <Link href={`/retailer/products/${product.id}`} className="block flex-grow flex flex-col">
        <CardContent className="p-0">
          <div className="relative h-56 w-full bg-muted overflow-hidden">
            <Image 
              src={product.image} 
              alt={product.name} 
              layout="fill" 
              objectFit="cover" 
              className="transition-transform duration-500 group-hover:scale-105"
              data-ai-hint={product.aiHint}
            />
          </div>
        </CardContent>
        <CardHeader className="p-4 flex-grow">
          <CardTitle className="text-base font-bold truncate group-hover:text-primary">{product.name}</CardTitle>
          <CardDescription className="text-xs text-muted-foreground mt-0.5 line-clamp-2 h-8 font-medium">
            {product.shortDescription}
          </CardDescription>
          <div className="flex justify-between items-baseline mt-2">
              <p className="text-sm text-primary font-black">{product.price}</p>
              <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">MOQ: {product.minOrderQuantity}</p>
          </div>
        </CardHeader>
      </Link>
      <CardFooter className="p-3 border-t bg-muted/5 flex flex-col items-start gap-3">
          <Link href={`/retailer/vendors/${vendorSlug}`} className="flex items-center group/vendor w-full">
              <Avatar className="h-6 w-6 mr-2 flex-shrink-0 border shadow-sm">
                  <AvatarImage src={product.vendorAvatar} alt={product.vendorName} data-ai-hint={product.vendorAvatarAiHint} />
                  <AvatarFallback>{product.vendorName.charAt(0)}</AvatarFallback>
              </Avatar>
              <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground group-hover/vendor:text-primary group-hover/vendor:underline truncate">
                  {product.vendorName}
              </p>
          </Link>
        <div className="grid grid-cols-2 gap-2 w-full">
          <Button variant="outline" size="sm" className="w-full rounded-xl text-[9px] font-black uppercase h-8 border-primary/20 text-primary" onClick={handleAddToCart}>
            <ShoppingCart className="mr-1 h-3 w-3" /> Cart
          </Button>
          <Button variant="default" size="sm" className="w-full rounded-xl text-[9px] font-black uppercase h-8 bg-accent text-accent-foreground" onClick={handleBuyNow}>
            <Zap className="mr-1 h-3 w-3" /> Buy Now
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};


function RetailerProductsContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const category = searchParams.get('category');
  const subCategoryQuery = searchParams.get('subCategory');

  const [activeTab, setActiveTab] = React.useState(subCategoryQuery || 'all');
  
  React.useEffect(() => {
    setActiveTab(subCategoryQuery || 'all');
  }, [subCategoryQuery]);

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    const params = new URLSearchParams(window.location.search);
    if (value === 'all') {
      params.delete('subCategory');
    } else {
      params.set('subCategory', value);
    }
    router.replace(`${window.location.pathname}?${params.toString()}`, { scroll: false });
  };


  const backLink = category === 'raw-materials' 
    ? '/retailer/categories?tab=raw-materials' 
    : '/retailer/categories';

  const pageTitle = category 
      ? (categoryDisplayNames[category] || category.split('-').map(w=>w[0].toUpperCase()+w.slice(1)).join(' ')) 
      : "All Products";

  const productsForCategory = allMockProducts.filter(p => category ? p.categorySlug === category : true);
  const filteredProducts = productsForCategory.filter(p => activeTab === 'all' || p.subCategory === activeTab);

  const subCategories = ['all', ...Array.from(new Set(productsForCategory.map(p => p.subCategory).filter(Boolean))) as string[]];
  const showTabs = subCategories.length > 2;


  const renderProductGrid = (products: Product[]) => (
     products.length > 0 ? (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.map(product => (
          <ProductItemCard key={product.id} product={product} />
        ))}
      </div>
    ) : (
      <Card className="rounded-[2.5rem] border-2 border-dashed">
        <CardContent className="py-20 text-center">
          <ShoppingCart className="h-16 w-16 text-muted-foreground mx-auto mb-4 opacity-10" />
          <h3 className="text-xl font-headline font-black">Warehouse Empty</h3>
          <p className="text-xs text-muted-foreground font-medium uppercase tracking-widest mt-2">
            No listings found in this sector.
          </p>
          <Button asChild className="mt-8 rounded-2xl h-12 font-black uppercase text-xs">
            <Link href="/retailer/categories">Switch Terminal</Link>
          </Button>
        </CardContent>
      </Card>
    )
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-headline font-semibold">{pageTitle}</h1>
        <Button variant="outline" onClick={() => router.back()} className="rounded-full h-10 w-10">
            <ArrowLeft className="h-5 w-5"/>
        </Button>
      </div>

      {showTabs ? (
         <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
            <TabsList className="flex w-full overflow-x-auto whitespace-nowrap no-scrollbar pb-1 h-auto flex-wrap md:h-10 bg-muted/30 p-1 rounded-2xl border">
              {subCategories.map(subCat => (
                <TabsTrigger key={subCat} value={subCat} className="flex-shrink-0 px-4 py-1.5 m-0.5 capitalize text-[10px] font-black uppercase tracking-widest rounded-xl data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                  {subCat === 'all' ? 'All' : subCat}
                </TabsTrigger>
              ))}
            </TabsList>
            <TabsContent value={activeTab} className="mt-6">
               {renderProductGrid(filteredProducts)}
            </TabsContent>
         </Tabs>
      ) : (
        renderProductGrid(productsForCategory)
      )}
      <style jsx global>{`
        .no-scrollbar::-webkit-scrollbar {
            display: none;
        }
        .no-scrollbar {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}

export default function RetailerProductsPage() {
  return (
    <Suspense fallback={<div className="flex justify-center py-20"><Loader2 className="animate-spin h-10 w-10 text-primary" /></div>}>
      <RetailerProductsContent />
    </Suspense>
  );
}
