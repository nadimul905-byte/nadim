"use client";

import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { 
    Star, Heart, MessageSquare, ShoppingCart, Sparkles, 
    ChevronLeft, ChevronRight, PackageSearch, Zap, ArrowLeft, 
    ShieldCheck, Ruler, CheckCircle2, Clock, Globe, Award,
    Box, Truck, Plus, ArrowRight, Send, Paperclip, Bot, Edit3
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { allMockProducts, type Product as BasicProduct } from '@/app/retailer/products/page';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Checkbox } from '@/components/ui/checkbox';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetDescription } from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';

interface ProductDetail {
  id: string;
  name: string;
  brand: string;
  images: { src: string; alt: string; aiHint: string }[];
  basePrice: number;
  bulkPricing: { range: string; pricePerUnit: number }[];
  variants: {
    size: string[];
    color: string[];
  };
  description: string;
  details: string;
  leadTime: string;
  customization: { label: string; minQty: number }[];
  vendorInfo: {
    name: string;
    logo: string;
    logoAiHint: string;
    rating: number;
    reviews: number;
    responseTime: string;
    onTimeDelivery: string;
  };
  reviewsData: { id: number; user: string; rating: number; comment: string }[];
  relatedProducts: { id: string; name: string; price: string; image: string; aiHint: string }[];
}

const generateMockDetailsForProduct = (basicProductInfo: BasicProduct): ProductDetail => {
  const priceStr = basicProductInfo.price.replace('$', '');
  const basePrice = parseFloat(priceStr) || 0;
  const moq = basicProductInfo.minOrderQuantity || 1;

  return {
    id: basicProductInfo.id,
    name: basicProductInfo.name,
    brand: basicProductInfo.vendorName,
    images: [
      { src: basicProductInfo.image, alt: `${basicProductInfo.name} main view`, aiHint: basicProductInfo.aiHint },
      { src: `https://picsum.photos/seed/${basicProductInfo.id}side/600/800`, alt: `${basicProductInfo.name} side view`, aiHint: "product side" },
      { src: `https://picsum.photos/seed/${basicProductInfo.id}detail/600/800`, alt: `${basicProductInfo.name} detail`, aiHint: "product detail" },
      { src: `https://picsum.photos/seed/${basicProductInfo.id}context/600/800`, alt: `${basicProductInfo.name} context`, aiHint: "lifestyle product" },
    ],
    price: basePrice,
    bulkPricing: [
      { range: `${moq}-${moq*5-1} pcs`, pricePerUnit: basePrice },
      { range: `${moq*5}-${moq*10-1} pcs`, pricePerUnit: basePrice * 0.92 },
      { range: `${moq*10}+ pcs`, pricePerUnit: basePrice * 0.85 },
    ],
    variants: { 
      size: ['S', 'M', 'L', 'XL', 'XXL'],
      color: ['Signature White', 'Onyx Black', 'Midnight Blue', 'Sand Beige'],
    },
    description: basicProductInfo.shortDescription + " This high-fidelity professional garment is engineered for bulk retail. Features reinforced seams and premium dye retention.",
    details: `Fabric: 100% Organic Pima Cotton. Weight: 180GSM. Fit: Retail Standard.`,
    leadTime: "15 Days (under 500 pcs)",
    customization: [
        { label: "Custom Logo", minQty: 100 },
        { label: "Custom Packaging", minQty: 500 },
        { label: "Graphic Printing", minQty: 200 }
    ],
    vendorInfo: {
      name: basicProductInfo.vendorName,
      logo: basicProductInfo.vendorAvatar,
      logoAiHint: basicProductInfo.vendorAvatarAiHint,
      rating: 4.8 + (Math.random() * 0.2),
      reviews: 150 + Math.floor(Math.random() * 300),
      responseTime: "< 2h",
      onTimeDelivery: "99.2%",
    },
    reviewsData: [
      { id: 1, user: "GlobalRetail_NY", rating: 5, comment: "Consistently high quality." },
    ],
    relatedProducts: allMockProducts.filter(p => p.id !== basicProductInfo.id).slice(0,6).map(p => ({
        id: p.id,
        name: p.name,
        price: p.price,
        image: p.image,
        aiHint: p.aiHint
    })),
  };
};

export default function ProductDetailsPage() {
  const router = useRouter();
  const params = useParams();
  const productId = params.productId as string;
  const { toast } = useToast();

  const [product, setProduct] = useState<ProductDetail | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string | undefined>();
  const [selectedColor, setSelectedColor] = useState<string | undefined>();
  const [quantity, setQuantity] = useState(1);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [chatMessage, setChatMessage] = useState('');

  useEffect(() => {
    if (!productId) return;
    setIsLoading(true);
    const basicProductInfo = allMockProducts.find(p => p.id === productId);
    if (basicProductInfo) {
      const detailedProduct = generateMockDetailsForProduct(basicProductInfo);
      setProduct(detailedProduct);
      setSelectedSize(detailedProduct.variants.size[0]);
      setSelectedColor(detailedProduct.variants.color[0]);
      setQuantity(basicProductInfo.minOrderQuantity || 1);
    }
    setIsLoading(false);
  }, [productId]);

  const handleAddToCart = () => {
    if (!product) return;
    toast({ title: "Procurement Started", description: `${product.name} added to your batch.`});
  };
  
  const handleBuyNow = () => {
    if (!product) return;
    router.push('/retailer/checkout');
  };

  if (isLoading) {
    return (
      <div className="space-y-6 max-w-xs mx-auto">
        <Skeleton className="aspect-[3/4] w-full rounded-[2.5rem]" />
        <Skeleton className="h-20 w-full rounded-2xl" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container mx-auto py-12 text-center max-w-xs">
        <PackageSearch className="mx-auto h-16 w-16 text-muted-foreground mb-4 opacity-20" />
        <h1 className="text-xl font-headline font-black">Item Offline</h1>
        <Button onClick={() => router.back()} className="mt-4 rounded-xl w-full">Back to Market</Button>
      </div>
    );
  }

  const getPriceForQty = (qty: number) => {
    const moq = parseInt(product.bulkPricing[0].range.split('-')[0]);
    if (qty < moq) return product.basePrice;
    const tiers = [...product.bulkPricing].reverse();
    for (const tier of tiers) {
        const threshold = parseInt(tier.range.replace('+', '').split('-')[0]);
        if (qty >= threshold) return tier.pricePerUnit;
    }
    return product.basePrice;
  };

  const currentPrice = getPriceForQty(quantity);
  const vendorSlug = product.vendorInfo.name.toLowerCase().trim().replace(/[^\w-]/g, '').replace(/[\s_-]+/g, '-').replace(/^-+|-+$/g, '');
  const lkoinValue = (currentPrice * 10 * quantity).toLocaleString();

  return (
    <div className="space-y-6 max-w-xs mx-auto px-1 pb-24 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <Button variant="outline" size="icon" onClick={() => router.back()} className="rounded-full h-10 w-10 bg-background/80 backdrop-blur-sm border-none shadow-sm">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex items-center gap-2">
            <Badge variant="secondary" className="bg-primary/5 text-primary border-primary/20 text-[9px] font-black uppercase tracking-tighter">OS Verified</Badge>
            <Badge variant="secondary" className="bg-green-500/10 text-green-600 border-none text-[9px] font-black uppercase tracking-tighter">Ready to Ship</Badge>
        </div>
        <Button variant="ghost" size="icon" onClick={() => { setIsWishlisted(!isWishlisted); toast({title: isWishlisted ? "Removed from Wishlist" : "Added to Wishlist"}); }} className="rounded-full h-10 w-10">
            <Heart className={cn("h-5 w-5 transition-all duration-300", isWishlisted ? "fill-primary text-primary scale-110" : "text-muted-foreground")} />
        </Button>
      </div>

      <div className="relative group">
        <div className="aspect-[3/4] relative overflow-hidden rounded-[2.5rem] shadow-2xl bg-muted border-2 border-background">
          <Image src={product.images[currentImageIndex].src} alt={product.images[currentImageIndex].alt} fill className="object-cover" data-ai-hint={product.images[currentImageIndex].aiHint} />
          <div className="absolute inset-y-0 left-0 flex items-center">
             <Button variant="ghost" size="icon" className="h-10 w-8 bg-black/10 text-white rounded-r-xl rounded-l-none opacity-0 group-hover:opacity-100 transition-opacity" onClick={() => setCurrentImageIndex(i => (i - 1 + product.images.length) % product.images.length)}><ChevronLeft /></Button>
          </div>
          <div className="absolute inset-y-0 right-0 flex items-center">
             <Button variant="ghost" size="icon" className="h-10 w-8 bg-black/10 text-white rounded-l-xl rounded-r-none opacity-0 group-hover:opacity-100 transition-opacity" onClick={() => setCurrentImageIndex(i => (i + 1) % product.images.length)}><ChevronRight /></Button>
          </div>
          <div className="absolute inset-x-0 bottom-6 flex justify-center gap-1.5">
            {product.images.map((_, idx) => (
                <button 
                    key={idx} 
                    onClick={() => setCurrentImageIndex(idx)}
                    className={cn(
                        "h-1 rounded-full transition-all",
                        idx === currentImageIndex ? "w-8 bg-white" : "w-1 bg-white/40"
                    )}
                />
            ))}
          </div>
        </div>
      </div>

      <div className="space-y-3 px-1">
        <div className="space-y-1">
            <h1 className="text-2xl font-headline font-black tracking-tight leading-[1.1]">{product.name}</h1>
            <div className="flex items-center justify-between">
                 <Link href={`/retailer/vendors/${vendorSlug}`} className="flex items-center gap-2 group">
                    <Avatar className="h-6 w-6 border-2 border-background shadow-sm">
                        <AvatarImage src={product.vendorInfo.logo} data-ai-hint={product.vendorInfo.logoAiHint} />
                        <AvatarFallback>{product.brand[0]}</AvatarFallback>
                    </Avatar>
                    <span className="text-[10px] font-black uppercase tracking-widest text-primary group-hover:underline">{product.brand}</span>
                </Link>
                <div className="flex items-center gap-1">
                    <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                    <span className="text-[10px] font-black">{product.vendorInfo.rating}</span>
                    <span className="text-[9px] text-muted-foreground font-bold">({product.vendorInfo.reviews})</span>
                </div>
            </div>
        </div>

        <div className="grid grid-cols-3 gap-2 py-4 px-3 bg-secondary/50 rounded-3xl border border-dashed border-primary/10">
            {product.bulkPricing.map((tier, idx) => {
                const moqStr = tier.range.replace('+', '').split('-')[0];
                const nextMoqStr = product.bulkPricing[idx+1]?.range.split('-')[0];
                const isActive = (quantity >= parseInt(moqStr) && (idx === product.bulkPricing.length - 1 || quantity < parseInt(nextMoqStr)));
                return (
                    <div 
                        key={idx} 
                        className={cn(
                            "text-center space-y-1 py-1 px-2 rounded-2xl transition-all cursor-pointer",
                            isActive ? "bg-primary text-primary-foreground shadow-lg scale-105" : "text-muted-foreground hover:bg-muted/50"
                        )}
                        onClick={() => {
                          const targetQty = parseInt(moqStr);
                          if (!isNaN(targetQty)) {
                            setQuantity(targetQty);
                            toast({ title: "Tier Applied", description: `Quantity updated to ${targetQty} for bulk pricing.` });
                          }
                        }}
                    >
                        <p className="text-[8px] font-black uppercase tracking-tighter opacity-80">{tier.range}</p>
                        <p className="text-sm font-black tracking-tighter">${tier.pricePerUnit.toFixed(2)}</p>
                    </div>
                );
            })}
        </div>
      </div>

      <Card className="rounded-[2.5rem] bg-zinc-900 text-white border-none shadow-2xl overflow-hidden animate-in slide-in-from-bottom-4 duration-700">
            <CardContent className="p-8 space-y-8">
                <div className="flex justify-between items-end">
                    <div className="space-y-1">
                        <p className="text-[10px] uppercase font-black tracking-[0.2em] text-zinc-300">Active Procurement</p>
                        <div className="flex items-baseline gap-2">
                             <p className="text-4xl font-black tracking-tighter text-white">${currentPrice.toFixed(2)}</p>
                             <span className="text-[10px] text-zinc-300 font-bold uppercase">/ Unit</span>
                        </div>
                    </div>
                    <div className="text-right">
                        <p className="text-[9px] uppercase font-black tracking-[0.2em] text-amber-400">Reward Yield</p>
                        <p className="text-sm font-black text-amber-400 flex items-center justify-end gap-1">
                            <Sparkles className="h-4 w-4 fill-amber-400" /> LK {lkoinValue}
                        </p>
                    </div>
                </div>

                <Separator className="bg-white/10" />

                <div className="space-y-8">
                    <div className="space-y-4">
                        <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-200">Product Configuration</h4>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label className="text-[11px] font-bold text-zinc-200 ml-1">Dimensions / Size</Label>
                                <Select value={selectedSize} onValueChange={setSelectedSize}>
                                    <SelectTrigger className="rounded-xl h-11 text-xs font-bold bg-white/5 border-white/10 text-white shadow-none focus:ring-primary/40"><SelectValue placeholder="Size" /></SelectTrigger>
                                    <SelectContent className="rounded-xl">
                                        {product.variants.size.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label className="text-[11px] font-bold text-zinc-200 ml-1">Finish / Color</Label>
                                <Select value={selectedColor} onValueChange={setSelectedColor}>
                                    <SelectTrigger className="rounded-xl h-11 text-xs font-bold bg-white/5 border-white/10 text-white shadow-none focus:ring-primary/40"><SelectValue placeholder="Color" /></SelectTrigger>
                                    <SelectContent className="rounded-xl">
                                        {product.variants.color.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                    </div>

                    <div className="space-y-4">
                        <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-200">Service Customization</h4>
                        <div className="space-y-2.5">
                            {product.customization.map((opt, i) => (
                                <div key={i} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 group transition-all hover:bg-white/10">
                                    <div className="flex items-center gap-3">
                                        <Checkbox id={`custom-${i}`} className="rounded-full h-5 w-5 border-white/20 data-[state=checked]:bg-primary data-[state=checked]:border-primary" />
                                        <Label htmlFor={`custom-${i}`} className="text-sm font-bold text-white cursor-pointer">{opt.label}</Label>
                                    </div>
                                    <Badge variant="outline" className="text-[10px] font-black uppercase border-primary/20 text-zinc-100 bg-primary/10 px-2 py-0.5">Min {opt.minQty}</Badge>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="space-y-4">
                        <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-200">Procurement Volume</h4>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label className="text-[11px] font-bold text-zinc-200 ml-1">Batch Units</Label>
                                <div className="flex items-center bg-white/5 rounded-2xl border border-white/10 h-12 px-3 focus-within:ring-1 ring-primary/40">
                                    <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full text-zinc-400 hover:bg-white/10" onClick={() => setQuantity(Math.max(1, quantity - 1))}><ChevronLeft className="h-4 w-4"/></Button>
                                    <input 
                                        type="number" 
                                        value={quantity} 
                                        onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                                        className="bg-transparent border-none text-center w-full text-sm font-black focus:ring-0 text-white"
                                    />
                                    <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full text-zinc-400 hover:bg-white/10" onClick={() => setQuantity(quantity + 1)}><ChevronRight className="h-4 w-4"/></Button>
                                </div>
                            </div>
                            <div className="space-y-2">
                                <Label className="text-[11px] font-bold text-zinc-200 ml-1">Batch Total</Label>
                                <div className="flex items-center justify-center bg-white/5 rounded-2xl border border-white/10 h-12">
                                    <span className="text-lg font-black text-white">${(currentPrice * quantity).toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="flex items-start gap-3 p-4 bg-primary/10 rounded-2xl border border-primary/20">
                        <ShieldCheck className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                        <p className="text-[10px] font-medium text-zinc-100 leading-relaxed italic">
                            Secure B2B Escrow active. Funds held until confirmed inventory arrival at your destination.
                        </p>
                    </div>
                </div>
            </CardContent>
            <CardFooter className="px-8 pb-8 pt-0 grid grid-cols-1 gap-3">
                <Button size="lg" className="w-full rounded-2xl bg-white text-black hover:bg-zinc-200 h-14 font-black uppercase text-xs shadow-xl shadow-black/40" onClick={handleBuyNow}>
                    Commit to Production
                </Button>
                <div className="grid grid-cols-1 gap-3">
                    <Button variant="ghost" className="w-full rounded-xl bg-white/5 text-white hover:bg-white/10 h-12 text-[10px] font-black uppercase tracking-widest" onClick={handleAddToCart}>
                        <ShoppingCart className="mr-2 h-4 w-4" /> Add to Batch (Cart)
                    </Button>
                </div>
            </CardFooter>
      </Card>

      <div className="space-y-3">
          <Card className="rounded-3xl border shadow-sm">
             <CardHeader className="p-6 pb-2">
                 <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-2xl bg-primary/10 flex items-center justify-center">
                        <Truck className="h-5 w-5 text-primary" />
                    </div>
                    <span className="text-[10px] font-black uppercase tracking-widest">Logistics Hub</span>
                </div>
            </CardHeader>
            <CardContent className="p-6 pt-2 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                        <p className="text-[9px] font-black uppercase text-muted-foreground">Est. Lead Time</p>
                        <div className="flex items-center gap-1.5 mt-1">
                            <Clock className="h-3.5 w-3.5 text-primary" />
                            <p className="text-xs font-black">{product.leadTime}</p>
                        </div>
                    </div>
                    <div className="space-y-1">
                        <p className="text-[9px] font-black uppercase text-muted-foreground">Shipment Range</p>
                        <div className="flex items-center gap-1.5 mt-1">
                            <Globe className="h-3.5 w-3.5 text-primary" />
                            <p className="text-xs font-black">Global Access</p>
                        </div>
                    </div>
                </div>
            </CardContent>
          </Card>
      </div>

      <Accordion type="single" collapsible className="w-full space-y-2">
            <Card className="rounded-3xl border shadow-sm overflow-hidden">
                <AccordionItem value="description" className="border-none">
                    <AccordionTrigger className="px-6 py-5 hover:no-underline font-black uppercase text-[10px] tracking-widest">
                        Technical Manifesto
                    </AccordionTrigger>
                    <AccordionContent className="px-6 pb-6 pt-0">
                        <div className="pt-4 border-t border-dashed space-y-4">
                            <p className="text-xs font-medium text-muted-foreground leading-relaxed italic">"{product.description}"</p>
                            <div className="grid grid-cols-1 gap-2">
                                {product.details.split('.').filter(s => s.trim()).map((s, i) => (
                                    <div key={i} className="flex items-center gap-2 p-3 bg-muted/30 rounded-xl">
                                        <Box className="h-3 w-3 text-primary/40" />
                                        <span className="text-[10px] font-bold">{s.trim()}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </AccordionContent>
                </AccordionItem>
            </Card>

            <Card className="rounded-3xl border shadow-sm overflow-hidden">
                <AccordionItem value="vendor" className="border-none">
                    <AccordionTrigger className="px-6 py-5 hover:no-underline font-black uppercase text-[10px] tracking-widest">
                        Vendor Integrity
                    </AccordionTrigger>
                    <AccordionContent className="px-6 pb-6 pt-0">
                        <div className="pt-4 border-t border-dashed space-y-6">
                            <div className="flex items-center justify-between">
                                <div className="space-y-1">
                                    <p className="text-[9px] font-black uppercase text-muted-foreground">Performance Score</p>
                                    <p className="text-xl font-black text-primary">{product.vendorInfo.rating.toFixed(1)} ★</p>
                                </div>
                                <div className="text-right space-y-1">
                                    <p className="text-[9px] font-black uppercase text-muted-foreground">Certified Since</p>
                                    <p className="text-xs font-black">2021</p>
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                                <div className="p-3 bg-secondary/50 rounded-2xl border text-center">
                                    <p className="text-[8px] font-black uppercase text-muted-foreground tracking-widest mb-1">Response</p>
                                    <p className="text-[11px] font-black">{product.vendorInfo.responseTime}</p>
                                </div>
                                <div className="p-3 bg-secondary/50 rounded-2xl border text-center">
                                    <p className="text-[8px] font-black uppercase text-muted-foreground tracking-widest mb-1">On-Time</p>
                                    <p className="text-[11px] font-black">{product.vendorInfo.onTimeDelivery}</p>
                                </div>
                            </div>
                            <Button variant="outline" className="w-full rounded-2xl h-12 text-[10px] font-black uppercase tracking-widest shadow-sm" asChild>
                                <Link href={`/retailer/vendors/${vendorSlug}`}>
                                    Audit Full Profile <ArrowRight className="ml-2 h-3.5 w-3.5" />
                                </Link>
                            </Button>
                        </div>
                    </AccordionContent>
                </AccordionItem>
            </Card>
      </Accordion>

      <section className="pt-6 space-y-4">
            <div className="flex items-center justify-center gap-3">
                <Separator className="flex-1" />
                <h2 className="text-[9px] font-black uppercase tracking-[0.4em] text-muted-foreground/60 shrink-0">Batch Complements</h2>
                <Separator className="flex-1" />
            </div>
            <div className="flex overflow-x-auto snap-x snap-mandatory space-x-4 pb-4 no-scrollbar -mx-1">
                {product.relatedProducts.map(rp => (
                    <Link key={rp.id} href={`/retailer/products/${rp.id}`} className="snap-start flex-shrink-0">
                        <Card className="w-36 rounded-[1.75rem] overflow-hidden border shadow-sm group hover:shadow-md transition-all">
                            <div className="relative aspect-square">
                                <Image src={rp.image} alt={rp.name} fill className="object-cover transition-transform duration-500 group-hover:scale-105" />
                                <div className="absolute top-2 right-2">
                                     <Badge className="bg-background/80 backdrop-blur-md text-primary border-none h-5 w-5 p-0 flex items-center justify-center rounded-full"><Plus className="h-3 w-3" /></Badge>
                                </div>
                            </div>
                            <div className="p-3">
                                <p className="text-[10px] font-black truncate leading-tight">{rp.name}</p>
                                <p className="text-[11px] font-black text-primary mt-1">{rp.price}</p>
                            </div>
                        </Card>
                    </Link>
                ))}
            </div>
      </section>

      <div className="fixed bottom-24 right-6 z-50">
          <Sheet>
              <SheetTrigger asChild>
                  <Button 
                      size="icon" 
                      className="h-16 w-16 rounded-full shadow-2xl bg-primary text-white hover:bg-primary/90 transition-transform active:scale-95 flex items-center justify-center border-4 border-background overflow-hidden p-0"
                  >
                      <Avatar className="h-full w-full">
                          <AvatarImage src={product.vendorInfo.logo} alt={product.vendorInfo.name} data-ai-hint={product.vendorInfo.logoAiHint} className="object-cover" />
                          <AvatarFallback className="bg-primary text-white text-lg font-black">{product.brand[0]}</AvatarFallback>
                      </Avatar>
                      <div className="absolute inset-0 bg-primary/10 pointer-events-none" />
                  </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[85vw] sm:max-w-md p-0 flex flex-col rounded-l-[2rem] border-none shadow-2xl overflow-hidden">
                  <SheetHeader className="p-6 bg-zinc-900 text-white flex-shrink-0">
                      <div className="flex items-center gap-3">
                          <Avatar className="h-10 w-10 border-2 border-primary/20">
                              <AvatarImage src={product.vendorInfo.logo} data-ai-hint={product.vendorInfo.logoAiHint} />
                              <AvatarFallback>{product.brand[0]}</AvatarFallback>
                          </Avatar>
                          <div className="text-left">
                              <SheetTitle className="text-white text-lg font-black tracking-tight">{product.brand}</SheetTitle>
                              <SheetDescription asChild>
                                <div className="text-zinc-500 text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 mt-0.5">
                                    <span className="h-1.5 w-1.5 rounded-full bg-green-500" />
                                    Active Procurement Session
                                </div>
                              </SheetDescription>
                          </div>
                      </div>
                  </SheetHeader>
                  
                  <Separator className="bg-zinc-800" />

                  <ScrollArea className="flex-1 p-6 bg-zinc-50 dark:bg-zinc-900/30">
                      <div className="space-y-6">
                          <div className="flex justify-center">
                              <Badge variant="outline" className="text-[8px] font-black uppercase text-muted-foreground border-dashed px-3">
                                  Product Query: {product.id}
                              </Badge>
                          </div>

                          <div className="flex flex-col gap-2 max-w-[85%]">
                              <div className="p-4 bg-white dark:bg-zinc-800 rounded-3xl rounded-tl-none shadow-sm border border-zinc-100 dark:border-zinc-700">
                                  <p className="text-xs font-medium leading-relaxed">
                                      Hello! Do you have specific questions about the {product.name}? I'm here to help with your procurement.
                                  </p>
                              </div>
                              <p className="text-[8px] font-black uppercase text-muted-foreground px-2">10:30 AM</p>
                          </div>

                          <div className="flex flex-col gap-2 max-w-[85%] ml-auto items-end">
                              <div className="p-4 bg-primary text-white rounded-3xl rounded-tr-none shadow-lg shadow-primary/20">
                                  <p className="text-xs font-bold leading-relaxed">
                                      Can you confirm if the items are available for bulk shipping immediately?
                                  </p>
                              </div>
                              <p className="text-[8px] font-black uppercase text-primary/60 px-2">10:32 AM</p>
                          </div>
                      </div>
                  </ScrollArea>

                  <div className="p-4 bg-white dark:bg-zinc-950 border-t flex-shrink-0">
                      <div className="relative">
                          <Input 
                              placeholder="Type professional inquiry..." 
                              className="h-14 rounded-2xl bg-muted/30 border-none pl-4 pr-12 text-sm font-medium focus-visible:ring-1 ring-primary/20"
                              value={chatMessage}
                              onChange={(e) => setChatMessage(e.target.value)}
                          />
                          <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                              <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full text-muted-foreground hover:text-primary">
                                  <Paperclip className="h-4 w-4" />
                              </Button>
                              <Button 
                                  size="icon" 
                                  className="h-10 w-10 rounded-xl bg-primary text-white shadow-lg shadow-primary/20"
                                  onClick={() => {
                                      if (chatMessage.trim()) {
                                          toast({ title: "Query Sent", description: "The vendor will respond shortly." });
                                          setChatMessage('');
                                      }
                                  }}
                              >
                                  <Send className="h-4 w-4" />
                              </Button>
                          </div>
                      </div>
                      <div className="mt-3 flex items-center justify-center gap-2">
                           <Bot className="h-3 w-3 text-primary" />
                           <p className="text-[8px] font-black uppercase tracking-widest text-muted-foreground/60">AI Smart Draft Active</p>
                      </div>
                  </div>
              </SheetContent>
          </Sheet>
      </div>

      <style jsx global>{`
        .no-scrollbar::-webkit-scrollbar {
            display: none;
        }
        .no-scrollbar {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}
