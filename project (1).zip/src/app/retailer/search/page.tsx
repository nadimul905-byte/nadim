
"use client";
import React, { useState, useEffect, useMemo, useCallback, Suspense } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search as SearchIcon, SlidersHorizontal, X, Image as ImageIcon, Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import Image from 'next/image';
import Link from 'next/link';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetClose,
  SheetFooter
} from "@/components/ui/sheet"
import { useSearchParams, useRouter } from 'next/navigation';
import { allMockProducts, type Product } from '../products/page';

// Define a type for the search result item structure
interface SearchResultItem extends Product {
    vendor: string;
    rating?: number;
}


const ProductResultCard = ({ product }: { product: SearchResultItem }) => (
  <Card className="w-full overflow-hidden">
    <Link href={`/retailer/products/${product.id}`}>
      <CardContent className="p-0">
        <div className="relative h-56 w-full">
          <Image src={product.image} alt={product.name} layout="fill" objectFit="cover" data-ai-hint={product.aiHint} />
        </div>
      </CardContent>
      <CardHeader className="p-3">
        <CardTitle className="text-base font-medium truncate">{product.name}</CardTitle>
        <CardDescription className="text-sm text-muted-foreground">{product.vendorName}</CardDescription>
        <div className="flex justify-between items-center pt-1">
            <p className="text-lg font-semibold text-primary">{product.price}</p>
            {product.rating && <Badge variant="outline">Rating: {product.rating.toFixed(1)} ★</Badge>}
        </div>
      </CardHeader>
    </Link>
  </Card>
);

function RetailerSearchContent() {
  const searchParamsHook = useSearchParams();
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResultItem[]>([]);
  const [filters, setFilters] = useState({ priceRange: [0, 500], minMoq: 1, vendorRating: 3, fabric: [] as string[], deliveryTime: 30 });
  const [appliedSearchTerm, setAppliedSearchTerm] = useState('');

  const qValueFromUrl = searchParamsHook.get('q');

  const performSearch = useCallback((term: string) => {
    const trimmedTermForSearch = term.trim().toLowerCase();
    setAppliedSearchTerm(term.trim());

    if (trimmedTermForSearch === '') {
      setSearchResults([]);
      return;
    }

    const searchKeywords = trimmedTermForSearch.split(/\s+/).filter(k => k.length > 0);

    const results = allMockProducts.filter(product => {
      const productNameLower = product.name.toLowerCase();
      const vendorNameLower = product.vendorName.toLowerCase();

      return searchKeywords.every(keyword =>
        productNameLower.includes(keyword) ||
        vendorNameLower.includes(keyword)
      );
    }).map(p => ({ ...p, vendor: p.vendorName, rating: Math.round((Math.random() * 1.5 + 3.5) * 10) / 10 }));

    setSearchResults(results);
  }, [setAppliedSearchTerm, setSearchResults]);

  useEffect(() => {
    if (qValueFromUrl) {
      if (qValueFromUrl !== searchTerm || qValueFromUrl !== appliedSearchTerm) {
        setSearchTerm(qValueFromUrl);
        performSearch(qValueFromUrl);
      }
    } else {
      if (searchTerm || appliedSearchTerm) {
        setSearchTerm('');
        performSearch('');
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [qValueFromUrl, performSearch]); 

  const handleSearch = () => {
    const termToSearch = searchTerm.trim();
    let newQueryString = "";
    if (termToSearch) {
        newQueryString = `?q=${encodeURIComponent(termToSearch)}`;
    }
    if (termToSearch !== qValueFromUrl || !termToSearch && qValueFromUrl) {
      router.push(`/retailer/search${newQueryString}`);
    } else if (termToSearch && termToSearch === qValueFromUrl && termToSearch !== appliedSearchTerm) {
      performSearch(termToSearch);
    }
  };

  const clearSearch = () => {
    setSearchTerm('');
    setAppliedSearchTerm('');
    setSearchResults([]);
    router.push(`/retailer/search`);
  };

  const fabrics = ["Cotton", "Silk", "Polyester", "Wool", "Linen", "Leather", "Denim"];

  return (
    <div className="space-y-6">
      <div className="flex gap-2 items-center sticky top-[calc(theme(spacing.16)_+_1px)] bg-background py-3 z-30">
        <div className="relative flex-grow">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search for products, brands, keywords..."
            className="pl-10 pr-28 py-3 text-base h-12"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handleSearch();
              }
            }}
          />
          {searchTerm && (
            <Button variant="ghost" size="icon" onClick={clearSearch} className="absolute right-14 top-1/2 -translate-y-1/2 h-8 w-8">
              <X className="h-5 w-5 text-muted-foreground" />
            </Button>
          )}
          <Button variant="ghost" size="icon" className="absolute right-2 top-1/2 -translate-y-1/2 h-10 w-10">
            <ImageIcon className="h-5 w-5 text-muted-foreground" />
          </Button>
        </div>
        <Button onClick={handleSearch} className="h-12">Search</Button>
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="h-12 w-12">
                <SlidersHorizontal className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent>
            <SheetHeader>
              <SheetTitle>Filters</SheetTitle>
              <SheetDescription>Refine your search results.</SheetDescription>
            </SheetHeader>
            <div className="py-4 space-y-6">
                <div>
                    <Label>Price Range: ${filters.priceRange[0]} - ${filters.priceRange[1] === 1000 ? '1000+' : filters.priceRange[1]}</Label>
                    <Slider defaultValue={[filters.priceRange[0], filters.priceRange[1]]} max={1000} step={10} onValueChange={(value) => setFilters(f => ({...f, priceRange: value}))} />
                </div>
                 <div>
                    <Label>Minimum Order Quantity (MOQ): {filters.minMoq}</Label>
                    <Slider defaultValue={[filters.minMoq]} max={100} step={1} onValueChange={(value) => setFilters(f => ({...f, minMoq: value[0]}))} />
                </div>
                 <div>
                    <Label>Vendor Rating (min): {filters.vendorRating} ★</Label>
                    <Slider defaultValue={[filters.vendorRating]} max={5} step={0.5} onValueChange={(value) => setFilters(f => ({...f, vendorRating: value[0]}))} />
                </div>
                <div>
                    <Label>Fabric/Material</Label>
                    <div className="space-y-2 mt-2 h-40 overflow-y-auto border p-2 rounded-md">
                        {fabrics.map(fabric => (
                            <div key={fabric} className="flex items-center space-x-2">
                                <Checkbox id={`fabric-${fabric}`} onCheckedChange={(checked) => setFilters(f => ({...f, fabric: checked ? [...f.fabric, fabric] : f.fabric.filter(fab => fab !== fabric)}))} />
                                <Label htmlFor={`fabric-${fabric}`} className="font-normal">{fabric}</Label>
                            </div>
                        ))}
                    </div>
                </div>
                <div>
                    <Label>Delivery Time (max days): {filters.deliveryTime}</Label>
                    <Slider defaultValue={[filters.deliveryTime]} max={90} step={1} onValueChange={(value) => setFilters(f => ({...f, deliveryTime: value[0]}))} />
                </div>
            </div>
            <SheetFooter>
              <SheetClose asChild>
                <Button type="button">Apply Filters</Button>
              </SheetClose>
            </SheetFooter>
          </SheetContent>
        </Sheet>
      </div>

      {appliedSearchTerm && searchResults.length > 0 ? (
        <>
          <p className="text-sm text-muted-foreground">Showing {searchResults.length} results for "{appliedSearchTerm}"</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {searchResults.map(product => <ProductResultCard key={product.id} product={product} />)}
          </div>
        </>
      ) : appliedSearchTerm && searchResults.length === 0 ? (
        <p className="text-center text-muted-foreground py-8">No results found for "{appliedSearchTerm}". Try a different keyword or check your spelling.</p>
      ) : (
         <div className="text-center py-12">
            <SearchIcon className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
            <h2 className="text-xl font-semibold">Search for Products</h2>
            <p className="text-muted-foreground">Enter keywords, product names, or use image search.</p>
        </div>
      )}
    </div>
  );
}

export default function RetailerSearchPage() {
  return (
    <Suspense fallback={<div className="flex justify-center py-20"><Loader2 className="animate-spin h-10 w-10 text-primary" /></div>}>
      <RetailerSearchContent />
    </Suspense>
  )
}
