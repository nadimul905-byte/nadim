
"use client";

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Save, Globe, DollarSign, Loader2 } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';

const languages = [
  { value: 'en-US', label: 'English (United States)' },
  { value: 'bn-BD', label: 'বাংলা (বাংলাদেশ)' }, // Bangla (Bangladesh)
  { value: 'es-ES', label: 'Español (España)' },
  { value: 'fr-FR', label: 'Français (France)' },
  { value: 'de-DE', label: 'Deutsch (Deutschland)' },
  { value: 'ja-JP', label: '日本語 (日本)' },
  { value: 'ar-SA', label: 'العربية (المملكة العربية السعودية)' }, // Arabic (Saudi Arabia)
  { value: 'hi-IN', label: 'हिन्दी (भारत)' }, // Hindi (India)
  { value: 'zh-CN', label: '中文 (中国)' }, // Chinese (China)
];

const currencies = [
  { value: 'USD', label: 'USD - United States Dollar' },
  { value: 'BDT', label: 'BDT - Bangladeshi Taka' },
  { value: 'EUR', label: 'EUR - Euro' },
  { value: 'GBP', label: 'GBP - British Pound Sterling' },
  { value: 'JPY', label: 'JPY - Japanese Yen' },
  { value: 'CAD', label: 'CAD - Canadian Dollar' },
];

export default function RetailerLanguageCurrencySettingsPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [selectedLanguage, setSelectedLanguage] = useState('en-US');
  const [selectedCurrency, setSelectedCurrency] = useState('USD');
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    toast({
      title: "Settings Saved",
      description: `Language set to ${languages.find(l => l.value === selectedLanguage)?.label} and currency to ${selectedCurrency}. (Mocked)`,
    });
    console.log("Saved Retailer Language & Currency:", { selectedLanguage, selectedCurrency });
    setIsSaving(false);
    // Potentially update a global context or localStorage here
  };

  return (
    <div className="space-y-6 max-w-xl mx-auto">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => router.back()} aria-label="Back to settings">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-headline font-semibold">Language & Currency</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Localization Preferences</CardTitle>
          <CardDescription>Choose your preferred language and currency for the platform.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label htmlFor="language-select" className="flex items-center mb-1">
              <Globe className="h-4 w-4 mr-2 text-muted-foreground" />
              Display Language
            </Label>
            <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
              <SelectTrigger id="language-select">
                <SelectValue placeholder="Select language" />
              </SelectTrigger>
              <SelectContent>
                {languages.map(lang => (
                  <SelectItem key={lang.value} value={lang.value}>{lang.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="currency-select" className="flex items-center mb-1">
              <DollarSign className="h-4 w-4 mr-2 text-muted-foreground" />
              Default Currency
            </Label>
            <Select value={selectedCurrency} onValueChange={setSelectedCurrency}>
              <SelectTrigger id="currency-select">
                <SelectValue placeholder="Select currency" />
              </SelectTrigger>
              <SelectContent>
                {currencies.map(curr => (
                  <SelectItem key={curr.value} value={curr.value}>{curr.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground mt-1">
              This will be the default currency for displaying prices on the platform.
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={isSaving} size="lg">
          {isSaving ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Save className="mr-2 h-5 w-5" />}
          Save Preferences
        </Button>
      </div>
    </div>
  );
}
