"use client";
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BellRing, Tag, Truck, MessageSquare } from 'lucide-react';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';

export const notifications = [
  { id: 1, type: "Promotion", title: "Summer Sale is ON!", message: "Get up to 50% off on selected items. Ends soon!", time: "2h ago", icon: Tag, read: false, link: "/retailer/products?category=sale" },
  { id: 2, type: "Order Update", title: "Order #ORD002 Shipped", message: "Your order for Stylish Sneakers has been shipped.", time: "1d ago", icon: Truck, read: false, link: "/retailer/orders/ORD002" },
  { id: 3, type: "New Message", title: "Message from Chic Designs Co.", message: "Regarding your custom blouse inquiry...", time: "3d ago", icon: MessageSquare, read: true, link: "/retailer/messages/chat123" },
  { id: 4, type: "Bid Alert", title: "New Bid on 'Custom Leather Boots'", message: "Vendor 'Artisan Footwear' placed a bid.", time: "5d ago", icon: BellRing, read: true, link: "/retailer/custom-requests/bids/req007" },
];

export default function RetailerNotificationsPage() {
  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <h1 className="text-3xl font-headline font-semibold">Notifications</h1>
      
      {notifications.length > 0 ? (
        notifications.map(notif => {
          const Icon = notif.icon;
          return (
            <Link href={notif.link || '#'} key={notif.id}>
              <Card className={`hover:shadow-lg transition-shadow ${!notif.read ? 'border-primary border-2' : ''}`}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      <Icon className="h-6 w-6 text-primary" />
                      <CardTitle className="text-lg">{notif.title}</CardTitle>
                    </div>
                    {!notif.read && <Badge variant="default" className="bg-primary text-primary-foreground">New</Badge>}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-1">{notif.message}</p>
                  <p className="text-xs text-muted-foreground/70">{notif.time}</p>
                </CardContent>
              </Card>
            </Link>
          );
        })
      ) : (
        <Card>
          <CardContent className="py-12 text-center">
            <BellRing className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold">No New Notifications</h3>
            <p className="text-muted-foreground">You're all caught up!</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
