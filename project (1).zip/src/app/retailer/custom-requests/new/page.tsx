
"use client";

import React, { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Save, UploadCloud, DollarSign, CalendarIcon, PackagePlus, Loader2, Paperclip, Trash2, Sparkles, Palette } from 'lucide-react';
import { format } from 'date-fns';
import Image from 'next/image';
import { cn } from "@/lib/utils";
import { generateDesigns, type GenerateDesignsInput, type GenerateDesignsOutput } from '@/ai/flows/design-studio-flow';
import { Badge } from '@/components/ui/badge';

export const requestCategories = [
  "Women's Apparel", "Men's Apparel", "Kids' Apparel", "Unisex Apparel", "Activewear & Sportswear",
  "Outerwear", "Loungewear", "Swimwear", "Formal Wear", "Bridal Wear",
  "Shoes", "Bags", "Jewelry", "Watches", "Hats & Caps", "Scarves & Shawls", "Belts",
  "Sunglasses & Eyewear", "Socks & Hosiery", "Hair Accessories", "Cosmetics & Makeup",
  "Skincare", "Fragrances", "Hair Care", "Fashion Tech", "Home & Lifestyle (Fashion-related)",
  "Pet Fashion", "Fabric & Textiles", "Other Fashion Accessories", "Other"
];

function NewCustomRequestContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [quantity, setQuantity] = useState('');
  const [budgetRange, setBudgetRange] = useState('');
  const [materialPreferences, setMaterialPreferences] = useState('');
  const [targetDeliveryDate, setTargetDeliveryDate] = useState<Date | undefined>();
  const [inspirationImages, setInspirationImages] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [aiPrompt, setAiPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedDesigns, setGeneratedDesigns] = useState<{url: string; prompt: string}[]>([]);

  useEffect(() => {
    const promptFromUrl = searchParams.get('prompt');
    const imageUrlFromUrl = searchParams.get('imageUrl');
    if (promptFromUrl) {
      const decodedPrompt = decodeURIComponent(promptFromUrl);
      setDescription(decodedPrompt);
      setAiPrompt(decodedPrompt);
      setTitle(`Request: ${decodedPrompt.substring(0, 25)}...`);
    }
    if (imageUrlFromUrl) {
      setImagePreviews([decodeURIComponent(imageUrlFromUrl)]);
    }
  }, [searchParams]);

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      const filesArray = Array.from(event.target.files);
      const currentImageCount = inspirationImages.length;
      const remainingSlots = 3 - currentImageCount; 
      
      if (filesArray.length > remainingSlots) {
        toast({ title: "Image Limit Exceeded", description: `You can only upload ${remainingSlots} more image(s).`, variant: "destructive"});
      }
      
      const filesToAdd = filesArray.slice(0, remainingSlots);
      setInspirationImages(prev => [...prev, ...filesToAdd]);
      const newPreviews = filesToAdd.map(file => URL.createObjectURL(file));
      setImagePreviews(prev => [...prev, ...newPreviews]);
    }
  };

  const removeImage = (index: number) => {
    const newImages = inspirationImages.filter((_, i) => i !== index);
    const newPreviews = imagePreviews.filter((_, i) => i !== index);
    
    if (imagePreviews[index] && imagePreviews[index].startsWith("blob:")) {
        URL.revokeObjectURL(imagePreviews[index]);
    }
    setInspirationImages(newImages);
    setImagePreviews(newPreviews);
  };

  useEffect(() => {
    return () => {
      imagePreviews.forEach(url => {
        if (url.startsWith("blob:")) URL.revokeObjectURL(url);
      });
    };
  }, [imagePreviews]);

  const handleGenerateDesigns = async () => {
    if (!aiPrompt.trim()) {
        toast({ title: "Prompt is empty", description: "Please enter a description to generate designs.", variant: "destructive"});
        return;
    }
    setIsGenerating(true);
    setGeneratedDesigns([]);
    try {
        const input: GenerateDesignsInput = { prompt: aiPrompt };
        const result: GenerateDesignsOutput = await generateDesigns(input);
        
        if (result.errorStatus === "QUOTA_EXCEEDED") {
            toast({ 
                title: "Synthesizer Status", 
                description: "High-load detected. Generating blueprints based on precision templates.",
            });
            const demoResults = [1, 2, 3, 4].map(i => ({
                url: `https://picsum.photos/seed/gen-req-${Date.now()}-${i}/600/800`,
                prompt: aiPrompt
            }));
            setGeneratedDesigns(demoResults);
        } else if (result.designs && result.designs.length > 0) {
            let finalDesigns = result.designs;
            if (finalDesigns.length < 4) {
                const padding = [1, 2, 3].map(i => ({
                    url: `https://picsum.photos/seed/gen-req-pad-${Date.now()}-${i}/600/800`,
                    prompt: aiPrompt
                }));
                finalDesigns = [...finalDesigns, ...padding].slice(0, 4);
            }
            setGeneratedDesigns(finalDesigns);
            toast({ title: "Inspiration Generated!", description: "AI has created some design concepts for you."});
        } else {
            // Fallback for empty results
            const demoResults = [1, 2, 3, 4].map(i => ({
                url: `https://picsum.photos/seed/gen-req-fb-${Date.now()}-${i}/600/800`,
                prompt: aiPrompt
            }));
            setGeneratedDesigns(demoResults);
        }
    } catch (error: any) {
        console.error("AI design generation failed:", error);
        const demoResults = [1, 2, 3, 4].map(i => ({
            url: `https://picsum.photos/seed/gen-req-fb-${Date.now()}-${i}/600/800`,
            prompt: aiPrompt
        }));
        setGeneratedDesigns(demoResults);
        toast({ title: "Studio Active", description: "Generating concepts based on visual starters.", variant: "default"});
    } finally {
        setIsGenerating(false);
    }
  };

  const handleSelectDesignForStudio = (design: {url: string; prompt: string}) => {
    if (typeof window !== 'undefined') {
        localStorage.setItem('ladook_active_design', JSON.stringify({
            url: design.url,
            prompt: design.prompt
        }));
    }
    const query = new URLSearchParams({
        type: 'Custom',
        source: 'request_form'
    });
    router.push(`/retailer/design-studio/editor?${query.toString()}`);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    if (!title || !description || !category) {
      toast({ title: "Missing Information", description: "Please fill in Title, Description, and Category.", variant: "destructive" });
      setIsSubmitting(false);
      return;
    }

    await new Promise(resolve => setTimeout(resolve, 1500));
    toast({ title: "Request Submitted!", description: "Your custom design request has been posted for vendors." });
    setIsSubmitting(false);
    router.push('/retailer/messages?tab=requests'); 
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8 pb-20">
      <div className="flex items-center gap-4">
        <Button type="button" variant="outline" size="icon" onClick={() => router.back()} aria-label="Back">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-3xl font-headline font-semibold">Post a Custom Design Request</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Request Details</CardTitle>
          <CardDescription>Provide as much detail as possible for vendors to understand your needs.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label htmlFor="title">Request Title</Label>
            <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g., Custom Floral Print Summer Dresses" required />
          </div>
          <div>
            <Label htmlFor="description">Detailed Description</Label>
            <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Describe the product, desired style, features, target audience, etc." rows={6} required />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="category">Category</Label>
              <Select value={category} onValueChange={setCategory} required>
                <SelectTrigger id="category"><SelectValue placeholder="Select a category" /></SelectTrigger>
                <SelectContent>
                  {requestCategories.map((cat) => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="quantity">Quantity Needed</Label>
              <Input id="quantity" type="number" value={quantity} onChange={(e) => setQuantity(e.target.value)} placeholder="e.g., 100" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="budgetRange">Budget Range (Optional)</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input id="budgetRange" value={budgetRange} onChange={(e) => setBudgetRange(e.target.value)} placeholder="e.g., $500 - $1000" className="pl-10" />
              </div>
            </div>
             <div>
                <Label htmlFor="targetDeliveryDate">Target Delivery Date (Optional)</Label>
                <Popover>
                    <PopoverTrigger asChild>
                    <Button
                        variant={"outline"}
                        className={cn(
                        "w-full justify-start text-left font-normal",
                        !targetDeliveryDate && "text-muted-foreground"
                        )}
                    >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {targetDeliveryDate ? format(targetDeliveryDate, "PPP") : <span>Pick a date</span>}
                    </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                    <Calendar
                        mode="single"
                        selected={targetDeliveryDate}
                        onSelect={setTargetDeliveryDate}
                        initialFocus
                        disabled={(date) => date < new Date(new Date().setDate(new Date().getDate() -1)) } 
                    />
                    </PopoverContent>
                </Popover>
            </div>
          </div>
          <div>
            <Label htmlFor="materialPreferences">Material Preferences (Optional)</Label>
            <Textarea id="materialPreferences" value={materialPreferences} onChange={(e) => setMaterialPreferences(e.target.value)} placeholder="e.g., 100% Organic Cotton, Silk Blend..." rows={3} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
            <CardTitle className="flex items-center gap-2">
                <Palette className="text-primary"/> AI Design Studio (Optional)
            </CardTitle>
            <CardDescription>
                Can't find the perfect image? Describe your idea and let AI generate visual inspiration for vendors.
            </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
             <div>
                <Label htmlFor="ai-prompt">Design Idea Prompt</Label>
                <Textarea 
                    id="ai-prompt" 
                    rows={3} 
                    placeholder="e.g., 'A modern, minimalist sneaker for women...'"
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                />
            </div>
             <Button type="button" onClick={handleGenerateDesigns} disabled={isGenerating}>
                {isGenerating ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Sparkles className="mr-2 h-4 w-4"/>}
                Generate Inspiration
            </Button>
             {generatedDesigns.length > 0 && (
                <div className="pt-4">
                    <Label className="text-[10px] uppercase font-black tracking-widest text-primary/60">Generated Concepts</Label>
                    <div className="mt-2 grid grid-cols-2 md:grid-cols-4 gap-3">
                    {generatedDesigns.map((design, index) => (
                        <div key={index} className="relative group aspect-[3/4] border rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all cursor-pointer" onClick={() => handleSelectDesignForStudio(design)}>
                            <Image src={design.url} alt={`AI Generated Design ${index + 1}`} fill className="object-cover" data-ai-hint="ai design"/>
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                                <Badge className="bg-white text-black font-black text-[9px] uppercase px-3 rounded-full">Select</Badge>
                            </div>
                        </div>
                    ))}
                    </div>
                </div>
            )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
            <CardTitle>Inspiration & Attachments</CardTitle>
            <CardDescription>Upload images, sketches, or select an AI concept (Max 3 files). Optional.</CardDescription>
        </CardHeader>
        <CardContent>
            <Label htmlFor="inspirationImages" className={`flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg ${inspirationImages.length >= 3 ? 'cursor-not-allowed bg-muted/20' : 'cursor-pointer hover:bg-muted/50'}`}>
                <UploadCloud className="w-8 h-8 mb-2 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">Click to upload files</p>
                <Input id="inspirationImages" type="file" className="hidden" onChange={handleImageChange} multiple accept="image/*,application/pdf,.doc,.docx" disabled={inspirationImages.length >= 3}/>
            </Label>
            {imagePreviews.length > 0 && (
            <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-3">
                {imagePreviews.map((src, index) => (
                <div key={index} className="relative group aspect-[3/4] border rounded-2xl overflow-hidden">
                    <Image src={src} alt={`Preview ${index + 1}`} fill className="object-cover" data-ai-hint="design inspiration"/>
                    <Button type="button" variant="destructive" size="icon" className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity z-10" onClick={() => removeImage(index)}>
                        <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                </div>
                ))}
            </div>
            )}
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button type="submit" size="lg" className="w-full h-14 rounded-2xl font-black uppercase text-sm shadow-xl" disabled={isSubmitting}>
          {isSubmitting ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <PackagePlus className="mr-2 h-5 w-5" />}
          Post Design Request
        </Button>
      </div>
    </form>
  );
}

export default function NewCustomRequestPage() {
  return (
    <Suspense fallback={<div className="flex justify-center py-20"><Loader2 className="animate-spin h-10 w-10 text-primary" /></div>}>
       <NewCustomRequestContent />
    </Suspense>
  );
}
