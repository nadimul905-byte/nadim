"use client";

import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { mockRequests, type CustomRequest } from '@/app/vendor/requests/page';
import { summarizeBids, type SummarizeBidsInput, type SummarizeBidsOutput } from '@/ai/flows/summarize-bids';
import { ArrowLeft, MessageSquare, Sparkles, Loader2, Star, Calendar, Tag, CheckCircle, FileText, Package } from 'lucide-react';
import Link from 'next/link';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

interface Bid {
  id: string;
  vendorName: string;
  vendorSlug: string;
  vendorAvatar: string;
  vendorAvatarAiHint: string;
  vendorRating: number;
  price: number;
  estimatedDeliveryDate: string;
  message: string;
  sampleImage?: string;
  sampleImageAiHint?: string;
  timestamp: string;
}

export const mockBids: Bid[] = [
  {
    id: 'bid001', vendorName: 'Chic Designs Co.', vendorSlug: 'chic-designs-co', vendorAvatar: 'https://images.unsplash.com/photo-1590874315261-788881621f7a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwbG9nb3xlbnwwfHx8fDE3NDg4NjUyODl8MA&ixlib=rb-4.1.0&q=80&w=1080', vendorAvatarAiHint: 'fashion logo',
    vendorRating: 4.8, price: 950, estimatedDeliveryDate: '2024-08-30',
    message: "We specialize in high-quality silk printing and can match your floral patterns perfectly.",
    sampleImage: 'https://images.unsplash.com/photo-1521406068416-1ebaaf984024?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw5fHxzaWxrJTIwc2NhcmZlc3xlbnwwfHx8fDE3NDg3ODU4NTd8MA&ixlib=rb-4.1.0&q=80&w=1080', sampleImageAiHint: 'silk scarf',
    timestamp: '1d ago'
  },
];

const BidCard = ({ bid, onAccept, isAccepting, isAwarded }: { bid: Bid, onAccept: (bidId: string) => void, isAccepting: boolean, isAwarded: boolean }) => (
    <Card className="shadow-md hover:shadow-lg transition-shadow">
        <CardHeader className="flex flex-row items-start gap-4">
            <Link href={`/retailer/vendors/${bid.vendorSlug}`} className="flex-shrink-0">
                <Avatar className="h-12 w-12 border">
                    <AvatarImage src={bid.vendorAvatar} alt={bid.vendorName} data-ai-hint={bid.vendorAvatarAiHint}/>
                    <AvatarFallback>{bid.vendorName.charAt(0)}</AvatarFallback>
                </Avatar>
            </Link>
            <div className="flex-1">
                <Link href={`/retailer/vendors/${bid.vendorSlug}`} className="hover:underline">
                    <CardTitle className="text-lg">{bid.vendorName}</CardTitle>
                </Link>
                <div className="flex items-center text-xs text-muted-foreground">
                    <Star className="w-3 h-3 mr-1 fill-yellow-400 text-yellow-400"/> {bid.vendorRating}/5.0
                </div>
            </div>
            <div className="text-right">
                <p className="text-xl font-bold text-primary">${bid.price.toFixed(2)}</p>
                <p className="text-xs text-muted-foreground">{bid.timestamp}</p>
            </div>
        </CardHeader>
        <CardContent className="space-y-4">
            {bid.sampleImage && (
                <div className="relative aspect-video w-full rounded-md overflow-hidden bg-muted">
                    <Image src={bid.sampleImage} alt="Sample Image" layout="fill" objectFit="cover" data-ai-hint={bid.sampleImageAiHint} />
                </div>
            )}
            <p className="text-sm text-muted-foreground italic">"{bid.message}"</p>
            <div className="text-sm flex items-center text-muted-foreground">
                <Calendar className="h-4 w-4 mr-2"/> Estimated Delivery: {bid.estimatedDeliveryDate}
            </div>
        </CardContent>
        <CardFooter className="grid grid-cols-2 gap-2">
            <Button variant="outline" asChild>
                <Link href={`/retailer/messages/${bid.vendorSlug}`}><MessageSquare className="h-4 w-4 mr-2"/> Chat</Link>
            </Button>
             <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button disabled={isAwarded}>
                  <CheckCircle className="h-4 w-4 mr-2"/> {isAwarded ? "Awarded" : "Accept Bid"}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Accept this Bid?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will award the request to <span className="font-bold">{bid.vendorName}</span>.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={() => onAccept(bid.id)}>
                    {isAccepting ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : null}
                    Yes, Accept
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
        </CardFooter>
    </Card>
)

export default function RetailerRequestDetailsPage() {
  const router = useRouter();
  const params = useParams();
  const requestId = params.requestId as string;
  const { toast } = useToast();

  const [request, setRequest] = useState<CustomRequest | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [isAccepting, setIsAccepting] = useState(false);
  const [summary, setSummary] = useState<string | null>(null);

  useEffect(() => {
    if (requestId) {
      const foundRequest = mockRequests.find(r => r.id === requestId);
      if (foundRequest) {
        setRequest(foundRequest);
      } else {
        toast({ title: "Error", description: "Custom request not found.", variant: "destructive" });
        router.push('/retailer/messages?tab=requests');
      }
    }
    setLoading(false);
  }, [requestId, router, toast]);

  const handleSummarizeBids = async () => {
    if (!request) return;
    setIsSummarizing(true);
    setSummary(null);

    const bidsForAISummary = mockBids.map(b => {
      const { sampleImage, sampleImageAiHint, ...rest } = b;
      return rest;
    });

    const summarizeInput: SummarizeBidsInput = {
      requestDescription: request.descriptionFull || request.descriptionSnippet,
      bids: bidsForAISummary,
    };

    try {
      const result: SummarizeBidsOutput = await summarizeBids(summarizeInput);
      setSummary(result.summary);
      toast({title: "Bids Summarized"});
    } catch (error) {
      toast({ title: "Error", description: "Could not summarize bids.", variant: "destructive" });
    } finally {
      setIsSummarizing(false);
    }
  };
  
  const handleAcceptBid = async (bidId: string) => {
    if (!request) return;
    setIsAccepting(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    const requestIndex = mockRequests.findIndex(r => r.id === request.id);
    if(requestIndex !== -1) { mockRequests[requestIndex].status = "Awarded"; }
    setRequest(prev => prev ? { ...prev, status: "Awarded" } : null);
    setIsAccepting(false);
    toast({ title: "Bid Accepted!" });
  };

  if (loading) {
    return <div className="space-y-4"><Skeleton className="h-10 w-24" /><Skeleton className="h-48 w-full" /></div>;
  }

  if (!request) return null;

  const isAwarded = request.status === "Awarded" || request.status === "Bidding Closed";

  return (
    <div className="space-y-8">
      <Button variant="outline" onClick={() => router.push('/retailer/messages?tab=requests')}>
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to My Requests
      </Button>

      <Card>
        <CardHeader>
            <div className="flex justify-between items-start">
                <div>
                    <CardTitle className="text-2xl font-headline">{request.title}</CardTitle>
                    <CardDescription>Posted on {request.datePosted}</CardDescription>
                </div>
                <Badge variant={request.status === 'Open' ? 'default' : 'secondary'}>{request.status}</Badge>
            </div>
        </CardHeader>
        <CardContent>
            {request.image && (
                <div className="relative w-full aspect-video rounded-lg overflow-hidden bg-muted mb-4">
                    <Image src={request.image} alt={request.title} fill className="object-cover" data-ai-hint={request.aiHint} />
                </div>
            )}
            <p>{request.descriptionFull || request.descriptionSnippet}</p>
        </CardContent>
      </Card>
      
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-semibold">Bids Received ({mockBids.length})</h2>
          <Button onClick={handleSummarizeBids} disabled={isSummarizing || mockBids.length === 0}>
            {isSummarizing ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Sparkles className="mr-2 h-4 w-4" />}
            Summarize Bids (AI)
          </Button>
        </div>

        {summary && (
            <Card className="mb-6 bg-secondary/50">
                <CardHeader><CardTitle className="text-lg flex items-center"><Sparkles className="h-5 w-5 mr-2 text-primary"/>AI Bid Summary</CardTitle></CardHeader>
                <CardContent><p className="text-muted-foreground whitespace-pre-wrap">{summary}</p></CardContent>
            </Card>
        )}
        
        <div className="grid md:grid-cols-2 gap-6">
            {mockBids.map(bid => <BidCard key={bid.id} bid={bid} onAccept={handleAcceptBid} isAccepting={isAccepting} isAwarded={isAwarded} />)}
        </div>
      </div>
    </div>
  );
}
