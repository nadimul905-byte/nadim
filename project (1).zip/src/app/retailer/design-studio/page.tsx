"use client";

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { 
  Sparkles, 
  ArrowRight, 
  Zap, 
  Lightbulb,
  MessageSquare,
  Video
} from 'lucide-react';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import Image from 'next/image';

const visualStarters = [
    "Minimalist sustainable sneaker made from hemp and recycled rubber.",
    "Bohemian floral maxi dress with delicate lace detailing and bell sleeves.",
    "Urban utility backpack with modular compartments and waterproof zippers.",
    "Elegant silver necklace inspired by celestial constellations."
];

export default function RetailerDesignStudioHub() {
    const router = useRouter();
    const [prompt, setPrompt] = useState(visualStarters[0]);

    const handleShuffle = () => {
        const idx = Math.floor(Math.random() * visualStarters.length);
        setPrompt(visualStarters[idx]);
    };

    return (
        <div className="space-y-6 max-w-xs mx-auto px-1 pb-20">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-headline font-bold">Concept Hub</h1>
                    <p className="text-muted-foreground text-[10px] font-black uppercase tracking-widest">AI Design Studio</p>
                </div>
                <Badge variant="outline" className="bg-primary/5 text-primary border-primary/20 text-[10px] font-bold rounded-full px-3">
                    BETA
                </Badge>
            </div>

            <Card className="rounded-[2.5rem] bg-zinc-900 text-white border-none shadow-2xl overflow-hidden relative" asChild>
                <div className="relative">
                    <div className="absolute top-0 right-0 p-8 opacity-10">
                        <Sparkles className="h-24 w-24" />
                    </div>
                    <CardHeader className="p-8 pb-4">
                        <div>
                            <CardTitle className="text-2xl font-headline font-black leading-tight text-white">
                                Manifest your <span className="text-primary italic">vision.</span>
                            </CardTitle>
                            <CardDescription className="text-zinc-400 text-xs font-medium mt-2">
                                Describe the product you want to source, and let AI generate visual blueprints for your custom request.
                            </CardDescription>
                        </div>
                    </CardHeader>
                    <CardContent className="px-8 pb-8">
                        <div className="p-4 bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 space-y-2">
                            <div className="flex items-center justify-between">
                                <span className="text-[8px] font-black uppercase tracking-widest text-zinc-500">Draft Blueprint</span>
                                <Button variant="ghost" size="xs" onClick={handleShuffle} className="h-5 text-[9px] text-primary hover:bg-primary/10">Shuffle</Button>
                            </div>
                            <Textarea 
                                value={prompt}
                                onChange={(e) => setPrompt(e.target.value)}
                                className="bg-transparent border-none p-0 focus-visible:ring-0 resize-none italic text-sm font-medium text-white leading-relaxed min-h-[80px]"
                            />
                        </div>
                    </CardContent>
                    <CardFooter className="px-8 pb-8 pt-0">
                        <Button 
                            asChild
                            className="w-full h-14 rounded-2xl bg-white text-black hover:bg-zinc-200 font-black text-sm uppercase shadow-xl shadow-black/20"
                        >
                            <Link href={`/retailer/design-studio/generate-designs?prompt=${encodeURIComponent(prompt)}`}>
                                <Zap className="mr-2 h-4 w-4 fill-black" /> Generate Concepts
                            </Link>
                        </Button>
                    </CardFooter>
                </div>
            </Card>

            <div className="grid grid-cols-1 gap-4">
                <Card className="rounded-3xl hover:border-primary/50 transition-all cursor-pointer group shadow-sm" asChild>
                    <Link href="/retailer/custom-requests/new">
                        <CardHeader className="p-6">
                            <div className="flex items-center gap-4">
                                <div className="h-12 w-12 rounded-2xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                                    <MessageSquare className="h-6 w-6 text-primary" />
                                </div>
                                <div className="flex-1">
                                    <h3 className="text-sm font-bold">Start Custom Request</h3>
                                    <p className="text-[10px] text-muted-foreground font-medium">Post to the vendor feed</p>
                                </div>
                                <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-transform group-hover:translate-x-1" />
                            </div>
                        </CardHeader>
                    </Link>
                </Card>

                <Card className="rounded-3xl hover:border-primary/50 transition-all cursor-pointer group shadow-sm" asChild>
                    <Link href="/retailer/trends">
                        <CardHeader className="p-6">
                            <div className="flex items-center gap-4">
                                <div className="h-12 w-12 rounded-2xl bg-accent/10 flex items-center justify-center flex-shrink-0">
                                    <Lightbulb className="h-6 w-6 text-amber-600" />
                                </div>
                                <div className="flex-1">
                                    <h3 className="text-sm font-bold">Market Intelligence</h3>
                                    <p className="text-[10px] text-muted-foreground font-medium">See what's trending now</p>
                                </div>
                                <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-transform group-hover:translate-x-1" />
                            </div>
                        </CardHeader>
                    </Link>
                </Card>

                <Card className="rounded-3xl hover:border-primary/50 transition-all cursor-pointer group shadow-sm" asChild>
                    <Link href="/retailer/design-studio/marketing">
                        <CardHeader className="p-6">
                            <div className="flex items-center gap-4">
                                <div className="h-12 w-12 rounded-2xl bg-rose-500/10 flex items-center justify-center flex-shrink-0">
                                    <Video className="h-6 w-6 text-rose-600" />
                                </div>
                                <div className="flex-1">
                                    <h3 className="text-sm font-bold">AI Marketing Studio</h3>
                                    <p className="text-[10px] text-muted-foreground font-medium">Generate social campaigns</p>
                                </div>
                                <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-transform group-hover:translate-x-1" />
                            </div>
                        </CardHeader>
                    </Link>
                </Card>
            </div>

            <div className="pt-4 text-center">
                <p className="text-[8px] font-black uppercase tracking-[0.4em] text-muted-foreground mb-4">Inspiration Stream</p>
                <div className="grid grid-cols-2 gap-3">
                    {[1, 2, 3, 4].map(i => (
                        <div key={i} className="aspect-[3/4] rounded-2xl overflow-hidden relative border bg-muted shadow-sm hover:shadow-md transition-all">
                            <Image src={`https://picsum.photos/seed/studio_retail_${i}/400/600`} fill alt="Inspiration" className="object-cover" data-ai-hint="fashion inspiration" />
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
