"use client";

import React from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { ArrowLeft, Sparkles, CalendarDays, FileText, Send, CheckCircle2, Clock, Megaphone, ChevronRight } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

const mockManifests = [
    { id: 'CM-001', title: 'Summer Solstice Collection', date: '2024-07-28', status: 'Draft', type: 'Social Campaign', details: 'A comprehensive social media push for the upcoming high-summer collection. Focusing on high-contrast visuals and lifestyle imagery.' },
    { id: 'CM-002', title: 'Winter Heritage Lookbook', date: '2024-07-25', status: 'In Review', type: 'Technical Editorial', details: 'Technical lookbook for wholesale partners showcasing winter heritage textiles and construction details.' },
];

export default function CampaignManifestDetailPage() {
    const router = useRouter();
    const params = useParams();
    const manifestId = params.manifestId as string;
    
    const manifest = mockManifests.find(m => m.id === manifestId) || mockManifests[0];

    return (
        <div className="space-y-6 max-w-xs mx-auto px-1 pb-24 animate-in fade-in duration-500">
            <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => router.back()} className="rounded-full h-10 w-10 border-zinc-200 shadow-sm">
                    <ArrowLeft className="h-5 w-5 text-zinc-600" />
                </Button>
                <div>
                    <h1 className="text-xl font-headline font-black tracking-tight leading-tight">Manifest Audit</h1>
                    <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest">{manifest.id}</p>
                </div>
            </div>

            <Card className="rounded-[2rem] border shadow-md overflow-hidden bg-card transition-all ring-1 ring-zinc-200/50">
                <CardHeader className="p-6 pb-4 bg-muted/10 border-b border-dashed">
                    <div className="flex justify-between items-start">
                        <div className="space-y-1">
                            <CardTitle className="text-base font-black uppercase tracking-tight">{manifest.title}</CardTitle>
                            <div className="flex items-center gap-1.5 text-[9px] font-black uppercase text-muted-foreground tracking-widest">
                                <CalendarDays className="h-3 w-3" /> {manifest.date}
                            </div>
                        </div>
                        <Badge variant="outline" className="rounded-full text-[8px] font-black uppercase px-2 py-0.5 bg-background border-zinc-200 shadow-sm">{manifest.status}</Badge>
                    </div>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                    <div className="flex items-center gap-3">
                        <div className="h-9 w-9 rounded-2xl bg-primary/10 flex items-center justify-center">
                            <Megaphone className="h-4 w-4 text-primary" />
                        </div>
                        <span className="text-[10px] font-black uppercase tracking-widest text-zinc-800">{manifest.type}</span>
                    </div>
                    <Separator className="border-dashed" />
                    <p className="text-[11px] font-medium text-muted-foreground leading-relaxed italic border-l-2 border-primary/30 pl-4">
                        "{manifest.details}"
                    </p>
                </CardContent>
            </Card>

            <div className="space-y-4">
                <div className="flex items-center justify-between px-1">
                    <h2 className="text-[10px] font-black uppercase tracking-[0.3em] text-muted-foreground">Campaign Logic</h2>
                </div>
                <div className="space-y-3">
                    {['Asset Synthesis', 'Audience Mapping', 'Budget Allocation'].map((step, i) => (
                        <div key={step} className="p-4 bg-card border rounded-2xl flex items-center justify-between shadow-sm group hover:border-primary/20 transition-all">
                            <div className="flex items-center gap-3">
                                <div className="h-7 w-7 rounded-xl bg-zinc-100 flex items-center justify-center group-hover:bg-primary/5 transition-colors">
                                    <span className="text-[10px] font-black text-zinc-400 group-hover:text-primary transition-colors">{i + 1}</span>
                                </div>
                                <span className="text-[10px] font-black uppercase tracking-tight text-zinc-700">{step}</span>
                            </div>
                            <CheckCircle2 className="h-4 w-4 text-zinc-200 group-hover:text-green-500 transition-colors" />
                        </div>
                    ))}
                </div>
            </div>

            <Card className="rounded-[2rem] border-none bg-primary/5 shadow-none mt-6">
                <CardContent className="p-6 space-y-4">
                    <div className="flex items-center gap-2">
                        <Sparkles className="h-4 w-4 text-primary" />
                        <span className="text-[10px] font-black uppercase tracking-widest text-primary/80">AI Strategy Active</span>
                    </div>
                    <p className="text-[11px] font-medium text-primary/70 leading-relaxed italic border-l-2 border-primary/30 pl-4">
                        "I've identified a 15% drop in reach for minimalist themes this week. I recommend pivoting the manifest to include high-contrast textures."
                    </p>
                </CardContent>
            </Card>
            
            <Button className="w-full h-14 rounded-2xl bg-zinc-900 text-white hover:bg-zinc-800 font-black uppercase text-xs shadow-xl active:scale-95 transition-all">
                Commit Manifest <Send className="ml-2 h-4 w-4" />
            </Button>
        </div>
    );
}
