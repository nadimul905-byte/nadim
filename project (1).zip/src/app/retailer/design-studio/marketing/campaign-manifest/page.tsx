"use client";

import React from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { ArrowLeft, Megaphone, Plus, CalendarDays, FileText, ChevronRight, Sparkles, Send } from 'lucide-react';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';

const mockManifests = [
    { id: 'CM-001', title: 'Summer Solstice Collection', date: '2024-07-28', status: 'Draft', type: 'Social Campaign' },
    { id: 'CM-002', title: 'Winter Heritage Lookbook', date: '2024-07-25', status: 'In Review', type: 'Technical Editorial' },
];

export default function CampaignManifestPage() {
    const router = useRouter();

    return (
        <div className="space-y-6 max-w-xs mx-auto px-1 pb-20 animate-in fade-in duration-500">
            <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => router.back()} className="rounded-full h-10 w-10">
                    <ArrowLeft className="h-5 w-5" />
                </Button>
                <div>
                    <h1 className="text-xl font-headline font-bold">Campaign Manifest</h1>
                    <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest">Promotion Logic</p>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
                <Button className="h-14 rounded-2xl bg-zinc-900 text-white hover:bg-zinc-800 font-black uppercase text-xs shadow-lg gap-2">
                    <Plus className="h-4 w-4" /> New Manifest
                </Button>

                <div className="space-y-4 pt-4">
                    <p className="text-[9px] font-black uppercase tracking-[0.4em] text-muted-foreground">Active Drafts</p>
                    {mockManifests.map(manifest => (
                        <Card key={manifest.id} className="rounded-3xl border shadow-sm hover:border-primary/20 transition-all cursor-pointer bg-card overflow-hidden">
                            <CardHeader className="p-5 bg-muted/20 border-b border-dashed">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <CardTitle className="text-sm font-black uppercase tracking-tight">{manifest.title}</CardTitle>
                                        <p className="text-[9px] text-muted-foreground font-bold uppercase mt-1">{manifest.id} • {manifest.date}</p>
                                    </div>
                                    <Badge variant="outline" className="text-[8px] font-black uppercase rounded-full px-2 py-0.5">{manifest.status}</Badge>
                                </div>
                            </CardHeader>
                            <CardContent className="p-5 flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                    <div className="h-8 w-8 rounded-xl bg-primary/10 flex items-center justify-center">
                                        <FileText className="h-4 w-4 text-primary" />
                                    </div>
                                    <span className="text-[10px] font-bold text-zinc-600 uppercase tracking-tight">{manifest.type}</span>
                                </div>
                                <Button variant="ghost" size="icon" className="rounded-xl h-8 w-8" asChild>
                                    <Link href={`/retailer/design-studio/marketing/campaign-manifest/${manifest.id}`}>
                                        <ChevronRight className="h-4 w-4 text-primary" />
                                    </Link>
                                </Button>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            </div>

            <Card className="rounded-[2.5rem] bg-primary/5 border-none shadow-none mt-6">
                <CardContent className="p-6 space-y-4">
                    <div className="flex items-center gap-2">
                        <Sparkles className="h-4 w-4 text-primary" />
                        <span className="text-[10px] font-black uppercase tracking-widest text-primary/80">AI Strategy Active</span>
                    </div>
                    <p className="text-[11px] font-medium text-primary/70 leading-relaxed italic border-l-2 border-primary/30 pl-4">
                        "I've identified a 15% drop in reach for minimalist themes this week. I recommend pivoting the manifest to include high-contrast textures."
                    </p>
                </CardContent>
                <CardFooter className="px-6 pb-6 pt-0">
                    <Button variant="outline" className="w-full rounded-xl h-10 text-[9px] font-black uppercase tracking-widest border-primary/20 text-primary">
                        Apply Strategy <Send className="ml-2 h-3.5 w-3.5" />
                    </Button>
                </CardFooter>
            </Card>
        </div>
    );
}
