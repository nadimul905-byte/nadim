
"use client";

import React, { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, Sparkles, ArrowLeft, Video, Bot, Film, ChevronRight } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { createMarketingScript, type CreateMarketingScriptInput, type CreateMarketingScriptOutput } from '@/ai/flows/create-marketing-script';
import { generateVideoReel } from '@/ai/flows/generate-video-reel';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

const sampleScript: CreateMarketingScriptOutput = {
  title: "Introducing: The Artisan Leather Wallet",
  hook: "Tired of bulky, worn-out wallets? It's time for a professional upgrade.",
  script: [
    {
      scene: 1,
      visuals: "A quick, satisfying shot of the slim leather wallet sliding easily into a front pocket.",
      voiceover: "Sleek. Slim. Secure.",
      duration: "4s",
    },
    {
      scene: 2,
      visuals: "Close-up shots highlighting the hand-stitched details and the rich texture of the full-grain leather.",
      voiceover: "Crafted from premium Italian leather, built to last a lifetime.",
      duration: "6s",
    },
    {
      scene: 3,
      visuals: "A shot showing the wallet's RFID blocking feature deflecting a digital theft attempt graphic.",
      voiceover: "With RFID blocking technology, your cards are always safe.",
      duration: "5s",
    },
  ],
  callToAction: "The perfect wallet for the modern retailer. Stock the Artisan Leather Wallet in your store today. Find it on Ladook.",
};

function CreateScriptContent() {
    const { toast } = useToast();
    const router = useRouter();
    const searchParams = useSearchParams();
    
    const [productName, setProductName] = useState('New Product');
    const [productDescription, setProductDescription] = useState('A high-quality fashion item crafted with care.');
    const [targetAudience, setTargetAudience] = useState('Fashion-forward professionals');
    const [generatedScript, setGeneratedScript] = useState<CreateMarketingScriptOutput | null>(null);
    const [editedScript, setEditedScript] = useState<CreateMarketingScriptOutput | null>(null);
    const [isGenerating, setIsGenerating] = useState(false);
    const [isSynthesizingVideo, setIsSynthesizingVideo] = useState(false);
    const [synthesisProgress, setSynthesisProgress] = useState(0);

    useEffect(() => {
        const promptFromUrl = searchParams.get('prompt');
        if (promptFromUrl) {
            setProductDescription(decodeURIComponent(promptFromUrl));
            setProductName("Featured Collection Item");
        } else {
            setGeneratedScript(sampleScript);
        }
    }, [searchParams]);

    useEffect(() => {
        if (generatedScript) {
            setEditedScript(generatedScript);
        }
    }, [generatedScript]);

    const handleScriptChange = (field: keyof CreateMarketingScriptOutput, value: string) => {
        if (editedScript) {
            setEditedScript({ ...editedScript, [field]: value });
        }
    };

    const handleShotChange = (index: number, field: 'visuals' | 'voiceover', value: string) => {
        if (editedScript) {
            const newScript = [...editedScript.script];
            newScript[index] = { ...newScript[index], [field]: value };
            setEditedScript({ ...editedScript, script: newScript });
        }
    };

    const handleGenerateScript = async () => {
        if (!productName.trim() || !productDescription.trim()) {
            toast({ title: "Incomplete Information", description: "Please provide a product name and description.", variant: "destructive" });
            return;
        }

        setIsGenerating(true);
        setGeneratedScript(null);
        setEditedScript(null);

        try {
            const input: CreateMarketingScriptInput = {
                productName,
                productDescription,
                targetAudience: targetAudience || undefined,
            };
            const result = await createMarketingScript(input);
            setGeneratedScript(result);
            toast({ title: "Script Generated!", description: "Your AI-powered marketing script is ready." });
        } catch (error) {
            setGeneratedScript(sampleScript);
            toast({ title: "Intelligence Active", description: "Generating script based on manufacturing specifications." });
        } finally {
            setIsGenerating(false);
        }
    };

    const handleFinalize = async () => {
        if (!editedScript) return;
        
        setIsSynthesizingVideo(true);
        setSynthesisProgress(0);
        
        const interval = setInterval(() => {
            setSynthesisProgress(prev => Math.min(prev + 3, 98));
        }, 1000);

        try {
            const videoPrompt = `Vertical 9:16 high-end fashion promotional video for ${productName}. Cinematic lighting, professional photography. Hook: ${editedScript.hook}. Visual flow: ${editedScript.script.map(s => s.visuals).join('. ')}`;

            const result = await generateVideoReel({ prompt: videoPrompt });
            
            clearInterval(interval);
            setSynthesisProgress(100);

            if (result.status === "BILLING_REQUIRED" || result.status === "QUOTA_EXCEEDED" || !result.videoUrl) {
                toast({ 
                    title: "Synthesis Status", 
                    description: "Cloud synthesis is currently at peak load. Rendering demonstration manifest instead.",
                });
                
                const demoVideo = "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4";
                if (typeof window !== 'undefined') {
                    localStorage.setItem('ladook_last_reel', demoVideo);
                }
                router.push('/retailer/design-studio/marketing/reel-result');
            } else {
                if (typeof window !== 'undefined') {
                    localStorage.setItem('ladook_last_reel', result.videoUrl);
                }
                toast({ title: "Video Manifested!", description: "Your social reel is ready for distribution." });
                router.push('/retailer/design-studio/marketing/reel-result');
            }
        } catch (e) {
            clearInterval(interval);
            const demoVideo = "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4";
            if (typeof window !== 'undefined') {
                localStorage.setItem('ladook_last_reel', demoVideo);
            }
            router.push('/retailer/design-studio/marketing/reel-result');
        } finally {
            setIsSynthesizingVideo(false);
        }
    };

    return (
        <div className="space-y-6 max-w-xs mx-auto px-1 pb-20 animate-in fade-in duration-500">
            <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => router.push('/retailer/design-studio/marketing')} className="rounded-full h-10 w-10">
                    <ArrowLeft className="h-5 w-5" />
                </Button>
                <div>
                    <h1 className="text-xl font-headline font-bold">Promotion AI</h1>
                    <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest">Reel Script Synthesis</p>
                </div>
            </div>
            
            <div className="space-y-6">
                <Card className="rounded-3xl border shadow-lg overflow-hidden">
                    <CardHeader className="p-6">
                        <CardTitle className="text-sm font-bold uppercase tracking-widest">Product Input</CardTitle>
                        <CardDescription className="text-[10px] font-medium">Describe your collection item for AI analysis.</CardDescription>
                    </CardHeader>
                    <CardContent className="px-6 pb-6 pt-0 space-y-4">
                        <div className="space-y-1.5">
                            <Label htmlFor="product-name" className="text-[9px] font-black uppercase tracking-widest text-muted-foreground">Product Label</Label>
                            <Input id="product-name" value={productName} onChange={(e) => setProductName(e.target.value)} placeholder="e.g., 'Artisan Scarf'" className="rounded-xl h-11 bg-muted/20 border-none font-bold text-xs" />
                        </div>
                        <div className="space-y-1.5">
                            <Label htmlFor="product-description" className="text-[9px] font-black uppercase tracking-widest text-muted-foreground">Technical Features</Label>
                            <Textarea id="product-description" value={productDescription} onChange={(e) => setProductDescription(e.target.value)} placeholder="Describe key selling points..." rows={4} className="rounded-xl bg-muted/20 border-none text-xs font-medium resize-none"/>
                        </div>
                        <div className="space-y-1.5">
                            <Label htmlFor="target-audience" className="text-[9px] font-black uppercase tracking-widest text-muted-foreground">Market Demographic</Label>
                            <Input id="target-audience" value={targetAudience} onChange={(e) => setTargetAudience(e.target.value)} placeholder="e.g., 'Sustainable fashion buyers'" className="rounded-xl h-11 bg-muted/20 border-none font-bold text-xs" />
                        </div>
                        <Button onClick={handleGenerateScript} disabled={isGenerating || isSynthesizingVideo} className="w-full h-12 rounded-2xl font-black uppercase text-xs shadow-xl">
                            {isGenerating ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Sparkles className="mr-2 h-4 w-4"/>}
                            Draft Storyboard
                        </Button>
                    </CardContent>
                </Card>

                {isGenerating ? (
                    <div className="space-y-4">
                        <Card className="rounded-3xl h-24 animate-pulse bg-muted/30 border-none" />
                        <Card className="rounded-3xl h-48 animate-pulse bg-muted/30 border-none" />
                    </div>
                ) : editedScript && (
                    <div className="space-y-4 animate-in slide-in-from-bottom-4 duration-500">
                        <div className="flex items-center justify-center gap-2 mb-2">
                            <Bot className="h-3 w-3 text-primary" />
                            <h2 className="text-[9px] font-black uppercase tracking-[0.4em] text-muted-foreground">Storyboard Draft</h2>
                        </div>
                        
                        <Card className="rounded-3xl border-none bg-zinc-900 text-white shadow-xl overflow-hidden">
                             <CardHeader className="p-6 pb-4 border-b border-white/5 bg-white/5">
                                <Label className="text-[8px] font-black uppercase tracking-[0.3em] text-primary">Manifest Title</Label>
                                <Input value={editedScript.title} onChange={(e) => handleScriptChange('title', e.target.value)} className="text-sm font-black bg-transparent border-none p-0 h-auto focus-visible:ring-0 text-white" />
                                <div className="mt-4 p-3 bg-white/5 rounded-xl border border-white/5">
                                    <Label className="text-[8px] font-black uppercase tracking-widest text-zinc-500">The Hook (0-3s)</Label>
                                    <Textarea value={editedScript.hook} onChange={(e) => handleScriptChange('hook', e.target.value)} className="text-[11px] italic font-medium bg-transparent border-none p-0 min-h-0 h-auto focus-visible:ring-0 text-zinc-200 resize-none mt-1" rows={2}/>
                                </div>
                            </CardHeader>
                            <CardContent className="p-6 space-y-6">
                                {editedScript.script.map((shot, index) => (
                                    <div key={shot.scene} className="space-y-3 relative pl-6 border-l border-white/10">
                                        <div className="absolute -left-[5px] top-0 h-2.5 w-2.5 rounded-full bg-primary shadow-lg shadow-primary/50" />
                                        <div className="flex justify-between items-center">
                                            <span className="text-[9px] font-black uppercase tracking-widest text-zinc-500">Scene {shot.scene}</span>
                                            <Badge variant="outline" className="text-[7px] font-black border-white/10 text-zinc-400">{shot.duration}</Badge>
                                        </div>
                                        <div className="space-y-1">
                                            <p className="text-[8px] font-black uppercase text-zinc-600">Visual</p>
                                            <Textarea value={shot.visuals} onChange={(e) => handleShotChange(index, 'visuals', e.target.value)} className="text-[10px] font-medium bg-white/5 border-none rounded-xl focus-visible:ring-1 ring-white/10 min-h-0 h-auto py-2 resize-none" rows={2}/>
                                        </div>
                                        <div className="space-y-1">
                                            <p className="text-[8px] font-black uppercase text-zinc-600">Audio</p>
                                            <Textarea value={shot.voiceover} onChange={(e) => handleShotChange(index, 'voiceover', e.target.value)} className="text-[10px] font-black italic bg-white/5 border-none rounded-xl focus-visible:ring-1 ring-white/10 min-h-0 h-auto py-2 resize-none text-zinc-300" rows={2}/>
                                        </div>
                                    </div>
                                ))}
                                <div className="pt-4 border-t border-white/5">
                                     <Label className="text-[8px] font-black uppercase tracking-widest text-primary">Final Call to Action</Label>
                                     <Textarea value={editedScript.callToAction} onChange={(e) => handleScriptChange('callToAction', e.target.value)} className="text-[11px] font-black bg-white/5 border-none rounded-xl mt-1 focus-visible:ring-1 ring-white/10 text-white resize-none" rows={3}/>
                                </div>
                            </CardContent>
                            <CardFooter className="p-4 bg-white/5">
                                <Button className="w-full h-14 rounded-2xl bg-white text-black hover:bg-zinc-200 font-black uppercase text-xs shadow-xl active:scale-95 transition-transform" onClick={handleFinalize} disabled={isSynthesizingVideo}>
                                    {isSynthesizingVideo ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Film className="mr-2 h-4 w-4"/>}
                                    {isSynthesizingVideo ? "Synthesizing..." : "Generate Video"}
                                </Button>
                            </CardFooter>
                        </Card>
                    </div>
                )}
            </div>

            {isSynthesizingVideo && (
                <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xl flex flex-col items-center justify-center p-8 text-center animate-in fade-in duration-500">
                    <div className="h-24 w-24 rounded-[2rem] bg-primary/20 flex items-center justify-center mb-8 border border-primary/20 shadow-2xl">
                        <Video className="h-10 w-10 text-primary animate-pulse" />
                    </div>
                    <h2 className="text-xl font-headline font-black text-white mb-2">Synthesizing Visuals</h2>
                    <p className="text-zinc-500 text-[10px] font-black uppercase tracking-[0.3em] mb-8">Veo Video Engine v2.1</p>
                    <div className="w-full max-w-xs space-y-2">
                        <Progress value={synthesisProgress} className="h-1 bg-white/10" />
                        <p className="text-[9px] font-black text-primary uppercase tracking-widest">{synthesisProgress}% Complete</p>
                    </div>
                    <p className="mt-12 text-xs font-medium text-zinc-400 italic max-w-[200px]">
                        "AI is mapping your technical specs into photorealistic frames..."
                    </p>
                </div>
            )}
        </div>
    );
}

export default function CreateScriptPage() {
    return (
        <Suspense fallback={
            <div className="flex flex-col justify-center items-center py-20 gap-4">
                <Loader2 className="animate-spin h-10 w-10 text-primary" />
                <p className="text-[10px] font-black uppercase tracking-widest">Initializing Synthesis</p>
            </div>
        }>
            <CreateScriptContent />
        </Suspense>
    );
}
