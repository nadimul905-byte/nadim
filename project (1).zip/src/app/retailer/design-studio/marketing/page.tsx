"use client";

import React from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { ArrowLeft, Video, Palette, ArrowRight, Sparkles, Megaphone, Share2 } from 'lucide-react';
import Link from 'next/link';

export default function RetailerMarketingStudioPage() {
    const router = useRouter();

    return (
        <div className="space-y-6 max-w-xs mx-auto px-1 pb-20">
            <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => router.back()} className="rounded-full h-10 w-10">
                    <ArrowLeft className="h-5 w-5" />
                </Button>
                <div>
                    <h1 className="text-xl font-headline font-bold">Marketing Studio</h1>
                    <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest">Promotion AI</p>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
                <Card className="rounded-3xl shadow-sm hover:shadow-lg transition-all border bg-card overflow-hidden group">
                  <CardHeader className="p-6">
                    <div className="w-12 h-12 rounded-xl bg-rose-500/10 flex items-center justify-center mb-4">
                      <Video className="h-6 w-6 text-rose-600" />
                    </div>
                    <CardTitle className="text-lg font-bold">Reel Script AI</CardTitle>
                    <CardDescription className="text-[10px] font-medium">15-second high-conversion marketing scripts for your sourced products.</CardDescription>
                  </CardHeader>
                  <CardFooter className="p-6 pt-0">
                    <Button className="w-full h-12 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs uppercase" asChild>
                      <Link href="/retailer/design-studio/marketing/create-script">Launch Creator <ArrowRight className="ml-2 h-4 w-4"/></Link>
                    </Button>
                  </CardFooter>
                </Card>

                <Card className="rounded-3xl shadow-sm hover:shadow-lg transition-all border bg-card overflow-hidden group">
                  <CardHeader className="p-6">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                      <Megaphone className="h-6 w-6 text-primary" />
                    </div>
                    <CardTitle className="text-lg font-bold">Campaign Manifest</CardTitle>
                    <CardDescription className="text-[10px] font-medium">Draft complete promotional collections and themes with AI assistance.</CardDescription>
                  </CardHeader>
                  <CardFooter className="p-6 pt-0">
                    <Button variant="outline" className="w-full h-12 rounded-xl font-bold text-xs uppercase border-primary/20 text-primary" asChild>
                      <Link href="/retailer/design-studio/marketing/campaign-manifest">
                        Open Manifest <ArrowRight className="ml-2 h-4 w-4"/>
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>

                <Card className="rounded-3xl shadow-sm hover:shadow-lg transition-all border bg-card overflow-hidden group">
                  <CardHeader className="p-6">
                    <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-4">
                      <Share2 className="h-6 w-6 text-amber-600" />
                    </div>
                    <CardTitle className="text-lg font-bold">Social Scheduler</CardTitle>
                    <CardDescription className="text-[10px] font-medium">Automate your collection drops across Instagram, TikTok, and more.</CardDescription>
                  </CardHeader>
                  <CardFooter className="p-6 pt-0">
                    <Button variant="outline" className="w-full h-12 rounded-xl font-bold text-xs uppercase border-accent/20 text-amber-600">
                      Sync Accounts <ArrowRight className="ml-2 h-4 w-4"/>
                    </Button>
                  </CardFooter>
                </Card>
            </div>
            
            <Card className="rounded-[2rem] border-none bg-primary/5 shadow-none p-2">
              <CardContent className="p-4 flex gap-3">
                  <Sparkles className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                  <p className="text-[10px] font-medium text-primary/80 leading-relaxed italic">
                      "Pro Tip: Use the AI Design Studio blueprints directly in your marketing scripts to build early hype for upcoming requests."
                  </p>
              </CardContent>
            </Card>
        </div>
    );
}
