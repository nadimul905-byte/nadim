"use client";

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { ArrowLeft, Download, Share2, Sparkles, CheckCircle2, Play, ShoppingBag, MessageSquare, Loader2 } from 'lucide-react';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

export default function ReelResultPage() {
    const router = useRouter();
    const { toast } = useToast();
    const [videoUrl, setVideoUrl] = useState<string | null>(null);
    const [isPosting, setIsPosting] = useState(false);

    useEffect(() => {
        if (typeof window !== 'undefined') {
            const storedReel = localStorage.getItem('ladook_last_reel');
            if (storedReel) {
                setVideoUrl(storedReel);
            } else {
                router.replace('/retailer/design-studio/marketing');
            }
        }
    }, [router]);

    const handleDownload = () => {
        if (!videoUrl) return;
        const link = document.createElement('a');
        link.href = videoUrl;
        link.download = `ladook-reel-${Date.now()}.mp4`;
        link.click();
    };

    const handlePostToCommunity = async () => {
        setIsPosting(true);
        // Simulate professional publication manifest within the OS
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        toast({ 
            title: "Reel Published!", 
            description: "Your social asset has been successfully distributed to the community discovery feed.",
        });
        
        setIsPosting(false);
        router.push('/retailer/social');
    };

    if (!videoUrl) return null;

    return (
        <div className="space-y-6 max-w-xs mx-auto px-1 pb-24 animate-in fade-in duration-500">
            <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => router.push('/retailer/design-studio/marketing')} className="rounded-full h-10 w-10">
                    <ArrowLeft className="h-5 w-5" />
                </Button>
                <div>
                    <h1 className="text-xl font-headline font-bold">Reel Output</h1>
                    <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest">Production Complete</p>
                </div>
            </div>

            <div className="relative group aspect-[9/16] w-full rounded-[2.5rem] overflow-hidden shadow-2xl bg-zinc-900 border-4 border-background">
                <video 
                    src={videoUrl} 
                    className="h-full w-full object-cover" 
                    controls 
                    autoPlay 
                    loop 
                    playsInline
                />
                <div className="absolute top-6 left-6">
                    <Badge className="bg-primary/90 text-white border-none rounded-full font-black text-[9px] uppercase tracking-widest px-4 py-1.5 shadow-xl">
                        AI MANIFESTED
                    </Badge>
                </div>
            </div>

            <Card className="rounded-3xl border shadow-md bg-card overflow-hidden">
                <CardHeader className="p-6 pb-2">
                    <div className="flex items-center gap-2">
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                        <CardTitle className="text-xs uppercase font-black tracking-widest">Asset Ready</CardTitle>
                    </div>
                    <CardDescription className="text-[11px] font-medium leading-relaxed italic mt-2">
                        "Your social asset is encoded and optimized for high-conversion distribution across the community network."
                    </CardDescription>
                </CardHeader>
                <CardFooter className="p-6 grid grid-cols-2 gap-3">
                    <Button variant="outline" className="rounded-xl h-12 font-black uppercase text-[10px]" onClick={handleDownload}>
                        <Download className="mr-2 h-4 w-4" /> Download
                    </Button>
                    <Button variant="outline" className="rounded-xl h-12 font-black uppercase text-[10px]" onClick={() => toast({ title: "Sync Active", description: "Sharing parameters updated." })}>
                        <Share2 className="mr-2 h-4 w-4" /> Share
                    </Button>
                </CardFooter>
            </Card>

            <div className="space-y-3 pt-4">
                <p className="text-[9px] font-black uppercase tracking-[0.4em] text-muted-foreground text-center">Operational Links</p>
                <div className="grid grid-cols-1 gap-3">
                    <Button 
                        className="h-14 rounded-2xl bg-zinc-900 text-white hover:bg-zinc-800 font-black uppercase text-xs shadow-lg"
                        onClick={handlePostToCommunity}
                        disabled={isPosting}
                    >
                        {isPosting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <MessageSquare className="mr-2 h-4 w-4" />}
                        Post to Community
                    </Button>
                    <Button variant="ghost" asChild className="h-12 rounded-xl text-primary font-black uppercase text-[10px]">
                        <Link href="/retailer/design-studio">
                            <Sparkles className="mr-2 h-4 w-4" /> New Synthesis Session
                        </Link>
                    </Button>
                </div>
            </div>
        </div>
    );
}
