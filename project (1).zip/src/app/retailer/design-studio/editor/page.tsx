"use client";

import React, { useState, useEffect, Suspense, useCallback } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  Palette, Sparkles, Image as ImageIcon, Mic, 
  ArrowLeft, RotateCcw, RotateCw, ZoomIn, 
  Layers, Ruler, Bot, Wand2, 
  ChevronRight, Loader2, Undo, Redo, Share2, Send,
  Paintbrush, Maximize2, MousePointer2, Type, Eraser, 
  Settings, Download, Plus, Minus, Scissors, FileText, LayoutGrid, Star,
  PanelLeftClose, PanelLeftOpen, ChevronLeft, Square, Pin, Ruler as RulerIcon,
  Pencil
} from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { generateDesigns, type GenerateDesignsOutput } from '@/ai/flows/design-studio-flow';
import placeholders from '@/app/lib/placeholder-images.json';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetDescription, SheetClose, SheetFooter } from '@/components/ui/sheet';

const fabricSwatches = placeholders.studio.fabricSwatches;

const designAssets = [
  { name: 'Patch Pocket', icon: Square },
  { name: 'Classic Button', icon: Pin },
  { name: 'Welt Pocket', icon: Square },
  { name: 'Exposed Zipper', icon: Scissors },
  { name: 'Mandarin Collar', icon: Pin },
  { name: 'D-Ring', icon: Pin },
];

function StudioContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const designType = searchParams.get('type') || 'Apparel';

  const [step, setStep] = useState<'refinement'>('refinement');
  const [prompt, setPrompt] = useState('');
  const [selectedDesign, setSelectedDesign] = useState<string | null>(null);
  const [zoom, setZoom] = useState(100);
  const [activeMode, setActiveMode] = useState<'select' | 'sketch' | 'cut' | 'assets' | 'none'>('select');

  useEffect(() => {
    if (typeof window !== 'undefined') {
        const storedDesign = localStorage.getItem('ladook_active_design');
        if (storedDesign) {
            try {
                const parsed = JSON.parse(storedDesign);
                setSelectedDesign(parsed.url);
                setPrompt(parsed.prompt || '');
                // We keep the design in storage until we move to the request form
                return;
            } catch (e) {
                console.error("Failed to parse design from storage", e);
            }
        }
    }
  }, []);

  const handleApplyTool = (toolName: string) => {
    toast({ title: `Tool Enabled: ${toolName}`, description: "The active canvas is responding to design adjustments." });
  };

  const handleFinalize = () => {
    if (selectedDesign) {
        const query = new URLSearchParams({
            prompt: prompt,
            imageUrl: selectedDesign
        });
        router.push(`/retailer/custom-requests/new?${query.toString()}`);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh_-_theme(spacing.16)_-_theme(spacing.16)_-_theme(spacing.8))] bg-background rounded-3xl border shadow-2xl overflow-hidden relative max-w-md mx-auto">
      <header className="h-14 border-b flex items-center justify-between px-4 bg-card flex-shrink-0 z-30">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={() => router.back()} className="rounded-full h-8 w-8">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <Separator orientation="vertical" className="h-6" />
          <h1 className="font-bold text-[10px] uppercase tracking-widest flex items-center gap-2 text-foreground">
            <Palette className="h-3 w-3 text-primary" /> Edit Studio
          </h1>
        </div>

        <div className="flex items-center gap-2">
           <Button 
                size="xs" 
                className="rounded-full bg-primary text-primary-foreground hover:bg-primary/90 px-4 h-8 font-bold text-[10px] uppercase tracking-tighter" 
                onClick={handleFinalize} 
           >
               Request <ChevronRight className="ml-1 h-3 w-3" />
           </Button>
        </div>
      </header>

      <div className="flex-1 flex flex-col overflow-hidden relative">
        <main className="flex-1 relative bg-zinc-100 dark:bg-zinc-900 flex items-center justify-center p-4 bg-[radial-gradient(#d1d5db_1px,transparent_1px)] dark:bg-[radial-gradient(#333_1px,transparent_1px)] [background-size:20px_20px]">
            <div 
              className="relative shadow-2xl overflow-hidden bg-white border-[1px] border-border group/canvas transition-all duration-700"
              style={{ 
                  width: '100%', 
                  maxWidth: '280px',
                  aspectRatio: '1080 / 1350',
                  transform: `scale(${zoom / 100})`,
              }}
            >
                {selectedDesign ? (
                  <Image 
                      src={selectedDesign} 
                      alt="Master Design" 
                      fill 
                      className="object-cover" 
                      data-ai-hint="high end design" 
                  />
                ) : (
                    <div className="flex items-center justify-center h-full">
                        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                )}
                
                <div className={cn(
                    "absolute inset-0 transition-all",
                    activeMode === 'select' ? "cursor-default" : "cursor-crosshair"
                )}>
                    {activeMode === 'sketch' && (
                        <div className="absolute inset-0 bg-primary/5 animate-in fade-in">
                            <div className="absolute top-1/4 left-1/2 w-8 h-8 border-2 border-primary rounded-full animate-pulse flex items-center justify-center">
                                <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                            </div>
                        </div>
                    )}
                </div>

                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 p-2 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-xl rounded-full shadow-xl border border-white/20 z-10">
                  <Button variant="ghost" size="icon" className="rounded-full h-8 w-8 hover:bg-muted" onClick={() => handleApplyTool('Rotate CCW')}><RotateCcw className="h-4 w-4 text-muted-foreground"/></Button>
                  <div className="flex items-center gap-1 bg-muted/50 rounded-full px-2 py-1">
                       <Button variant="ghost" size="icon" className="h-6 w-6 rounded-full" onClick={() => setZoom(Math.max(50, zoom - 10))}><Minus className="h-3 w-3"/></Button>
                       <span className="text-[9px] font-black w-8 text-center text-foreground">{zoom}%</span>
                       <Button variant="ghost" size="icon" className="h-6 w-6 rounded-full" onClick={() => setZoom(Math.min(200, zoom + 10))}><Plus className="h-3 w-3"/></Button>
                  </div>
                  <Button variant="ghost" size="icon" className="rounded-full h-8 w-8 text-primary hover:bg-primary/10" onClick={() => handleApplyTool('Fullscreen Mode')}><Maximize2 className="h-4 w-4"/></Button>
                </div>
            </div>
        </main>
      </div>

      <footer className="h-20 border-t bg-card flex items-center justify-around px-2 flex-shrink-0 z-10 overflow-x-auto no-scrollbar">
           <Sheet>
                <SheetTrigger asChild>
                     <Button variant="ghost" size="icon" className="flex flex-col gap-1 h-12 w-12 min-w-[3rem] rounded-xl hover:bg-primary/10 text-muted-foreground hover:text-primary">
                        <Settings className="h-5 w-5" />
                        <span className="text-[8px] font-black uppercase tracking-tight">Setup</span>
                    </Button>
                </SheetTrigger>
                <SheetContent side="bottom" className="h-[70vh] rounded-t-[2rem] z-[100]">
                    <SheetHeader className="pb-4 border-b flex flex-row items-center justify-between">
                        <div>
                            <SheetTitle className="text-xl font-headline font-black">Refine Concept</SheetTitle>
                            <SheetDescription className="text-[10px] uppercase font-bold tracking-widest text-primary flex items-center gap-1">
                                 <PanelLeftClose className="h-3 w-3"/> Optimization Module
                            </SheetDescription>
                        </div>
                        <SheetClose asChild>
                            <Button variant="ghost" size="icon" className="rounded-full">
                                <ChevronLeft className="h-5 w-5 text-muted-foreground" />
                            </Button>
                        </SheetClose>
                    </SheetHeader>
                    <ScrollArea className="h-full py-6">
                        <Accordion type="single" collapsible defaultValue="layers" className="space-y-4">
                            <AccordionItem value="layers" className="border-none">
                                <AccordionTrigger className="hover:no-underline font-black uppercase text-xs tracking-widest">
                                     Refinement Layers
                                </AccordionTrigger>
                                <AccordionContent className="space-y-2 pt-3">
                                    {['Structural Stability', 'Material Match', 'Hardware Options'].map(l => (
                                        <div key={l} className="p-3 bg-muted/30 rounded-2xl flex justify-between items-center border">
                                            <span className="text-xs font-bold">{l}</span>
                                            <Switch defaultChecked />
                                        </div>
                                    ))}
                                </AccordionContent>
                            </AccordionItem>
                            <AccordionItem value="fabric" className="border-none">
                                <AccordionTrigger className="hover:no-underline font-black uppercase text-xs tracking-widest">
                                     Preferred Textiles
                                </AccordionTrigger>
                                <AccordionContent className="pt-3">
                                    <div className="grid grid-cols-3 gap-3">
                                        {fabricSwatches.map(s => (
                                            <div key={s.name} className="relative aspect-square rounded-xl overflow-hidden border shadow-sm" onClick={() => handleApplyTool(s.name)}>
                                                <Image src={s.url} alt={s.name} fill className="object-cover" />
                                            </div>
                                        ))}
                                    </div>
                                </AccordionContent>
                            </AccordionItem>
                        </Accordion>
                        <div className="pt-6 border-t mt-6 grid grid-cols-1 gap-3 pb-20">
                            <Button className="rounded-xl h-12 text-[10px] font-black uppercase" onClick={() => handleApplyTool('Sync to Manufacturer')}><Wand2 className="mr-2 h-4 w-4"/> AI Fabric Sync</Button>
                        </div>
                    </ScrollArea>
                </SheetContent>
           </Sheet>

           <Button 
            variant="ghost" 
            size="icon" 
            className={cn(
                "flex flex-col gap-1 h-12 w-12 min-w-[3rem] rounded-xl transition-all",
                activeMode === 'select' ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-primary/5"
            )}
            onClick={() => setActiveMode('select')}
           >
                <MousePointer2 className="h-5 w-5" />
                <span className="text-[8px] font-black uppercase tracking-tight">Select</span>
           </Button>

           <Sheet>
                <SheetTrigger asChild>
                     <Button 
                        variant="ghost" 
                        size="icon" 
                        className={cn(
                            "flex flex-col gap-1 h-12 w-12 min-w-[3rem] rounded-xl transition-all",
                            activeMode === 'sketch' ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-primary/5"
                        )}
                        onClick={() => setActiveMode('sketch')}
                     >
                        <Pencil className="h-5 w-5" />
                        <span className="text-[8px] font-black uppercase tracking-tight">Markup</span>
                    </Button>
                </SheetTrigger>
                <SheetContent side="bottom" className="h-[30vh] rounded-t-[2rem] z-[100]">
                    <SheetHeader className="pb-2">
                        <SheetTitle className="text-lg font-black uppercase">Markup Presets</SheetTitle>
                    </SheetHeader>
                    <div className="flex gap-4 py-4 overflow-x-auto no-scrollbar">
                         {['Comment Tool', 'Highlighter', 'Arrow Note'].map(p => (
                            <Button key={p} variant="outline" className="h-16 w-24 flex-shrink-0 flex flex-col gap-1 rounded-2xl" onClick={() => handleApplyTool(p)}>
                                <Pencil className="h-4 w-4" />
                                <span className="text-[9px] font-bold">{p}</span>
                            </Button>
                         ))}
                    </div>
                </SheetContent>
           </Sheet>

            <div className="h-14 w-14 rounded-full bg-primary flex items-center justify-center shadow-xl shadow-primary/20 -translate-y-4 border-4 border-background flex-shrink-0">
                <Sparkles className="h-6 w-6 text-white" />
            </div>

            <Sheet>
                <SheetTrigger asChild>
                     <Button variant="ghost" size="icon" className="flex flex-col gap-1 h-12 w-12 min-w-[3rem] rounded-xl hover:bg-primary/10 text-muted-foreground hover:text-primary">
                        <Square className="h-5 w-5" />
                        <span className="text-[8px] font-black uppercase tracking-tight">Trims</span>
                    </Button>
                </SheetTrigger>
                <SheetContent side="bottom" className="h-[40vh] rounded-t-[2rem] z-[100]">
                    <SheetHeader className="pb-4 border-b">
                        <SheetTitle className="text-lg font-black uppercase">Trims & Hardware</SheetTitle>
                        <SheetDescription className="text-xs">Specify hardware requirements for your request.</SheetDescription>
                    </SheetHeader>
                    <div className="grid grid-cols-3 gap-4 py-6">
                        {designAssets.map(asset => (
                            <Button key={asset.name} variant="outline" className="h-20 flex flex-col gap-2 rounded-2xl" onClick={() => handleApplyTool(asset.name)}>
                                <asset.icon className="h-5 w-5 text-primary" />
                                <span className="text-[8px] font-bold uppercase">{asset.name}</span>
                            </Button>
                        ))}
                    </div>
                </SheetContent>
           </Sheet>

            <Sheet>
                <SheetTrigger asChild>
                     <Button variant="ghost" size="icon" className="flex flex-col gap-1 h-12 w-12 min-w-[3rem] rounded-xl hover:bg-primary/10 text-muted-foreground hover:text-primary">
                        <Bot className="h-5 w-5" />
                        <span className="text-[8px] font-black uppercase tracking-tight">Copilot</span>
                    </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-[85vw] sm:max-w-md z-[100]">
                    <SheetHeader className="pb-4 border-b">
                        <SheetTitle className="flex items-center gap-2 font-headline font-black"><Bot className="text-primary"/> Design Copilot</SheetTitle>
                        <SheetDescription className="text-[10px] uppercase font-bold tracking-widest">Active Intelligence Session</SheetDescription>
                    </SheetHeader>
                    <div className="flex flex-col h-full py-6">
                        <ScrollArea className="flex-1 pr-4">
                            <div className="space-y-6">
                                <div className="bg-primary/5 p-4 rounded-2xl rounded-tl-none border border-primary/10">
                                    <p className="text-xs font-bold leading-relaxed">I've analyzed the concept. For this category, I recommend **reinforced eyelets** and a **double-stitched welt** to increase durability during production.</p>
                                </div>
                                <div className="space-y-2">
                                    <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground px-2">AI Optimization</p>
                                    {['Add custom pocket', 'Suggest fabric', 'Verify symmetry'].map(a => (
                                        <Button key={a} variant="outline" size="sm" className="w-full justify-start h-10 rounded-xl text-[10px] font-bold" onClick={() => handleApplyTool(a)}>
                                            <Sparkles className="mr-2 h-3 w-3 text-primary opacity-50" /> {a}
                                        </Button>
                                    ))}
                                </div>
                            </div>
                        </ScrollArea>
                        <div className="mt-auto pb-10 space-y-4">
                            <Textarea placeholder="Instruct AI to modify..." className="rounded-2xl bg-muted/50 border-none text-xs p-4 resize-none h-24" />
                            <Button className="w-full h-12 rounded-xl font-bold bg-primary"><Send className="mr-2 h-4 w-4"/> Apply Changes</Button>
                        </div>
                    </div>
                </SheetContent>
            </Sheet>
      </footer>

      <style jsx global>{`
        .no-scrollbar::-webkit-scrollbar {
            display: none;
        }
        .no-scrollbar {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}

export default function RetailerStudioEditorPage() {
    return (
        <div className="w-full max-w-4xl mx-auto h-full">
            <Suspense fallback={
                <div className="flex flex-col items-center justify-center py-20 gap-4">
                    <Loader2 className="h-10 w-10 animate-spin text-primary opacity-20" />
                    <p className="text-xs font-black uppercase tracking-[0.5em] text-muted-foreground">Loading Suite</p>
                </div>
            }>
                <StudioContent />
            </Suspense>
        </div>
    );
}
