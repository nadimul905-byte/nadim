"use client";

import React, { Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { ArrowLeft, Sparkles, Wand2, Loader2, Palette, ChevronRight } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';

function TemplatesContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const prompt = searchParams.get('prompt') || 'New Design Concept';

  const curatedTemplates = [
    { id: 'p1', name: 'Minimalist Silhouette', image: 'https://picsum.photos/seed/curated1/400/600', aiHint: 'minimalist fashion' },
    { id: 'p2', name: 'Avant-Garde Structure', image: 'https://picsum.photos/seed/curated2/400/600', aiHint: 'avant garde fashion' },
    { id: 'p3', name: 'Vintage Heritage', image: 'https://picsum.photos/seed/curated3/400/600', aiHint: 'vintage fashion' },
    { id: 'p4', name: 'Urban Utility', image: 'https://picsum.photos/seed/curated4/400/600', aiHint: 'urban fashion' },
  ];

  const handleSelectTemplate = (templateId: string) => {
    // Retailers use templates to kick off a refinement session before request
    const template = curatedTemplates.find(t => t.id === templateId);
    if (template) {
        if (typeof window !== 'undefined') {
            localStorage.setItem('ladook_active_design', JSON.stringify({
                url: template.image,
                prompt: prompt
            }));
        }
        
        const query = new URLSearchParams({
            type: 'Template',
            source: 'templates'
        });
        router.push(`/retailer/design-studio/editor?${query.toString()}`);
    }
  };

  return (
    <div className="space-y-6 max-w-xs mx-auto">
      <div className="flex flex-col gap-3">
        <div className="flex items-center gap-3">
          <Button variant="outline" size="icon" onClick={() => router.back()} className="rounded-full h-10 w-10 flex-shrink-0">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="min-w-0">
            <h1 className="text-xl font-headline font-black tracking-tight truncate">Blueprints</h1>
            <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest">Select Base Silhouette</p>
          </div>
        </div>
        <div className="bg-primary/5 p-3 rounded-xl border border-primary/10">
            <p className="text-[11px] text-muted-foreground italic font-medium line-clamp-2">"{prompt}"</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {curatedTemplates.map((template) => (
          <Card key={template.id} className="overflow-hidden group hover:shadow-xl transition-all rounded-[1.25rem] bg-card border-none shadow-md flex flex-col">
            <div className="relative aspect-[3/4] w-full bg-muted">
              <Image src={template.image} alt={template.name} fill className="object-cover transition-transform duration-500 group-hover:scale-105" data-ai-hint={template.id} />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-3">
                <Button size="sm" className="w-full rounded-lg font-black text-[10px] h-8 shadow-2xl bg-white text-black hover:bg-white/90" onClick={() => handleSelectTemplate(template.id)}>
                  SELECT
                </Button>
              </div>
            </div>
            <CardHeader className="p-2 text-center bg-card flex-grow">
              <CardTitle className="text-[10px] font-black uppercase tracking-tight truncate">{template.name}</CardTitle>
            </CardHeader>
          </Card>
        ))}
      </div>

      <Card className="bg-primary/5 border-primary/20 rounded-[1.5rem] shadow-none border-4 border-dashed py-6 px-4 text-center space-y-3">
        <div className="space-y-1.5">
            <div className="mx-auto h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center mb-1">
                <Sparkles className="text-primary h-5 w-5"/>
            </div>
            <CardTitle className="text-base font-headline font-black">
                Custom Synthesis
            </CardTitle>
            <CardDescription className="text-[11px] font-medium leading-tight">Generate completely original concepts from your vision statement.</CardDescription>
        </div>
        <Button size="lg" className="rounded-full w-full h-12 text-xs font-black shadow-lg shadow-primary/20" asChild>
            <Link href={`/retailer/design-studio/generate-designs?prompt=${encodeURIComponent(prompt)}`}>
                <Wand2 className="mr-1.5 h-3.5 w-3.5" /> Original Concepts
            </Link>
        </Button>
      </Card>
    </div>
  );
}

export default function DesignTemplatesPage() {
  return (
    <Suspense fallback={<div className="flex flex-col items-center justify-center py-20 gap-4">
        <Loader2 className="animate-spin h-12 w-12 text-primary" />
        <p className="font-black uppercase tracking-[0.4em] text-muted-foreground">Curating Infrastructure</p>
    </div>}>
      <TemplatesContent />
    </Suspense>
  );
}
