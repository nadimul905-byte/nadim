
"use client";
import { useEffect, useState } from 'react';
import { getProductRecommendations, type ProductRecommendationsOutput } from '@/ai/flows/product-recommendations';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import Image from 'next/image';
import { Skeleton } from '@/components/ui/skeleton';
import { allMockProducts, type Product as HomePageProduct } from '@/app/retailer/products/page';
import { ShoppingCart, Zap, Heart, Star, ChevronRight, Sparkles } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import { type CartItem } from '@/app/retailer/cart/page';
import { cn } from '@/lib/utils';

const simulatedRecommendedProductNames = [
  "Delicate Gold Necklace",
  "Velvet Matte Lipstick",
  "Eyeshadow Palette - Nudes",
  "Luxury Silk Blouse",
  "Floral Sundress",
];

export default function ProductRecommendationsSection() {
  const [recommendations, setRecommendations] = useState<HomePageProduct[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reasoning, setReasoning] = useState<string>('');
  const { toast } = useToast();
  const router = useRouter();

  useEffect(() => {
    setLoading(true);
    setError(null);

    // Map recommended names to full product details from allMockProducts
    const detailedRecs = simulatedRecommendedProductNames.map(name => {
        return allMockProducts.find(p => p.name === name);
    }).filter(Boolean) as HomePageProduct[];

    setTimeout(() => {
        setRecommendations(detailedRecs);
        setReasoning("Based on your recent interest in high-end apparel and accessories.");
        setLoading(false);
    }, 800);

  }, []);
  
  const handleAddToCart = (e: React.MouseEvent, productName: string) => {
    e.stopPropagation();
    e.preventDefault();
    toast({ title: "Added to Batch", description: `${productName} is in procurement.` });
  };

  const handleBuyNow = (e: React.MouseEvent, product: HomePageProduct) => {
    e.stopPropagation();
    e.preventDefault();
    
    const cartItem: CartItem = {
        id: product.id,
        name: product.name,
        price: parseFloat(product.price.replace('$', '')),
        quantity: product.minOrderQuantity || 1,
        image: product.image,
        aiHint: product.aiHint,
    };
    
    if (typeof window !== 'undefined') {
        localStorage.setItem('ladook-buy-now', JSON.stringify([cartItem]));
    }
    toast({ title: "Securing Production", description: `Added ${product.name} to active order.` });
    router.push('/retailer/checkout');
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-3 w-10" />
        </div>
        <div className="flex space-x-4 overflow-hidden">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="w-48 flex-shrink-0 space-y-3">
                <Skeleton className="h-40 w-full rounded-3xl" />
                <Skeleton className="h-3 w-3/4 rounded-full" />
                <Skeleton className="h-2 w-1/2 rounded-full" />
              </div>
            ))}
        </div>
      </div>
    );
  }

  if (!recommendations || recommendations.length === 0) {
    return null;
  }
  
  return (
    <section className="space-y-4">
      <div className="flex items-center justify-between border-b border-dashed border-primary/10 pb-2 px-1">
        <h2 className="text-[10px] font-black uppercase tracking-[0.3em] text-primary flex items-center gap-2">
            <Sparkles className="h-3 w-3 fill-primary" /> AI Recommended
        </h2>
        <Button variant="link" size="sm" className="p-0 h-auto text-[9px] font-black uppercase text-primary" asChild>
          <Link href="/retailer/trends">All <ChevronRight className="h-3 w-3"/></Link>
        </Button>
      </div>

      <div className="flex overflow-x-auto snap-x snap-mandatory space-x-4 pb-4 no-scrollbar">
          {recommendations.map(product => (
            <Card key={product.id} className="w-48 flex-shrink-0 snap-start rounded-3xl overflow-hidden group border shadow-sm hover:shadow-lg transition-all flex flex-col">
              <Link href={`/retailer/products/${product.id}`} className="flex flex-col flex-grow">
                <CardContent className="p-0">
                  <div className="relative h-40 w-full bg-muted">
                    <Image 
                      src={product.image} 
                      alt={product.name} 
                      fill 
                      className="object-cover transition-transform duration-500 group-hover:scale-110"
                      data-ai-hint={product.aiHint} 
                    />
                    <div className="absolute top-2 left-2 px-2 py-0.5 bg-primary/90 text-white text-[7px] font-black uppercase rounded-full shadow-lg">
                        MATCH 98%
                    </div>
                    <Button variant="ghost" size="icon" className="absolute top-2 right-2 bg-black/20 hover:bg-black/40 text-white rounded-full h-8 w-8" onClick={(e) => { e.preventDefault(); toast({title: "Added to Wishlist"}); }}>
                        <Heart className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
                <CardHeader className="p-3">
                  <CardTitle className="text-sm font-bold truncate group-hover:text-primary">{product.name}</CardTitle>
                  <CardDescription className="text-[10px] text-muted-foreground mt-0.5 font-medium">{product.vendorName}</CardDescription>
                  <div className="flex justify-between items-end mt-2">
                    <p className="text-sm font-black text-primary">{product.price}</p>
                    <p className="text-[8px] font-black uppercase text-muted-foreground">MOQ: {product.minOrderQuantity}</p>
                  </div>
                </CardHeader>
              </Link>
              <CardFooter className="p-2 border-t bg-muted/5 grid grid-cols-2 gap-2">
                <Button variant="outline" size="sm" className="h-8 rounded-xl text-[9px] font-black uppercase border-primary/10 text-primary" onClick={(e) => handleAddToCart(e, product.name)}>
                    Cart
                </Button>
                <Button size="sm" className="h-8 rounded-xl text-[9px] font-black uppercase bg-accent text-accent-foreground" onClick={(e) => handleBuyNow(e, product)}>
                    Buy Now
                </Button>
              </CardFooter>
            </Card>
          ))}
      </div>
    </section>
  );
}
