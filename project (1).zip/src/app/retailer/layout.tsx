
"use client";

import React from 'react';
import TopBar from '@/components/layout/TopBar';
import BottomNav from '@/components/layout/BottomNav';
import SideNav from '@/components/layout/SideNav';
import { retailerNavItems } from '@/config/navConfig';
import { useAuthProtection } from '@/lib/auth';
import { Skeleton } from '@/components/ui/skeleton';

export default function RetailerLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const isLoading = useAuthProtection('retailer');

  if (isLoading) {
    return (
      <div className="flex flex-col min-h-screen">
        <Skeleton className="h-16 w-full" />
        <div className="flex flex-1">
          <Skeleton className="hidden md:block md:w-64" />
          <div className="flex-1 p-6 space-y-4">
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-64 w-full" />
          </div>
        </div>
        <Skeleton className="h-16 w-full md:hidden" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen">
      <SideNav navItems={retailerNavItems} role="retailer" />
      <div className="flex flex-col flex-1 md:ml-64">
        <TopBar role="retailer" />
        <main className="flex-1 p-4 sm:p-6 lg:p-8 bg-secondary/50">
           <div className="mx-auto max-w-xs">
            {children}
          </div>
        </main>
        <BottomNav navItems={retailerNavItems} role="retailer" />
        <div className="h-16 md:hidden" /> {/* Spacer for bottom nav */}
      </div>
    </div>
  );
}
