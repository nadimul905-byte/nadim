
"use client";

import React, { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import Link from 'next/link';
import { mockRetailerChats, parseRetailerDisplayTimestamp } from './mockRetailerChatData';
import { Input } from '@/components/ui/input';
import { Search, MessageSquarePlus, ClipboardList, CalendarDays, ArrowRight, Package, Clock, ChevronRight, PlusCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { mockRequests, type CustomRequest } from '@/app/vendor/requests/page';
import { mockOrders } from '../orders/page';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { OrderStatusTimeline } from '@/components/OrderStatusTimeline';

// Card for showing a user's own custom requests
const MyRequestCard = ({ request }: { request: CustomRequest }) => (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow flex flex-col rounded-3xl border shadow-sm">
      <Link href={`/retailer/custom-requests/${request.id}`} className="block">
        {request.image && (
          <div className="relative w-full h-40 bg-muted">
            <Image src={request.image} alt={request.title} fill className="object-cover" data-ai-hint={request.aiHint} />
          </div>
        )}
      </Link>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start mb-1">
          <Link href={`/retailer/custom-requests/${request.id}`} className="block hover:text-primary">
            <CardTitle className="text-base font-bold truncate">{request.title}</CardTitle>
          </Link>
          <Badge variant={request.status === 'Open' ? 'default' : 'secondary'}
                 className={cn("rounded-full text-[8px] font-black uppercase px-2 py-0.5", request.status === 'Open' ? 'bg-green-500 text-white' : '')}>
            {request.status}
          </Badge>
        </div>
        <CardDescription className="text-[9px] font-black uppercase text-muted-foreground tracking-widest flex items-center gap-1">
          <Clock className="h-2.5 w-2.5" /> Posted: {request.datePosted}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-2 pb-4 flex-grow">
        <p className="text-[11px] font-medium text-muted-foreground line-clamp-2 italic">"{request.descriptionSnippet}"</p>
        <div className="flex flex-wrap gap-2 pt-1">
            <Badge variant="outline" className="text-[7px] font-bold uppercase tracking-tighter bg-muted/10 border-dashed">{request.category}</Badge>
            {request.quantity && <Badge variant="outline" className="text-[7px] font-bold uppercase tracking-tighter bg-muted/10 border-dashed">Qty: {request.quantity}</Badge>}
        </div>
      </CardContent>
      <CardFooter className="pt-0 mt-auto bg-muted/5 py-3">
        <Button asChild variant="ghost" size="sm" className="w-full text-[9px] font-black uppercase tracking-widest text-primary hover:bg-primary/5">
          <Link href={`/retailer/custom-requests/${request.id}`}>
            Review Bids <ChevronRight className="ml-1 h-3 w-3" />
          </Link>
        </Button>
      </CardFooter>
    </Card>
);

const OrderSummaryCard = ({ order }: { order: any }) => (
    <Card className="rounded-3xl border shadow-sm overflow-hidden flex flex-col hover:border-primary/20 transition-all bg-card">
        <CardHeader className="p-4 bg-muted/10 border-b border-dashed">
            <div className="flex justify-between items-start">
                <div className="space-y-0.5">
                    <p className="text-[8px] font-black uppercase text-primary tracking-[0.2em]">Procurement Manifest</p>
                    <CardTitle className="text-sm font-black uppercase tracking-tight">#{order.id}</CardTitle>
                </div>
                <Badge variant="outline" className="rounded-full text-[8px] font-black uppercase px-2 py-0.5 bg-background border-zinc-200 shadow-sm">{order.status}</Badge>
            </div>
        </CardHeader>
        <CardContent className="p-4 space-y-4">
            <div className="flex items-center gap-4">
                <div className="flex -space-x-3 overflow-hidden">
                    {order.items.slice(0, 3).map((item: any, i: number) => (
                        <div key={i} className="inline-block relative h-10 w-8 rounded-lg ring-2 ring-background overflow-hidden bg-muted border flex-shrink-0 shadow-sm">
                            <Image src={item.image} alt="" fill className="object-cover" />
                        </div>
                    ))}
                    {order.items.length > 3 && (
                        <div className="inline-block h-10 w-8 rounded-lg ring-2 ring-background bg-secondary flex items-center justify-center text-[9px] font-black text-muted-foreground border border-dashed flex-shrink-0">
                            +{order.items.length - 3}
                        </div>
                    )}
                </div>
                <div className="min-w-0 flex-1">
                    <p className="text-[9px] font-black text-muted-foreground uppercase tracking-widest truncate">{order.vendorName}</p>
                    <p className="text-base font-black text-primary tracking-tighter mt-0.5">${order.totalAmount.toFixed(2)}</p>
                </div>
                <Button variant="ghost" size="icon" asChild className="h-10 w-10 rounded-2xl hover:bg-primary/5 text-primary">
                    <Link href={`/retailer/orders/${order.id}`}><ChevronRight className="h-5 w-5" /></Link>
                </Button>
            </div>
            
            {/* Tracking System Integration */}
            {(order.status === 'Processing' || order.status === 'Shipped' || order.status === 'Delivered' || order.status === 'Completed') && (
                <div className="pt-2 border-t border-dashed">
                    <div className="flex items-center justify-between mb-2">
                        <p className="text-[8px] font-black uppercase text-muted-foreground tracking-widest">Tracking Status</p>
                    </div>
                    <OrderStatusTimeline currentStatus={order.status} className="px-0 scale-75 -mx-10" />
                </div>
            )}
        </CardContent>
    </Card>
);


export default function RetailerMessagesPage() {
  const [searchTerm, setSearchTerm] = useState('');

  const sortedAndFilteredChats = useMemo(() => {
    return mockRetailerChats
      .filter(chat => chat.vendorName.toLowerCase().includes(searchTerm.toLowerCase()))
      .sort((a, b) => {
        const dateA = parseRetailerDisplayTimestamp(a.timestamp);
        const dateB = parseRetailerDisplayTimestamp(b.timestamp);
        return dateB.getTime() - dateA.getTime();
      });
  }, [searchTerm]);

  const totalUnreadMessages = useMemo(() => {
    return mockRetailerChats.reduce((sum, chat) => sum + chat.unreadCount, 0);
  }, []);

  // Filter requests posted by the current mock retailer ('Boutique Elegance' and others are used in mock data)
  const myRequests = mockRequests.filter(req => ['Boutique Elegance', 'Green Threads Co.', 'Sunny Styles Boutique', 'Artisan Goods Ltd.'].includes(req.retailerName));

  const openRequestsCount = useMemo(() => myRequests.filter(req => req.status === "Open").length, [myRequests]);

  const activeOrders = useMemo(() => mockOrders.filter(o => o.status !== 'Completed' && o.status !== 'Cancelled'), []);

  return (
    <div className="space-y-6 max-w-xs mx-auto px-1 pb-20 animate-in fade-in duration-500">
      <div className="space-y-1">
          <h1 className="text-2xl font-headline font-black tracking-tight leading-tight">Hub Operations</h1>
          <p className="text-[10px] text-muted-foreground uppercase font-black tracking-[0.3em]">Communication OS v4.1</p>
      </div>
      
      <Tabs defaultValue="inbox" className="w-full">
        <TabsList className="grid w-full grid-cols-3 h-11 items-center justify-center rounded-2xl bg-muted/30 p-1 border">
          <TabsTrigger value="inbox" className="rounded-xl text-[9px] font-black uppercase tracking-widest relative h-full data-[state=active]:bg-background transition-all">
            <div className="flex items-center gap-1.5">
              <span>Inbox</span>
              {totalUnreadMessages > 0 && (
                <Badge className="h-3.5 min-w-3.5 p-0 flex items-center justify-center rounded-full text-[7px] bg-primary border-none text-white">{totalUnreadMessages}</Badge>
              )}
            </div>
          </TabsTrigger>
          <TabsTrigger value="requests" className="rounded-xl text-[9px] font-black uppercase tracking-widest relative h-full data-[state=active]:bg-background transition-all">
             <div className="flex items-center gap-1.5">
                <span>Leads</span>
                {openRequestsCount > 0 && (
                    <Badge variant="secondary" className="h-3.5 min-w-3.5 p-0 flex items-center justify-center rounded-full text-[7px] border-none">{openRequestsCount}</Badge>
                )}
             </div>
          </TabsTrigger>
          <TabsTrigger value="orders" className="rounded-xl text-[9px] font-black uppercase tracking-widest relative h-full data-[state=active]:bg-background transition-all">
             <div className="flex items-center gap-1.5">
                <span>Orders</span>
                {activeOrders.length > 0 && (
                    <Badge variant="outline" className="h-3.5 min-w-3.5 p-0 flex items-center justify-center rounded-full text-[7px] border-primary/30 text-primary font-black">{activeOrders.length}</Badge>
                )}
             </div>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="inbox" className="mt-6 space-y-4">
          <div className="relative group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
            <Input 
              placeholder="Search conversations..." 
              className="pl-9 h-11 rounded-2xl bg-card border shadow-sm text-xs font-medium"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="space-y-3">
            {sortedAndFilteredChats.length > 0 ? sortedAndFilteredChats.map(chat => (
              <Link href={`/retailer/messages/${chat.id}`} key={chat.id} className="block group">
                <Card className={cn(
                    "rounded-[1.75rem] border shadow-sm hover:border-primary/20 transition-all border-none bg-card",
                    chat.unreadCount > 0 ? "ring-1 ring-primary/20 shadow-primary/5" : "ring-1 ring-zinc-200/50"
                )}>
                  <CardContent className="p-4 flex items-center gap-4">
                    <Avatar className="h-12 w-12 border-2 border-background shadow-md">
                      <AvatarImage src={chat.vendorAvatar} alt={chat.vendorName} data-ai-hint={chat.vendorAvatarAiHint} />
                      <AvatarFallback className="bg-muted text-[10px] font-black">{chat.vendorName.substring(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-baseline">
                        <p className={cn("text-xs font-black uppercase tracking-tight truncate", chat.unreadCount > 0 ? "text-primary" : "text-foreground")}>{chat.vendorName}</p>
                        <p className="text-[8px] font-black text-muted-foreground ml-2 shrink-0">{chat.timestamp}</p>
                      </div>
                      <p className={cn("text-[11px] line-clamp-1 mt-1 font-medium leading-tight", chat.unreadCount > 0 ? "text-foreground font-black" : "text-muted-foreground")}>
                        {chat.lastMessage}
                      </p>
                    </div>
                    {chat.unreadCount > 0 && (
                      <div className="h-2 w-2 rounded-full bg-primary shrink-0 shadow-lg shadow-primary/20 animate-pulse" />
                    )}
                  </CardContent>
                </Card>
              </Link>
            )) : (
              <div className="text-center py-20 bg-muted/10 rounded-[2rem] border-2 border-dashed">
                <MessageSquare className="h-10 w-10 text-muted-foreground mx-auto mb-3 opacity-20" />
                <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground/60">
                  No Dialogues Found
                </p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="requests" className="mt-6 space-y-4">
            <div className="flex items-center justify-between px-1">
                <h2 className="text-[10px] font-black uppercase tracking-[0.3em] text-muted-foreground">Operational Leads</h2>
                <Button variant="link" size="sm" asChild className="p-0 h-auto text-[10px] font-black uppercase text-primary">
                    <Link href="/retailer/custom-requests/new">Initialize <PlusCircle className="h-3 w-3 ml-1"/></Link>
                </Button>
            </div>
            {myRequests.length > 0 ? (
                <div className="grid grid-cols-1 gap-5">
                    {myRequests.map(request => (
                        <MyRequestCard key={request.id} request={request} />
                    ))}
                </div>
            ) : (
                <Card className="rounded-[2.5rem] border-2 border-dashed bg-muted/10">
                    <CardContent className="py-20 text-center">
                        <ClipboardList className="mx-auto h-12 w-12 text-muted-foreground mb-4 opacity-10" />
                        <h3 className="text-lg font-headline font-black">Lead Pipe Empty</h3>
                        <p className="text-xs text-muted-foreground font-medium uppercase tracking-widest mt-2 px-6 leading-relaxed">
                            Draft a new design request to manifest vendor proposals.
                        </p>
                        <Button asChild className="mt-8 rounded-2xl h-12 font-black uppercase text-xs px-8">
                            <Link href="/retailer/custom-requests/new">Start Request</Link>
                        </Button>
                    </CardContent>
                </Card>
            )}
        </TabsContent>

        <TabsContent value="orders" className="mt-6 space-y-4">
            <div className="flex items-center justify-between px-1 border-b border-dashed border-primary/10 pb-2">
                <h2 className="text-[10px] font-black uppercase tracking-[0.3em] text-primary">Live Procurement</h2>
                <Button variant="link" size="sm" asChild className="p-0 h-auto text-[9px] font-black uppercase text-primary tracking-widest">
                    <Link href="/retailer/orders">View All Logs <ArrowRight className="h-3 w-3 ml-1"/></Link>
                </Button>
            </div>
            {activeOrders.length > 0 ? (
                <div className="space-y-4">
                    {activeOrders.map(order => (
                        <OrderSummaryCard key={order.id} order={order} />
                    ))}
                </div>
            ) : (
                <Card className="rounded-[2.5rem] border-2 border-dashed bg-muted/10">
                    <CardContent className="py-20 text-center">
                        <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4 opacity-10" />
                        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground/60">
                            No Active Manifests
                        </p>
                    </CardContent>
                </Card>
            )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
