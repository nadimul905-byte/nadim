
// src/app/retailer/messages/mockRetailerChatData.ts
export interface RetailerChatMessage {
  id: string;
  sender: 'retailer' | 'vendor';
  text: string;
  timestamp: string;
}

export interface MockRetailerChat {
  id: string; // Corresponds to vendorSlug
  vendorName: string;
  vendorAvatar: string;
  vendorAvatarAiHint: string;
  lastMessage: string;
  unreadCount: number;
  timestamp: string; // Last message timestamp
  messages: RetailerChatMessage[];
}

export const mockRetailerChats: MockRetailerChat[] = [
  {
    id: 'chic-designs-co', // Vendor slug from product page
    vendorName: 'Chic Designs Co.',
    vendorAvatar: 'https://images.unsplash.com/photo-1590874315261-788881621f7a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwbG9nb3xlbnwwfHx8fDE3NDg4NjUyODl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'fashion logo',
    lastMessage: "Yes, we can discuss bulk pricing.",
    unreadCount: 1,
    timestamp: "10:30 AM",
    messages: [
      { id: 'rm1-1', sender: 'retailer', text: "Hi Chic Designs, I'm interested in the Luxury Silk Blouse. Can we discuss bulk pricing?", timestamp: "10:28 AM" },
      { id: 'rm1-2', sender: 'vendor', text: "Hello! Absolutely. For how many units are you looking?", timestamp: "10:29 AM" },
      { id: 'rm1-3', sender: 'retailer', text: "Around 50 units to start with.", timestamp: "10:29 AM" },
      { id: 'rm1-4', sender: 'vendor', text: "Yes, we can discuss bulk pricing.", timestamp: "10:30 AM" },
    ]
  },
  {
    id: 'denim-dreams',
    vendorName: 'Denim Dreams',
    vendorAvatar: 'https://images.unsplash.com/photo-1459173422306-0ce3fb37f832?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw2fHxkZW5pbSUyMGJyYW5kfGVufDB8fHx8MTc0OTIxNTcwMHww&ixlib=rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'denim brand',
    lastMessage: "What are your MOQ for custom washes?",
    unreadCount: 0,
    timestamp: "Yesterday",
    messages: [
      { id: 'rm2-1', sender: 'retailer', text: "Hi Denim Dreams, I love your slim fit jeans. What are your MOQ for custom washes?", timestamp: "Yesterday" },
      { id: 'rm2-2', sender: 'vendor', text: "Our MOQ for custom washes is typically 200 units per style. We can sometimes accommodate smaller runs depending on the complexity.", timestamp: "Yesterday" },
    ]
  },
  {
    id: 'apparel-co',
    vendorName: 'Apparel Co.',
    vendorAvatar: 'https://images.unsplash.com/photo-1610702878528-ca48d38b9a2b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw5fHxhcHBhcmVsJTIwY29tcGFueXxlbnwwfHx8fDE3NDkyMTU3MDF8MA&ixlib.rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'apparel company',
    lastMessage: "Sure, I'll send the new samples over.",
    unreadCount: 0,
    timestamp: "3d ago",
    messages: [
      { id: 'rm3-1', sender: 'retailer', text: "Could you send over the new samples?", timestamp: "3d ago" },
      { id: 'rm3-2', sender: 'vendor', text: "Sure, I'll send the new samples over.", timestamp: "3d ago" },
    ]
  },
  {
    id: 'footwear-express',
    vendorName: 'Footwear Express',
    vendorAvatar: 'https://images.unsplash.com/photo-1582482020958-b838acfd9b66?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxzaG9lJTIwc3RvcmV8ZW58MHx8fHwxNzQ5MjE1NzAwfDA&ixlib.rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'shoe store',
    lastMessage: "Order confirmed, shipping in 2 days.",
    unreadCount: 0,
    timestamp: "4d ago",
    messages: [
      { id: 'rm4-1', sender: 'vendor', text: "Order confirmed, shipping in 2 days.", timestamp: "4d ago" },
    ]
  },
  {
    id: 'timepiece-trends',
    vendorName: 'Timepiece Trends',
    vendorAvatar: 'https://images.unsplash.com/photo-1434493651957-4ec11beae249?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw0fHx3YXRjaCUyMGNvbXBhbnl8ZW58MHx8fHwxNzQ5MjE1NzAwfDA&ixlib.rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'watch company',
    lastMessage: "The new collection is launching next week!",
    unreadCount: 2,
    timestamp: "9:15 AM",
    messages: [
      { id: 'rm5-1', sender: 'vendor', text: "The new collection is launching next week!", timestamp: "9:15 AM" },
      { id: 'rm5-2', sender: 'retailer', text: "Exciting! Can't wait to see it.", timestamp: "9:17 AM" },
    ]
  },
  {
    id: 'glimmer-gems',
    vendorName: 'Glimmer Gems',
    vendorAvatar: 'https://images.unsplash.com/photo-1574582242931-e2b1d1f65d4b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxqZXdlbHJ5JTIwc2hvcHxlbnwwfHx8fDE3NDkyMTU3MDF8MA&ixlib.rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'jewelry shop',
    lastMessage: "We have a special offer on necklaces this month.",
    unreadCount: 0,
    timestamp: "Mon",
    messages: [
      { id: 'rm6-1', sender: 'vendor', text: "We have a special offer on necklaces this month.", timestamp: "Mon" },
    ]
  },
  {
    id: 'beauty-blend',
    vendorName: 'Beauty Blend',
    vendorAvatar: 'https://images.unsplash.com/photo-1631214564867-f1aa6d638afc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw4fHxiZWF1dHklMjBicmFuZHxlbnwwfHx8fDE3NDkyMTU3MDB8MA&ixlib.rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'beauty brand',
    lastMessage: "Your inquiry about lipsticks has been received.",
    unreadCount: 1,
    timestamp: "11:05 AM",
    messages: [
      { id: 'rm7-1', sender: 'retailer', text: "Interested in your lipstick range.", timestamp: "11:00 AM" },
      { id: 'rm7-2', sender: 'vendor', text: "Your inquiry about lipsticks has been received.", timestamp: "11:05 AM" },
    ]
  },
  {
    id: 'palette-perfect',
    vendorName: 'Palette Perfect',
    vendorAvatar: 'https://images.unsplash.com/photo-1591375462469-62f189694738?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxjb3NtZXRpY3MlMjBicmFuZHxlbnwwfHx8fDE3NDkyMTU3MDB8MA&ixlib.rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'cosmetics brand',
    lastMessage: "Thank you for your order!",
    unreadCount: 0,
    timestamp: "Jul 28",
    messages: [
      { id: 'rm8-1', sender: 'vendor', text: "Thank you for your order!", timestamp: "Jul 28" },
    ]
  },
  {
    id: 'summer-styles',
    vendorName: 'Summer Styles',
    vendorAvatar: 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxzdW1tZXIlMjBmYXNoaW9ufGVufDB8fHx8MTc0OTIxNTcwMHww&ixlib.rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'summer fashion',
    lastMessage: "The floral sundresses are now in stock.",
    unreadCount: 0,
    timestamp: "Tue",
    messages: [
      { id: 'rm9-1', sender: 'vendor', text: "The floral sundresses are now in stock.", timestamp: "Tue" },
    ]
  },
  {
    id: 'gentlemen-wear',
    vendorName: 'Gentlemen Wear',
    vendorAvatar: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw5fHxtZW5zJTIwY2xvdGhpbmd8ZW58MHx8fHwxNzQ5MjE1NzAwfDA&ixlib.rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'mens clothing',
    lastMessage: "Are you interested in our new polo shirts?",
    unreadCount: 0,
    timestamp: "Wed",
    messages: [
      { id: 'rm10-1', sender: 'vendor', text: "Are you interested in our new polo shirts?", timestamp: "Wed" },
    ]
  }
];

// Function to parse timestamp, similar to vendor's chat data
export function parseRetailerDisplayTimestamp(displayTimestamp: string): Date {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  let match = displayTimestamp.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
  if (match) {
    let hours = parseInt(match[1]);
    const minutes = parseInt(match[2]);
    const ampm = match[3].toUpperCase();
    if (ampm === 'PM' && hours < 12) hours += 12;
    if (ampm === 'AM' && hours === 12) hours = 0;
    const date = new Date(now);
    date.setHours(hours, minutes, 0, 0);
    return date;
  }
  if (displayTimestamp.toLowerCase() === 'yesterday') {
    const date = new Date(today);
    date.setDate(today.getDate() - 1);
    date.setHours(12,0,0,0); // Set to midday for consistent comparison
    return date;
  }
   match = displayTimestamp.match(/^(\d+)d ago$/i);
  if (match) {
    const daysAgo = parseInt(match[1]);
    const date = new Date(today);
    date.setDate(today.getDate() - daysAgo);
    date.setHours(12,0,0,0);
    return date;
  }
   const monthMap: { [key: string]: number } = { Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5, Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11 };
  match = displayTimestamp.match(/^([A-Za-z]{3})\s(\d{1,2})$/);
  if (match) {
    const monthAbbr = match[1];
    const day = parseInt(match[2]);
    if (monthMap.hasOwnProperty(monthAbbr)) {
      const month = monthMap[monthAbbr];
      let year = now.getFullYear();
      const potentialDate = new Date(year, month, day, 12,0,0,0);
      // If the parsed date is in the future (e.g. "Dec 25" when current date is "Jul 30"), assume last year
      if (potentialDate > now && (month > now.getMonth() || (month === now.getMonth() && day > now.getDate()))) {
        potentialDate.setFullYear(year - 1);
      }
      return potentialDate;
    }
  }
  
  const dayNames = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  const dayOfWeekStr = displayTimestamp.toLowerCase();
  const targetDayIndex = dayNames.indexOf(dayOfWeekStr);
  if (targetDayIndex !== -1) {
    const date = new Date(today);
    let currentDayIndex = today.getDay();
    let diffDays = currentDayIndex - targetDayIndex;
     if (diffDays <= 0) diffDays += 7; 

    date.setDate(today.getDate() - diffDays);
    date.setHours(12, 0, 0, 0);
    return date;
  }

  const parsedDate = new Date(displayTimestamp); // Try parsing directly for full dates
  if (!isNaN(parsedDate.getTime())) {
    return parsedDate;
  }
  return new Date(0); // Fallback for unparsed or invalid
}

