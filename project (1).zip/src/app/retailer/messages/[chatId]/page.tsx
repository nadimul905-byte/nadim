"use client";

import React, { useState, useEffect, useRef } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ArrowLeft, Send, Paperclip, Mic, Smile } from 'lucide-react';
import { mockRetailerChats, type MockRetailerChat, type RetailerChatMessage } from '../mockRetailerChatData';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { allMockProducts } from '@/app/retailer/products/page';

export default function RetailerChatPage() {
  const router = useRouter();
  const params = useParams();
  const chatId = params.chatId as string;
  const { toast } = useToast();

  const [chat, setChat] = useState<MockRetailerChat | null>(null);
  const [messages, setMessages] = useState<RetailerChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!chatId) return;
    const foundChat = mockRetailerChats.find(c => c.id === chatId);
    if (foundChat) {
      setChat(foundChat);
      setMessages([...foundChat.messages]); 
      if (foundChat.unreadCount > 0) {
        const chatIndex = mockRetailerChats.findIndex(c => c.id === chatId);
        if (chatIndex !== -1) {
          mockRetailerChats[chatIndex].unreadCount = 0;
        }
      }
    } else if (chatId && typeof chatId === 'string') {
      const vendorNameFromSlug = chatId.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
      const vendorProduct = allMockProducts.find(p => p.vendorName.toLowerCase().replace(/\s+/g, '-') === chatId);
      
      const newChatContext: MockRetailerChat = {
        id: chatId,
        vendorName: vendorProduct?.vendorName || vendorNameFromSlug,
        vendorAvatar: vendorProduct?.vendorAvatar || 'https://placehold.co/40x40.png?text=??',
        vendorAvatarAiHint: vendorProduct?.vendorAvatarAiHint || 'store logo',
        lastMessage: 'No messages yet.',
        unreadCount: 0,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        messages: [],
      };
      setChat(newChatContext);
      setMessages([]);

      if (!mockRetailerChats.some(c => c.id === chatId)) {
        mockRetailerChats.push(newChatContext);
      }
    } else {
        toast({ title: "Invalid Chat", description: "Could not load chat.", variant: "destructive" });
        router.push('/retailer/messages');
    }
  }, [chatId, router, toast]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMessage.trim() === '' || !chat) return;

    const newMsgId = `msg-${chat.id}-${Date.now()}`;
    const newMsg: RetailerChatMessage = {
      id: newMsgId,
      sender: 'retailer', 
      text: newMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    
    const chatIndex = mockRetailerChats.findIndex(c => c.id === chat.id);
    if (chatIndex !== -1) {
      mockRetailerChats[chatIndex].messages.push(newMsg);
      mockRetailerChats[chatIndex].lastMessage = newMsg.text;
      mockRetailerChats[chatIndex].timestamp = newMsg.timestamp;
      setMessages([...mockRetailerChats[chatIndex].messages]);
    }
    setNewMessage('');
  };
  
  if (!chat) return <div className="flex justify-center items-center h-full">Loading...</div>;

  return (
    <div className="flex flex-col h-[calc(100vh-10rem)]">
        <CardHeader className="flex flex-row items-center p-3 border-b sticky top-0 bg-background z-10">
            <Button variant="ghost" size="icon" onClick={() => router.push('/retailer/messages')} className="mr-2">
                <ArrowLeft className="h-5 w-5" />
            </Button>
            <Avatar className="h-10 w-10 mr-3">
                <AvatarImage src={chat.vendorAvatar} alt={chat.vendorName} data-ai-hint={chat.vendorAvatarAiHint} />
                <AvatarFallback>{chat.vendorName.substring(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
                <CardTitle className="text-lg">{chat.vendorName}</CardTitle>
                <CardDescription className="text-xs text-green-500">Online</CardDescription> 
            </div>
        </CardHeader>

        <CardContent className="flex-1 overflow-y-auto px-4 pt-4 pb-2 space-y-4">
            {messages.map((msg) => (
            <div
                key={msg.id}
                className={cn(
                "flex items-end max-w-[80%]",
                msg.sender === 'retailer' ? 'ml-auto flex-row-reverse' : 'mr-auto'
                )}
            >
                <div
                className={cn(
                    "p-3 rounded-lg shadow-sm",
                    msg.sender === 'retailer'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted'
                )}
                >
                <p className="text-sm">{msg.text}</p>
                </div>
            </div>
            ))}
            <div ref={messagesEndRef} />
        </CardContent>

        <CardFooter className="p-2 border-t">
            <form onSubmit={handleSendMessage} className="flex w-full items-center gap-2">
            <Input
                type="text"
                placeholder="Type a message..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                className="flex-1 h-10"
            />
            <Button type="submit" size="icon">
                <Send className="h-5 w-5" />
            </Button>
            </form>
        </CardFooter>
    </div>
  );
}
