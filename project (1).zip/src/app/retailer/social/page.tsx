"use client";

import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Heart, MessageCircle, Send, ShoppingBag, PlayCircle } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { mockSocialFeed, mockReels, type SocialPost, type SocialReel } from '@/lib/mockSocialData';


const SocialPostCard = ({ post }: { post: SocialPost }) => {
  return (
    <Card className="w-full max-w-xl mx-auto">
      <CardHeader className="flex flex-row items-center gap-4 p-4">
        {post.vendorSlug === '#' ? (
            <Avatar>
              <AvatarImage src={post.vendorAvatar} alt={post.vendorName} data-ai-hint={post.vendorAvatarAiHint}/>
              <AvatarFallback>{post.vendorName.charAt(0)}</AvatarFallback>
            </Avatar>
        ) : (
          <Link href={`/retailer/vendors/${post.vendorSlug}`}>
            <Avatar>
              <AvatarImage src={post.vendorAvatar} alt={post.vendorName} data-ai-hint={post.vendorAvatarAiHint}/>
              <AvatarFallback>{post.vendorName.charAt(0)}</AvatarFallback>
            </Avatar>
          </Link>
        )}
        <div>
          {post.vendorSlug === '#' ? (
            <p className="font-semibold">{post.vendorName}</p>
          ) : (
            <Link href={`/retailer/vendors/${post.vendorSlug}`} className="font-semibold hover:underline">
              {post.vendorName}
            </Link>
          )}
          <p className="text-xs text-muted-foreground">{post.timestamp}</p>
        </div>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <p className="mb-4 text-sm">{post.postText}</p>
        {post.postImage && (
          <div className="relative aspect-video w-full overflow-hidden rounded-lg border">
            <Image src={post.postImage} alt="Post image" layout="fill" objectFit="cover" data-ai-hint={post.postImageAiHint} />
          </div>
        )}
      </CardContent>
      <CardFooter className="flex flex-col items-start gap-3 p-4 border-t">
        <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-4">
                <Button variant="ghost" size="sm" className="flex items-center gap-1.5 text-muted-foreground">
                    <Heart className="h-4 w-4"/> {post.likes}
                </Button>
                <Button variant="ghost" size="sm" className="flex items-center gap-1.5 text-muted-foreground">
                    <MessageCircle className="h-4 w-4"/> {post.comments}
                </Button>
            </div>
            {post.productId && (
                 <Button asChild size="sm">
                    <Link href={`/retailer/products/${post.productId}`}>
                        <ShoppingBag className="mr-2 h-4 w-4" /> Shop Product
                    </Link>
                </Button>
            )}
        </div>
        <div className="flex w-full items-center gap-2">
            <Avatar className="h-8 w-8">
                <AvatarImage src="https://images.unsplash.com/photo-1714715506679-f356716590fb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxpbXxlbnwwfHx8fDE3NDg4NjIwNTd8MA&ixlib=rb-4.1.0&q=80&w=1080" alt="Retailer avatar" data-ai-hint="person avatar"/>
                <AvatarFallback>R</AvatarFallback>
            </Avatar>
            <Input placeholder="Add a comment..." className="h-9 flex-1" />
            <Button variant="ghost" size="icon"><Send className="h-5 w-5"/></Button>
        </div>
      </CardFooter>
    </Card>
  );
};

const ReelCard = ({ reel }: { reel: SocialReel }) => (
    <Card className="relative aspect-[9/16] w-full max-w-md mx-auto overflow-hidden rounded-2xl group cursor-pointer snap-center">
        <Image 
            src={reel.reelCoverImage} 
            alt={reel.caption} 
            layout="fill" 
            objectFit="cover" 
            className="transition-transform duration-300 group-hover:scale-105" 
            data-ai-hint={reel.reelCoverImageAiHint}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
        
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
             <PlayCircle className="h-20 w-20 text-white/50 transition-all group-hover:text-white/80 group-hover:scale-110 opacity-70 group-hover:opacity-100" />
        </div>

        <div className="absolute bottom-4 right-2 flex flex-col items-center gap-4 text-white">
            <Button variant="ghost" className="flex flex-col h-auto p-1 gap-1 text-white hover:bg-white/20 hover:text-white">
                <Heart className="h-7 w-7"/>
                <span className="text-xs font-bold">{reel.likes.toLocaleString()}</span>
            </Button>
            <Button variant="ghost" className="flex flex-col h-auto p-1 gap-1 text-white hover:bg-white/20 hover:text-white">
                <MessageCircle className="h-7 w-7"/>
                <span className="text-xs font-bold">{reel.comments.toLocaleString()}</span>
            </Button>
            {reel.productId && (
                <Button asChild variant="ghost" className="flex flex-col h-auto p-1 gap-1 text-white hover:bg-white/20 hover:text-white" onClick={(e) => e.stopPropagation()}>
                    <Link href={`/retailer/products/${reel.productId}`}>
                        <ShoppingBag className="h-7 w-7"/>
                        <span className="text-xs font-bold">Shop</span>
                    </Link>
                </Button>
            )}
        </div>

        <div className="absolute bottom-0 left-0 p-4 text-white w-[calc(100%_-_60px)]">
            <Link href={`/retailer/vendors/${reel.vendorSlug}`} onClick={(e) => e.stopPropagation()} className="block">
                <div className="flex items-center gap-2">
                    <Avatar className="h-9 w-9 border-2 border-white/80">
                      <AvatarImage src={reel.vendorAvatar} alt={reel.vendorName} data-ai-hint={reel.vendorAvatarAiHint}/>
                      <AvatarFallback>{reel.vendorName.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <p className="font-semibold text-sm hover:underline">{reel.vendorName}</p>
                </div>
            </Link>
            <p className="text-sm mt-2 line-clamp-2">{reel.caption}</p>
        </div>
    </Card>
);

export default function RetailerSocialFeedPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-headline font-semibold text-center">Community Feed</h1>
      
      <Tabs defaultValue="feed" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="feed">Feed</TabsTrigger>
            <TabsTrigger value="reels">Reels</TabsTrigger>
        </TabsList>
        <TabsContent value="feed" className="mt-6">
            <div className="space-y-6 h-[calc(100vh_-_15rem)] overflow-y-auto no-scrollbar p-1">
                {mockSocialFeed.map(post => (
                    <SocialPostCard key={post.id} post={post} />
                ))}
            </div>
        </TabsContent>
        <TabsContent value="reels" className="mt-6">
            <div className="w-full space-y-12 h-[calc(100vh_-_15rem)] snap-y snap-mandatory overflow-y-auto no-scrollbar p-1">
                {mockReels.map(reel => (
                    <ReelCard key={reel.id} reel={reel} />
                ))}
            </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
