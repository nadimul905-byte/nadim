
"use client";

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, PlusCircle, Edit3, Trash2, CreditCard, Star, ShieldCheck, CalendarIcon, KeyRound } from 'lucide-react';
import { useRouter } from 'next/navigation';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface PaymentMethod {
  id: string;
  cardType: string; // "Visa", "Mastercard", etc. (mocked)
  last4: string;
  expiryDate: string; // MM/YY
  cardholderName: string;
  isDefault?: boolean;
}

const RETAILER_PAYMENT_METHODS_STORAGE_KEY = 'ladookRetailerPaymentMethods';

const initialPaymentMethods: PaymentMethod[] = [
  { id: 'pm1', cardType: 'Visa', last4: '1234', expiryDate: '12/25', cardholderName: 'Jane Doe', isDefault: true },
  { id: 'pm2', cardType: 'Mastercard', last4: '5678', expiryDate: '06/26', cardholderName: 'Jane Doe', isDefault: false },
];

// Function to determine card type (very basic mock)
const getCardType = (cardNumber: string): string => {
  if (cardNumber.startsWith('4')) return 'Visa';
  if (cardNumber.startsWith('5')) return 'Mastercard';
  if (cardNumber.startsWith('34') || cardNumber.startsWith('37')) return 'Amex';
  return 'Card'; // Generic
};

const PaymentMethodForm = ({ paymentMethod, onSave, onCancel }: { paymentMethod?: PaymentMethod | null, onSave: (pm: PaymentMethod) => void, onCancel: () => void }) => {
  const [formData, setFormData] = useState({
    cardNumber: paymentMethod ? `•••• •••• •••• ${paymentMethod.last4}` : '', // Mask for display, handle full for new
    expiryDate: paymentMethod?.expiryDate || '',
    cvc: '', // Not stored, just for form
    cardholderName: paymentMethod?.cardholderName || '',
    isDefault: paymentMethod?.isDefault || false,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
        const { checked } = e.target as HTMLInputElement;
        setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
        setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.cardholderName || !formData.cardNumber || !formData.expiryDate || (!paymentMethod && !formData.cvc) ) {
        alert("Please fill all required fields for the payment method.");
        return;
    }
    
    const actualCardNumber = paymentMethod && formData.cardNumber.includes('••••') ? paymentMethod.last4 : formData.cardNumber.replace(/\s/g, '').slice(-4);
    const cardType = getCardType(paymentMethod && formData.cardNumber.includes('••••') ? paymentMethod.cardType.charAt(0) + actualCardNumber : formData.cardNumber);


    onSave({ 
      ...formData, 
      id: paymentMethod?.id || `pm-${Date.now()}`,
      last4: actualCardNumber,
      cardType: cardType
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div><Label htmlFor="cardholderName">Cardholder Name</Label><Input id="cardholderName" name="cardholderName" value={formData.cardholderName} onChange={handleChange} required /></div>
      <div><Label htmlFor="cardNumber">Card Number</Label><Input id="cardNumber" name="cardNumber" value={formData.cardNumber} onChange={handleChange} placeholder="•••• •••• •••• ••••" required /></div>
      <div className="grid grid-cols-2 gap-4">
        <div><Label htmlFor="expiryDate">Expiry Date (MM/YY)</Label><Input id="expiryDate" name="expiryDate" value={formData.expiryDate} onChange={handleChange} placeholder="MM/YY" required /></div>
        <div><Label htmlFor="cvc">CVC</Label><Input id="cvc" name="cvc" value={formData.cvc} onChange={handleChange} placeholder="•••" required={!paymentMethod} /></div>
      </div>
      <div className="flex items-center space-x-2">
        <Checkbox id="isDefault" name="isDefault" checked={formData.isDefault} onCheckedChange={(checked) => setFormData(prev => ({...prev, isDefault: Boolean(checked)}))}/>
        <Label htmlFor="isDefault">Set as default payment method</Label>
      </div>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
        <Button type="submit">{paymentMethod ? 'Save Changes' : 'Add Card'}</Button>
      </DialogFooter>
    </form>
  );
};

export default function RetailerPaymentMethodsPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingPaymentMethod, setEditingPaymentMethod] = useState<PaymentMethod | null>(null);
  const [methodToDelete, setMethodToDelete] = useState<PaymentMethod | null>(null);

  useEffect(() => {
    const storedMethods = localStorage.getItem(RETAILER_PAYMENT_METHODS_STORAGE_KEY);
    if (storedMethods) {
      setPaymentMethods(JSON.parse(storedMethods));
    } else {
      localStorage.setItem(RETAILER_PAYMENT_METHODS_STORAGE_KEY, JSON.stringify(initialPaymentMethods));
      setPaymentMethods(initialPaymentMethods);
    }
  }, []);

  const savePaymentMethodsToStorage = (updatedMethods: PaymentMethod[]) => {
    localStorage.setItem(RETAILER_PAYMENT_METHODS_STORAGE_KEY, JSON.stringify(updatedMethods));
    setPaymentMethods(updatedMethods);
  };

  const handleSaveMethod = (method: PaymentMethod) => {
    let updatedMethods;
    if (editingPaymentMethod) {
      updatedMethods = paymentMethods.map(pm => (pm.id === method.id ? method : pm));
    } else {
      updatedMethods = [...paymentMethods, method];
    }

    if (method.isDefault) {
      updatedMethods = updatedMethods.map(pm => ({ ...pm, isDefault: pm.id === method.id }));
    }
    
    savePaymentMethodsToStorage(updatedMethods);
    toast({ title: editingPaymentMethod ? "Payment Method Updated" : "Payment Method Added", description: `Card ending in ${method.last4} has been saved.` });
    setIsFormOpen(false);
    setEditingPaymentMethod(null);
  };
  
  const handleSetDefault = (methodId: string) => {
    const updatedMethods = paymentMethods.map(pm => ({
      ...pm,
      isDefault: pm.id === methodId
    }));
    savePaymentMethodsToStorage(updatedMethods);
    toast({ title: "Default Payment Method Set", description: "Your default payment method has been updated." });
  };

  const openEditForm = (method: PaymentMethod) => {
    setEditingPaymentMethod(method);
    setIsFormOpen(true);
  };

  const openAddForm = () => {
    setEditingPaymentMethod(null);
    setIsFormOpen(true);
  };

  const handleDeleteMethod = () => {
    if (!methodToDelete) return;
    const updatedMethods = paymentMethods.filter(pm => pm.id !== methodToDelete.id);
    savePaymentMethodsToStorage(updatedMethods);
    toast({ title: "Payment Method Deleted", description: `Card ending in ${methodToDelete.last4} has been removed.`, variant: "destructive" });
    setMethodToDelete(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={() => router.back()}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Profile
        </Button>
        <Dialog open={isFormOpen} onOpenChange={(open) => { setIsFormOpen(open); if (!open) setEditingPaymentMethod(null); }}>
          <DialogTrigger asChild>
            <Button onClick={openAddForm}>
              <PlusCircle className="mr-2 h-4 w-4" /> Add New Card
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>{editingPaymentMethod ? 'Edit Payment Method' : 'Add New Card'}</DialogTitle>
              <DialogDescription>
                {editingPaymentMethod ? 'Update the details of your card.' : 'Enter your card details securely.'}
              </DialogDescription>
            </DialogHeader>
            <PaymentMethodForm 
                paymentMethod={editingPaymentMethod} 
                onSave={handleSaveMethod} 
                onCancel={() => { setIsFormOpen(false); setEditingPaymentMethod(null); }} 
            />
          </DialogContent>
        </Dialog>
      </div>

      <h1 className="text-3xl font-headline font-semibold">Payment Methods</h1>

      {paymentMethods.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <CreditCard className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold">No Payment Methods Saved</h3>
            <p className="text-muted-foreground">Add a card for faster and easier checkouts.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {paymentMethods.map(pm => (
            <Card key={pm.id} className={`flex flex-col sm:flex-row justify-between sm:items-center p-4 ${pm.isDefault ? 'border-primary border-2' : ''}`}>
              <div className="flex items-center mb-3 sm:mb-0">
                <CreditCard className="h-8 w-8 text-primary mr-4 flex-shrink-0" />
                <div>
                  <p className="font-semibold text-foreground">{pm.cardType} ending in •••• {pm.last4}</p>
                  <p className="text-sm text-muted-foreground">Expires: {pm.expiryDate} {pm.isDefault && <span className="ml-2 text-xs font-medium text-primary">(Default)</span>}</p>
                </div>
              </div>
              <div className="flex gap-2 self-end sm:self-center">
                {!pm.isDefault && (
                   <Button variant="outline" size="sm" onClick={() => handleSetDefault(pm.id)}>Set Default</Button>
                )}
                <Button variant="ghost" size="icon" onClick={() => openEditForm(pm)}>
                  <Edit3 className="h-4 w-4" />
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="ghost" size="icon" onClick={() => setMethodToDelete(pm)} className="text-destructive hover:text-destructive hover:bg-destructive/10">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This action cannot be undone. This will permanently delete your card ending in {methodToDelete?.last4}.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel onClick={() => setMethodToDelete(null)}>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleDeleteMethod} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">Delete</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

