"use client";

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Save, Loader2, Fingerprint, KeyRound } from 'lucide-react';

export default function RetailerWalletSecurityPage() {
  const router = useRouter();
  const { toast } = useToast();

  const [usePin, setUsePin] = useState(true);
  const [useFingerprint, setUseFingerprint] = useState(false);
  const [isChangingPin, setIsChangingPin] = useState(false);
  const [currentPin, setCurrentPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmNewPin, setConfirmNewPin] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSavePin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPin.length !== 4) {
      toast({ title: "Invalid PIN", description: "Your new PIN must be 4 digits.", variant: "destructive" });
      return;
    }
    if (newPin !== confirmNewPin) {
      toast({ title: "PINs Do Not Match", description: "Please ensure the new and confirmation PINs match.", variant: "destructive" });
      return;
    }
    
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    toast({ title: "PIN Updated", description: "Your wallet PIN has been successfully changed." });
    setIsChangingPin(false);
    setCurrentPin('');
    setNewPin('');
    setConfirmNewPin('');
    setIsSubmitting(false);
  };

  const handleFingerprintSetup = () => {
    // In a real app, this would trigger the device's biometric prompt.
    // Here, we'll just simulate it.
    toast({ title: "Simulating Biometric Setup...", description: "Please follow your device's instructions." });
    setTimeout(() => {
      setUseFingerprint(true);
      toast({ title: "Biometric Login Enabled", description: "You can now use your fingerprint to unlock your wallet." });
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.push('/retailer/profile/wallet')}>
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Wallet
      </Button>

      <h1 className="text-3xl font-headline font-semibold">Wallet Security</h1>

      <Card>
        <CardHeader>
          <CardTitle>Authentication Methods</CardTitle>
          <CardDescription>Enhance the security of your wallet with these options.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 divide-y">
          <div className="flex items-center justify-between pt-4 first:pt-0">
            <Label htmlFor="pin-switch" className="flex items-center gap-3">
              <KeyRound className="h-5 w-5 text-muted-foreground" />
              Require PIN for Transactions
            </Label>
            <Switch id="pin-switch" checked={usePin} onCheckedChange={setUsePin} />
          </div>
          <div className="flex items-center justify-between pt-4">
            <Label htmlFor="fingerprint-switch" className="flex items-center gap-3">
              <Fingerprint className="h-5 w-5 text-muted-foreground" />
              Use Fingerprint / Face ID
            </Label>
            <Switch id="fingerprint-switch" checked={useFingerprint} onCheckedChange={(checked) => {
              if (checked) handleFingerprintSetup();
              else setUseFingerprint(false);
            }} />
          </div>
        </CardContent>
      </Card>
      
      <Card>
          <CardHeader>
              <CardTitle>Manage PIN</CardTitle>
          </CardHeader>
           <CardContent>
               <Button onClick={() => setIsChangingPin(true)} disabled={isChangingPin}>Change Wallet PIN</Button>
               {isChangingPin && (
                   <form onSubmit={handleSavePin} className="mt-6 space-y-4 border-t pt-6">
                       <div>
                           <Label htmlFor="currentPin">Current PIN</Label>
                           <Input id="currentPin" type="password" maxLength={4} value={currentPin} onChange={e => setCurrentPin(e.target.value)} required />
                       </div>
                       <div>
                           <Label htmlFor="newPin">New 4-Digit PIN</Label>
                           <Input id="newPin" type="password" maxLength={4} value={newPin} onChange={e => setNewPin(e.target.value)} required />
                       </div>
                       <div>
                           <Label htmlFor="confirmNewPin">Confirm New PIN</Label>
                           <Input id="confirmNewPin" type="password" maxLength={4} value={confirmNewPin} onChange={e => setConfirmNewPin(e.target.value)} required />
                       </div>
                       <div className="flex justify-end gap-3">
                           <Button type="button" variant="ghost" onClick={() => setIsChangingPin(false)}>Cancel</Button>
                           <Button type="submit" disabled={isSubmitting}>
                               {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Save className="mr-2 h-4 w-4"/>}
                               Save New PIN
                           </Button>
                       </div>
                   </form>
               )}
           </CardContent>
      </Card>

    </div>
  );
}
