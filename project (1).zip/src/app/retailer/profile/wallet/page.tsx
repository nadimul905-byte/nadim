"use client";

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { 
  ArrowLeft, Wallet, Plus, Settings, 
  History, CreditCard, Banknote, Landmark, 
  ArrowRight, Sparkles, LineChart, TrendingUp, 
  Loader2, ShieldCheck
} from 'lucide-react';
import Link from 'next/link';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';

// Mock data
const mockTransactions = [
  { id: 'txn1', type: 'Purchase', amount: -250.00, description: 'Order #ORDC123 - Chic Designs Co.', date: '2024-07-29' },
  { id: 'txn2', type: 'Funding', amount: 1000.00, description: 'Added funds from Visa **** 1234', date: '2024-07-28' },
  { id: 'txn3', type: 'Purchase', amount: -75.50, description: 'Order #ORDC122 - Summer Styles', date: '2024-07-27' },
  { id: 'txn4', type: 'Refund', amount: 50.00, description: 'Refund for Order #ORDC119', date: '2024-07-26' },
];

const mockPaymentMethods = [
  { id: 'pm1', type: 'Visa', last4: '1234' },
  { id: 'pm2', type: 'Mastercard', last4: '5678' },
];

const financialPartners = [
  { id: 'bank-of-style', name: 'Bank of Style', logo: 'https://picsum.photos/seed/bos_logo/80/80', aiHint: 'bank logo' },
  { id: 'commerce-capital', name: 'Commerce Capital', logo: 'https://picsum.photos/seed/cc_logo/80/80', aiHint: 'financial logo' },
];

export default function RetailerWalletPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [balance, setBalance] = useState(724.50);
  const [lkoinBalance, setLkoinBalance] = useState(1250.00);
  
  const [addAmount, setAddAmount] = useState('');
  const [selectedCard, setSelectedCard] = useState('pm1');
  const [isAddingFunds, setIsAddingFunds] = useState(false);
  
  const [convertAmount, setConvertAmount] = useState('');
  const [isConverting, setIsConverting] = useState(false);
  
  const LKoinRate = 10; 
  const marketPrice = 0.12; 
  const priceChange = 5.24; 

  const handleAddFunds = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(addAmount);
    if (!amount || amount <= 0) return;
    setIsAddingFunds(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setBalance(prev => prev + amount);
    toast({ title: "Funds Added!", description: `$${amount.toFixed(2)} added to your wallet.` });
    setAddAmount('');
    setIsAddingFunds(false);
  };
  
  const handleConversion = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(convertAmount);
    if (!amount || amount <= 0 || amount > balance) return;
    setIsConverting(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setBalance(prev => prev - amount);
    setLkoinBalance(prev => prev + (amount * LKoinRate));
    toast({ title: "Conversion Successful!" });
    setIsConverting(false);
  };

  return (
    <div className="space-y-6 max-w-xs mx-auto px-1 pb-20">
      <div className="flex items-center justify-between">
        <Button variant="outline" size="icon" onClick={() => router.back()} className="rounded-full h-10 w-10">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="text-center">
            <h1 className="text-xl font-headline font-bold">Finance Hub</h1>
            <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest">Retailer Wallet</p>
        </div>
        <Button variant="ghost" size="icon" asChild className="rounded-full h-10 w-10">
            <Link href="/retailer/settings">
                <Settings className="h-5 w-5" />
            </Link>
        </Button>
      </div>

      <Card className="bg-zinc-900 text-white rounded-[2rem] border-none shadow-2xl overflow-hidden relative">
        <div className="absolute top-0 right-0 p-6 opacity-10">
            <Wallet className="h-24 w-24" />
        </div>
        <CardHeader className="p-6 pb-2">
          <CardTitle className="text-xs uppercase font-black tracking-widest text-zinc-400">Available Funds (USD)</CardTitle>
        </CardHeader>
        <CardContent className="p-6 pt-0">
          <p className="text-4xl font-black tracking-tighter">${balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
          <div className="flex items-center gap-2 mt-2">
              <Badge className="bg-primary/20 text-primary-foreground border-none text-[10px] font-bold">
                  Verified Account
              </Badge>
              <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-tight">Active Buyer</span>
          </div>
        </CardContent>
        <CardFooter className="p-4 bg-white/5 border-t border-white/5 grid grid-cols-1 gap-2">
           <Dialog>
              <DialogTrigger asChild>
                <Button className="w-full rounded-2xl h-12 bg-white text-black hover:bg-zinc-200 font-bold text-xs uppercase">
                  <Plus className="mr-2 h-4 w-4" /> Add Funds
                </Button>
              </DialogTrigger>
              <DialogContent className="rounded-[2rem] max-w-sm mx-auto">
                <DialogHeader>
                  <DialogTitle>Add Funds</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleAddFunds} className="space-y-4">
                    <div className="space-y-2">
                        <Label>Amount (USD)</Label>
                        <Input type="number" placeholder="0.00" value={addAmount} onChange={(e) => setAddAmount(e.target.value)} required />
                    </div>
                    <div className="space-y-2">
                        <Label>Select Card</Label>
                        <RadioGroup defaultValue="pm1" value={selectedCard} onValueChange={setSelectedCard} className="space-y-2">
                            {mockPaymentMethods.map(pm => (
                                <Label key={pm.id} htmlFor={pm.id} className="flex items-center space-x-3 p-3 border rounded-2xl cursor-pointer">
                                    <RadioGroupItem value={pm.id} id={pm.id} />
                                    <CreditCard className="h-5 w-5 mr-2 text-primary" />
                                    <span className="text-xs font-bold">{pm.type} ending in **** {pm.last4}</span>
                                </Label>
                            ))}
                        </RadioGroup>
                    </div>
                    <Button type="submit" className="w-full h-12 rounded-2xl font-bold uppercase" disabled={isAddingFunds}>
                        {isAddingFunds ? <Loader2 className="animate-spin h-5 w-5"/> : "Confirm Top-up"}
                    </Button>
                </form>
              </DialogContent>
          </Dialog>
        </CardFooter>
      </Card>

      <Card className="rounded-[2rem] border shadow-lg bg-gradient-to-br from-amber-50 to-white dark:from-zinc-900/50 dark:to-zinc-900">
        <CardHeader className="p-6 pb-2">
          <div className="flex justify-between items-start">
            <CardTitle className="text-xs uppercase font-black tracking-widest text-amber-600">Assets: LKoin</CardTitle>
            <Badge className="bg-amber-100 text-amber-700 border-none font-bold text-[10px]">
                +{priceChange}%
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="p-6 pt-0">
          <p className="text-3xl font-black text-foreground">LK {lkoinBalance.toFixed(2)}</p>
          <p className="text-[10px] text-muted-foreground font-medium mt-1">Reward Value: ${(lkoinBalance * marketPrice).toFixed(2)} USD</p>
        </CardContent>
        <CardFooter className="p-4 grid grid-cols-1 border-t">
             <Dialog>
                <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="rounded-xl h-10 text-[10px] font-black uppercase">
                        <Plus className="mr-1.5 h-3.5 w-3.5"/> Convert USD to LKoin
                    </Button>
                </DialogTrigger>
                <DialogContent className="rounded-[2rem] max-sm">
                    <DialogHeader><DialogTitle>Quick Conversion</DialogTitle></DialogHeader>
                    <div className="space-y-4 py-4">
                        <Input type="number" placeholder="USD Amount" value={convertAmount} onChange={(e) => setConvertAmount(e.target.value)} />
                        <p className="text-center text-xs font-bold">Receive: {parseFloat(convertAmount || '0') * LKoinRate} LKoin</p>
                        <Button onClick={handleConversion} className="w-full rounded-2xl h-12" disabled={isConverting}>Convert Now</Button>
                    </div>
                </DialogContent>
             </Dialog>
        </CardFooter>
      </Card>

      <div className="space-y-4">
        <div className="flex items-center justify-between px-2">
            <h2 className="text-[10px] uppercase font-black tracking-[0.3em] text-muted-foreground">Inventory Financing</h2>
            <Button variant="link" size="sm" asChild className="p-0 h-auto text-[10px] font-black uppercase text-primary">
                <Link href="/retailer/profile/microfinance">Full Center</Link>
            </Button>
        </div>
        <Card className="rounded-[2rem] border shadow-md overflow-hidden bg-primary/5 border-primary/10">
            <CardHeader className="p-6">
                <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-2xl bg-primary/10 flex items-center justify-center">
                        <Landmark className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                        <CardTitle className="text-sm font-bold text-foreground">Inventory Credit Line</CardTitle>
                        <CardDescription className="text-[10px] font-medium">Power your next collection</CardDescription>
                    </div>
                </div>
            </CardHeader>
            <CardContent className="px-6 pb-6 pt-0">
                <div className="p-4 bg-background rounded-2xl border flex items-center justify-between shadow-sm">
                    <div>
                        <p className="text-[8px] uppercase font-bold text-muted-foreground tracking-widest">Available Credit</p>
                        <p className="text-xl font-black text-primary">$15,000</p>
                    </div>
                    <Button size="sm" variant="ghost" className="text-primary font-bold text-[10px] uppercase" asChild>
                        <Link href="/retailer/profile/microfinance">Increase <ArrowRight className="ml-1 h-3 w-3"/></Link>
                    </Button>
                </div>
            </CardContent>
        </Card>

        <div className="grid grid-cols-2 gap-3">
            {financialPartners.map(partner => (
                <Card key={partner.id} className="rounded-3xl p-4 flex flex-col items-center text-center gap-3 hover:border-primary/50 cursor-pointer transition-all shadow-sm" onClick={() => router.push(`/retailer/profile/microfinance/${partner.id}`)}>
                    <Avatar className="h-12 w-12 border-2 border-background shadow-md">
                        <AvatarImage src={partner.logo} data-ai-hint={partner.aiHint} />
                        <AvatarFallback>{partner.name[0]}</AvatarFallback>
                    </Avatar>
                    <p className="text-[10px] font-black uppercase tracking-tighter line-clamp-1">{partner.name}</p>
                    <Button variant="ghost" size="xs" className="h-6 text-[8px] font-bold uppercase text-primary">Apply</Button>
                </Card>
            ))}
             <Card className="rounded-3xl p-4 flex flex-col items-center justify-center text-center gap-3 hover:border-primary/50 cursor-pointer transition-all shadow-sm border-dashed col-span-2" onClick={() => router.push('/retailer/profile/microfinance')}>
                <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center">
                    <Plus className="h-5 w-5 text-muted-foreground" />
                </div>
                <p className="text-[10px] font-black uppercase tracking-tighter">See More Partners</p>
            </Card>
        </div>
      </div>

      <Card className="rounded-[2rem] border-none bg-zinc-100 dark:bg-zinc-800/50 shadow-none">
          <CardContent className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                      <ShieldCheck className="h-4 w-4 text-primary" />
                      <span className="text-[10px] font-black uppercase tracking-widest text-foreground">Trust Analytics</span>
                  </div>
                  <Badge className="bg-primary/10 text-primary border-none text-[9px] font-bold">Platinum Buyer</Badge>
              </div>
              <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                      <p className="text-xl font-black text-foreground">99%</p>
                      <p className="text-[8px] uppercase font-bold text-muted-foreground">Payment Rate</p>
                  </div>
                  <div className="space-y-1">
                      <p className="text-xl font-black text-foreground">4.8 ★</p>
                      <p className="text-[8px] uppercase font-bold text-muted-foreground">Reputation</p>
                  </div>
              </div>
          </CardContent>
      </Card>

      <Card className="rounded-[2rem] border shadow-md">
        <CardHeader className="p-6">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-bold flex items-center gap-2 text-foreground">
              <History className="h-4 w-4 text-primary" /> History
            </CardTitle>
            <Button variant="link" size="sm" asChild className="p-0 h-auto text-[10px] font-bold uppercase text-primary">
              <Link href="/retailer/profile/wallet/transactions">View All</Link>
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y">
            {mockTransactions.map(tx => (
              <Link key={tx.id} href={`/retailer/profile/wallet/transactions/${tx.id}`} className="flex items-center justify-between p-4 hover:bg-muted/50 transition-colors">
                <div className="min-w-0">
                  <p className="text-xs font-bold truncate pr-2 text-foreground">{tx.description}</p>
                  <p className="text-[9px] text-muted-foreground uppercase font-black tracking-widest">{tx.date}</p>
                </div>
                <p className={cn("text-sm font-black whitespace-nowrap ml-2", tx.amount > 0 ? 'text-green-600' : 'text-foreground')}>
                  {tx.amount > 0 ? `+$${tx.amount.toFixed(2)}` : `-$${Math.abs(tx.amount).toFixed(2)}`}
                </p>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
