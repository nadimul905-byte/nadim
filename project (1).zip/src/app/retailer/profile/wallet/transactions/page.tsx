"use client";

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, History, Search } from 'lucide-react';
import Link from 'next/link';

// Using a slightly expanded mock data set for a full page
const mockAllTransactions = [
  { id: 'txn1', type: 'Purchase', amount: -250.00, description: 'Order #ORD123 - Chic Designs Co.', date: '2024-07-29', status: 'Completed' },
  { id: 'txn2', type: 'Funding', amount: 1000.00, description: 'Added funds from Visa **** 1234', date: '2024-07-28', status: 'Completed' },
  { id: 'txn3', type: 'Purchase', amount: -75.50, description: 'Order #ORD122 - Summer Styles', date: '2024-07-27', status: 'Completed' },
  { id: 'txn4', type: 'Refund', amount: 50.00, description: 'Refund for Order #ORD119', date: '2024-07-26', status: 'Completed' },
  { id: 'txn5', type: 'Purchase', amount: -45.00, description: 'Order #ORD121 - Artisan Goods', date: '2024-07-25', status: 'Completed' },
  { id: 'txn6', type: 'Funding', amount: 50.00, description: 'Added funds from Mastercard **** 5678', date: '2024-07-24', status: 'Completed' },
];

type Transaction = typeof mockAllTransactions[0];

export default function RetailerAllTransactionsPage() {
  const router = useRouter();
  const [transactions, setTransactions] = useState<Transaction[]>(mockAllTransactions);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('All');

  const filteredTransactions = transactions.filter(tx => {
    const matchesSearch = tx.description.toLowerCase().includes(searchTerm.toLowerCase()) || tx.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'All' || tx.type === filterType;
    return matchesSearch && matchesType;
  });
  
  const transactionTypes = ["All", ...Array.from(new Set(mockAllTransactions.map(tx => tx.type)))];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={() => router.push('/retailer/profile/wallet')}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Wallet
        </Button>
        <h1 className="text-3xl font-headline font-semibold">All Transactions</h1>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Transaction History</CardTitle>
          <CardDescription>Browse and filter all your wallet activities.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-4">
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search by description or ID..." 
                className="pl-10" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                {transactionTypes.map(type => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-4">
            {filteredTransactions.length > 0 ? filteredTransactions.map(tx => (
              <Link key={tx.id} href={`/retailer/profile/wallet/transactions/${tx.id}`} className="block p-3 rounded-lg hover:bg-muted/50 transition-colors border">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-semibold">{tx.description}</p>
                    <p className="text-xs text-muted-foreground">{tx.date} - {tx.type}</p>
                  </div>
                  <p className={`font-semibold text-lg ${tx.amount > 0 ? 'text-green-500' : 'text-foreground'}`}>
                    {tx.amount > 0 ? `+$${tx.amount.toFixed(2)}` : `-$${Math.abs(tx.amount).toFixed(2)}`}
                  </p>
                </div>
              </Link>
            )) : (
                <div className="text-center py-8 text-muted-foreground">
                    <History className="mx-auto h-12 w-12 mb-4"/>
                    <p>No transactions match your search.</p>
                </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
