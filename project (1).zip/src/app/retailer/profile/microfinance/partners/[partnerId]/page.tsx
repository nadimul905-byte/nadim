
"use client";

import React from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { 
    ArrowLeft, CheckCircle2, Info, ShieldCheck, TrendingUp, 
    Landmark, Shield, Award, ChevronRight, ArrowRight,
    Scale, Calculator, Clock, Globe, Briefcase
} from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

const financialPartners = [
  {
    id: 'bank-of-style',
    name: 'Bank of Style',
    logo: 'https://picsum.photos/seed/bos_logo/80/80',
    aiHint: 'bank logo',
    description: 'A specialized financial institution dedicated to high-growth fashion startups and emerging boutique retailers. We utilize real-time inventory intelligence to provide flexible liquidity.',
    features: [
        'Direct PO-based inventory financing', 
        'Flexible 6-24 month repayment terms', 
        'Automated drawdown based on GMV', 
        'Priority access for Platinum partners'
    ],
    stats: {
        interestRate: '4.2% - 7.5%',
        maxCap: '$50,000',
        auditTime: '24-48 Hours',
        onTimeFulfillment: '99.8%'
    }
  },
  {
    id: 'commerce-capital',
    name: 'Commerce Capital',
    logo: 'https://picsum.photos/seed/cc_logo/80/80',
    aiHint: 'financial logo',
    description: 'Empowering the global retail sector with industrial-grade working capital solutions. Our underwriting engine is directly integrated with the Ladook Procurement Hub.',
    features: [
        'Unsecured lines of credit', 
        'Raw material procurement funding', 
        'International trade compliance support', 
        'Volume-based rate discounting'
    ],
    stats: {
        interestRate: '5.0% - 8.2%',
        maxCap: '$100,000',
        auditTime: '3-5 Days',
        onTimeFulfillment: '98.5%'
    }
  },
  {
    id: 'artisan-alliance',
    name: 'Artisan Alliance',
    logo: 'https://picsum.photos/seed/aa_logo/80/80',
    aiHint: 'alliance logo',
    description: 'A community-focused capital partner dedicated to independent creators and micro-manufacturers. We bridge the gap between production skill and market scaling.',
    features: [
        'Micro-loans from $500', 
        'Low-interest social impact rates', 
        'Business mentorship integration', 
        'Zero early-repayment penalties'
    ],
    stats: {
        interestRate: '2.5% - 5.0%',
        maxCap: '$15,000',
        auditTime: '24 Hours',
        onTimeFulfillment: '100%'
    }
  },
];

export default function RetailerPartnerDetailsPage() {
    const router = useRouter();
    const params = useParams();
    const partnerId = params?.partnerId as string;
    
    const partner = financialPartners.find(p => p.id === partnerId);

    if (!partner) {
        return (
            <div className="flex flex-col items-center justify-center py-20 text-center space-y-4 max-w-xs mx-auto">
                <Info className="h-12 w-12 text-muted-foreground opacity-20" />
                <p className="font-black text-muted-foreground uppercase text-[10px] tracking-widest">Partner Data Offline</p>
                <Button variant="outline" onClick={() => router.back()} className="rounded-xl w-full">Go Back</Button>
            </div>
        );
    }

    return (
        <div className="space-y-6 max-w-xs mx-auto px-1 pb-24 animate-in fade-in duration-500">
            <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => router.back()} className="rounded-full h-10 w-10 border-zinc-200 shadow-sm">
                    <ArrowLeft className="h-5 w-5 text-zinc-600" />
                </Button>
                <div>
                    <h1 className="text-xl font-headline font-black tracking-tight leading-tight">Partner Audit</h1>
                    <p className="text-[10px] text-muted-foreground uppercase font-black tracking-[0.2em]">Bank Profile v4.1</p>
                </div>
            </div>
            
            <Card className="rounded-[2.5rem] border shadow-lg overflow-hidden bg-card">
                <CardHeader className="bg-muted/30 p-8 flex flex-col items-center text-center border-b border-dashed">
                    <div className="relative h-24 w-24 mb-4">
                        <Image 
                            src={partner.logo} 
                            alt={partner.name} 
                            fill 
                            className="rounded-full border-4 border-background shadow-xl object-cover" 
                            data-ai-hint={partner.aiHint}
                        />
                        <div className="absolute -bottom-1 -right-1 bg-primary rounded-full p-1.5 shadow-lg border-2 border-background">
                            <ShieldCheck className="h-4 w-4 text-white" />
                        </div>
                    </div>
                    <CardTitle className="text-2xl font-headline font-black leading-tight text-center">{partner.name}</CardTitle>
                    <div className="flex gap-2 mt-2">
                        <Badge variant="outline" className="bg-primary/5 text-primary border-primary/20 text-[9px] font-black uppercase tracking-widest px-3">Tier 1 Provider</Badge>
                        <Badge variant="outline" className="bg-green-500/5 text-green-600 border-green-500/20 text-[9px] font-black uppercase tracking-widest px-3">Verified Institutional</Badge>
                    </div>
                </CardHeader>
                <CardContent className="p-6 space-y-8">
                    <div className="space-y-2">
                        <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-400">Institutional Manifesto</h4>
                        <p className="text-[11px] font-medium text-muted-foreground leading-relaxed italic">
                            "{partner.description}"
                        </p>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3">
                        <div className="p-4 bg-secondary/50 rounded-2xl border text-center space-y-1">
                            <p className="text-[8px] font-black uppercase text-muted-foreground tracking-widest">Base Rate</p>
                            <p className="text-base font-black text-primary">{partner.stats.interestRate}</p>
                        </div>
                        <div className="p-4 bg-secondary/50 rounded-2xl border text-center space-y-1">
                            <p className="text-[8px] font-black uppercase text-muted-foreground tracking-widest">Max Manifest</p>
                            <p className="text-base font-black text-primary">{partner.stats.maxCap}</p>
                        </div>
                        <div className="p-4 bg-secondary/50 rounded-2xl border text-center space-y-1">
                            <p className="text-[8px] font-black uppercase text-muted-foreground tracking-widest">Audit Time</p>
                            <p className="text-base font-black text-primary">{partner.stats.auditTime}</p>
                        </div>
                        <div className="p-4 bg-secondary/50 rounded-2xl border text-center space-y-1">
                            <p className="text-[8px] font-black uppercase text-muted-foreground tracking-widest">Integrity</p>
                            <p className="text-base font-black text-primary">{partner.stats.onTimeFulfillment}</p>
                        </div>
                    </div>

                    <Separator className="border-dashed" />

                    <div className="space-y-4">
                        <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-foreground flex items-center gap-2">
                            <Scale className="h-3 w-3 text-primary" /> Operational Advantages
                        </h4>
                        <ul className="space-y-3">
                            {partner.features.map((feature, index) => (
                                <li key={index} className="flex items-start gap-3 p-3 bg-muted/20 rounded-xl border border-zinc-100">
                                    <CheckCircle2 className="h-4 w-4 text-green-500 flex-shrink-0 mt-0.5" />
                                    <span className="text-[10px] font-bold text-zinc-700 leading-tight uppercase tracking-tight">{feature}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                </CardContent>
                <CardFooter className="p-6 pt-0">
                    <Button className="w-full h-14 rounded-2xl bg-zinc-900 text-white hover:bg-zinc-800 font-black uppercase text-xs shadow-xl active:scale-95 transition-all" asChild>
                        <Link href={`/retailer/profile/microfinance/${partner.id}`}>
                            Apply for Manifest Capital <ArrowRight className="ml-2 h-4 w-4" />
                        </Link>
                    </Button>
                </CardFooter>
            </Card>

            <Card className="rounded-[2rem] border-none bg-primary/5 shadow-none ring-1 ring-primary/10">
                <CardContent className="p-6 space-y-4">
                    <div className="flex items-center gap-2">
                        <ShieldCheck className="h-5 w-5 text-primary" />
                        <span className="text-[10px] font-black uppercase tracking-[0.2em]">Ladook Trust Bridge Integration</span>
                    </div>
                    <p className="text-[11px] font-medium text-primary/70 leading-relaxed italic border-l-2 border-primary/30 pl-4">
                        "{partner.name} prioritizes Ladook users with a **Platinum Trust Score**. Your current profile qualifies for **technical collateral** status, bypassing traditional document-heavy cycles."
                    </p>
                </CardContent>
            </Card>
        </div>
    );
}
