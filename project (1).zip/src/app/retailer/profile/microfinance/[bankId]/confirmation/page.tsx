
"use client";

import React from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, Clock } from 'lucide-react';
import Link from 'next/link';

export default function MicrofinanceConfirmationPage() {
  const router = useRouter();
  const params = useParams();
  const bankId = params.bankId as string;
  const bankName = bankId ? bankId.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ') : 'Financial Partner';

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-10rem)] py-12 text-center">
      <Card className="w-full max-w-lg shadow-xl">
        <CardHeader>
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-green-100 mb-4">
            <CheckCircle className="h-10 w-10 text-green-600" />
          </div>
          <CardTitle className="text-3xl font-headline">Application Submitted!</CardTitle>
          <CardDescription className="text-lg text-muted-foreground">
            Your loan application to <span className="font-semibold text-primary">{bankName}</span> has been received.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <div className="flex items-start text-left p-4 bg-muted/50 rounded-lg">
                <Clock className="h-8 w-8 text-primary mr-4 mt-1 flex-shrink-0" />
                <div>
                    <h4 className="font-semibold">What happens next?</h4>
                    <ul className="list-disc pl-5 text-sm text-muted-foreground mt-2 space-y-1">
                        <li>You will receive an email confirmation shortly.</li>
                        <li>Your application will be reviewed within 5-7 business days.</li>
                        <li>The financial partner may contact you for additional information.</li>
                        <li>You can check the status of your application from your profile.</li>
                    </ul>
                </div>
            </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-6">
            <Button size="lg" asChild>
              <Link href="/retailer/profile">Back to My Profile</Link>
            </Button>
            <Button variant="outline" size="lg" asChild>
              <Link href="/retailer">
                Continue Shopping
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
