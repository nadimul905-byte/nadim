
"use client";

import React, { useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { 
    ArrowLeft, Send, Loader2, DollarSign, 
    FileText, Briefcase, User, Building, 
    ShieldCheck, UploadCloud, ChevronRight,
    Scale, Landmark, Calculator
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function RetailerMicrofinanceApplicationPage() {
  const router = useRouter();
  const params = useParams();
  const bankId = params.bankId as string;
  const { toast } = useToast();

  // Application State
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const bankName = bankId ? bankId.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ') : 'Financial Partner';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Mock API call for loan application
    await new Promise(resolve => setTimeout(resolve, 2000));
    toast({ title: "Manifest Committed", description: `Your application to ${bankName} is being analyzed.` });
    setIsSubmitting(false);
    router.push(`/retailer/profile/microfinance/${bankId}/confirmation`);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-xs mx-auto px-1 pb-24 animate-in fade-in duration-500">
      <div className="flex items-center gap-4">
        <Button type="button" variant="outline" size="icon" onClick={() => router.back()} className="rounded-full h-10 w-10 border-zinc-200 shadow-sm">
          <ArrowLeft className="h-5 w-5 text-zinc-600" />
        </Button>
        <div>
            <h1 className="text-xl font-headline font-black tracking-tight leading-tight">Capital Manifest</h1>
            <p className="text-[10px] text-muted-foreground uppercase font-black tracking-[0.2em]">Application OS v4.1</p>
        </div>
      </div>

       <Card className="rounded-[2rem] border-none bg-primary/5 shadow-none overflow-hidden ring-1 ring-primary/10">
        <CardHeader className="p-6 pb-2">
            <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                    <ShieldCheck className="h-4 w-4 text-primary" />
                    <span className="text-[10px] font-black uppercase tracking-widest text-primary/80">Operational Trust</span>
                </div>
                <Badge className="bg-primary/10 text-primary border-none text-[9px] font-bold">VERIFIED</Badge>
            </div>
            <CardDescription className="text-[11px] font-medium text-primary/70 leading-relaxed italic">
                "Your performance data on Ladook serves as technical collateral for expedited processing."
            </CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-2 gap-3 p-6 pt-2 text-center">
            <div className="p-3 bg-background/50 backdrop-blur-sm rounded-2xl border border-primary/10 shadow-sm">
                <p className="text-xl font-black text-primary">4.8 ★</p>
                <p className="text-[8px] font-black uppercase text-muted-foreground mt-0.5">Rating</p>
            </div>
            <div className="p-3 bg-background/50 backdrop-blur-sm rounded-2xl border border-primary/10 shadow-sm">
                <p className="text-xl font-black text-primary">99%</p>
                <p className="text-[8px] font-black uppercase text-muted-foreground mt-0.5">Payments</p>
            </div>
        </CardContent>
    </Card>

      <Card className="rounded-3xl border shadow-md overflow-hidden bg-card">
        <CardHeader className="p-6 border-b bg-muted/20">
            <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-2xl bg-zinc-100 flex items-center justify-center">
                    <Calculator className="h-5 w-5 text-zinc-600" />
                </div>
                <span className="text-[10px] font-black uppercase tracking-widest text-zinc-800">Capital Specifications</span>
            </div>
        </CardHeader>
        <CardContent className="space-y-4 p-6">
          <div className="space-y-1.5">
            <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Requested Capital (USD)</Label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-primary" />
              <Input type="number" placeholder="0.00" required className="pl-10 rounded-xl h-11 border-zinc-200 bg-background font-bold text-sm" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Amortization Term</Label>
            <Select required>
              <SelectTrigger className="rounded-xl h-11 border-zinc-200 bg-background font-bold text-xs"><SelectValue placeholder="Select period" /></SelectTrigger>
              <SelectContent className="rounded-2xl">
                <SelectItem value="6" className="text-xs font-bold">6 Months</SelectItem>
                <SelectItem value="12" className="text-xs font-bold">12 Months</SelectItem>
                <SelectItem value="24" className="text-xs font-bold">24 Months</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Operational Purpose</Label>
            <Textarea placeholder="How will this capital be deployed?" rows={3} required className="rounded-xl text-xs border-zinc-200 bg-background font-medium resize-none" />
          </div>
        </CardContent>
      </Card>
      
      <Card className="rounded-3xl border shadow-md overflow-hidden bg-card">
        <CardHeader className="p-6 border-b bg-muted/20">
            <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-2xl bg-zinc-100 flex items-center justify-center">
                    <Building className="h-5 w-5 text-zinc-600" />
                </div>
                <span className="text-[10px] font-black uppercase tracking-widest text-zinc-800">Corporate Entity Profile</span>
            </div>
        </CardHeader>
        <CardContent className="space-y-4 p-6">
            <div className="space-y-1.5">
              <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Legal Business Name</Label>
              <Input placeholder="e.g., Elegance Retail Ltd" required className="rounded-xl h-11 border-zinc-200 bg-background font-bold text-sm" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Entity Structure</Label>
              <Select required>
                <SelectTrigger className="rounded-xl h-11 border-zinc-200 bg-background font-bold text-xs"><SelectValue placeholder="Select type" /></SelectTrigger>
                <SelectContent className="rounded-2xl">
                  <SelectItem value="sole" className="text-xs font-bold">Sole Proprietorship</SelectItem>
                  <SelectItem value="llc" className="text-xs font-bold">LLC</SelectItem>
                  <SelectItem value="corp" className="text-xs font-bold">Corporation</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                    <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Years Active</Label>
                    <Input type="number" required className="rounded-xl h-11 border-zinc-200 bg-background font-bold text-sm" />
                </div>
                <div className="space-y-1.5">
                    <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Annual Rev.</Label>
                    <Input type="number" required className="rounded-xl h-11 border-zinc-200 bg-background font-bold text-sm" />
                </div>
            </div>
        </CardContent>
      </Card>

      <Card className="rounded-3xl border shadow-md overflow-hidden bg-card">
        <CardHeader className="p-6 border-b bg-muted/20">
            <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-2xl bg-zinc-100 flex items-center justify-center">
                    <FileText className="h-5 w-5 text-zinc-600" />
                </div>
                <span className="text-[10px] font-black uppercase tracking-widest text-zinc-800">Technical Documentation</span>
            </div>
        </CardHeader>
        <CardContent className="space-y-3 p-6">
            <div className="space-y-1.5">
                <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Business License / Registration</Label>
                <Label htmlFor="doc-license" className="flex flex-col items-center justify-center w-full h-24 border-2 border-dashed rounded-2xl cursor-pointer hover:bg-muted/50 transition-all border-zinc-200">
                    <UploadCloud className="h-5 w-5 text-muted-foreground mb-1" />
                    <span className="text-[9px] font-black uppercase text-muted-foreground tracking-widest">Upload PDF / Image</span>
                    <Input id="doc-license" type="file" className="hidden" />
                </Label>
            </div>
            <div className="space-y-1.5">
                <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Recent Bank Statements (3mo)</Label>
                <Label htmlFor="doc-statements" className="flex flex-col items-center justify-center w-full h-24 border-2 border-dashed rounded-2xl cursor-pointer hover:bg-muted/50 transition-all border-zinc-200">
                    <UploadCloud className="h-5 w-5 text-muted-foreground mb-1" />
                    <span className="text-[9px] font-black uppercase text-muted-foreground tracking-widest">Upload PDF / Image</span>
                    <Input id="doc-statements" type="file" className="hidden" />
                </Label>
            </div>
        </CardContent>
      </Card>

      <Card className="rounded-[2.5rem] bg-zinc-900 text-white border-none shadow-2xl overflow-hidden relative">
          <CardHeader className="p-8 pb-4">
            <div className="flex items-center gap-2">
                <Landmark className="h-5 w-5 text-primary" />
                <CardTitle className="text-[10px] uppercase font-black tracking-[0.3em] text-zinc-500">Authorization</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="px-8 pb-8 space-y-4">
              <p className="text-[11px] font-medium text-zinc-300 leading-relaxed italic border-l-2 border-primary/30 pl-3">
                  "By committing this application, you authorize {bankName} to pull operational data and credit insights for underwriting purposes."
              </p>
          </CardContent>
          <CardFooter className="px-8 pb-8 pt-0">
            <Button type="submit" size="lg" disabled={isSubmitting} className="w-full h-14 rounded-2xl bg-white text-black hover:bg-zinc-200 font-black uppercase text-sm shadow-xl active:scale-95 transition-all">
                {isSubmitting ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Send className="mr-2 h-5 w-5" />}
                Commit Application
            </Button>
          </CardFooter>
      </Card>
      
      <style jsx global>{`
        .no-scrollbar::-webkit-scrollbar {
            display: none;
        }
        .no-scrollbar {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
      `}</style>
    </form>
  );
}
