"use client";

import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { ArrowLeft, Landmark, Shield, ShoppingBag, Layers, Sparkles, RefreshCw, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';


// Duplicating the mock data here. In a real app, this would come from a shared service or API.
const mockSchemes = [
  {
    slug: 'inventory-purchase',
    title: "Inventory Purchase Loan",
    description: "Secure the funds you need to stock up on inventory for upcoming seasons or sales events. This loan is specifically designed to help retailers manage cash flow while ensuring their shelves are always full of the latest products.",
    features: ["Up to $25,000 in funding", "Repayment terms aligned with sales cycles", "Fast approval for existing Ladook members", "Use funds for any inventory listed on Ladook"],
    target: "Retailers",
    icon: ShoppingBag,
    link: "/retailer/profile/microfinance/schemes/inventory-purchase"
  },
  {
    slug: 'working-capital',
    title: "Working Capital Line of Credit",
    description: "A flexible line of credit to manage day-to-day operational expenses and keep your business running smoothly. Perfect for covering unexpected costs or managing seasonal cash flow gaps without needing a new loan each time.",
    features: ["Draw funds as you need them, up to your credit limit", "Pay interest only on the amount you use", "Revolving line of credit restores as you repay", "Ideal for ongoing operational needs"],
    target: "All Businesses",
    icon: RefreshCw,
    link: "/retailer/profile/microfinance/schemes/working-capital"
  },
  {
    slug: 'raw-material',
    title: "Raw Material Financing",
    description: "Purchase raw materials in bulk to reduce costs and ensure a steady supply chain for your production. This helps you fulfill larger orders without upfront capital constraints.",
    features: ["Covers fabrics, leather, buttons, zippers, etc.", "Terms up to 12 months", "Released upon supplier invoice", "Improves production efficiency"],
    target: "Vendors",
    icon: Layers,
    link: "/retailer/profile/microfinance/schemes/raw-material"
  },
  {
    slug: 'equipment-upgrade',
    title: "Equipment Upgrade Loan",
    description: "Invest in new machinery to increase your production capacity, improve quality, and reduce manufacturing times. Stay competitive with state-of-the-art equipment.",
    features: ["Financing for sewing machines, cutting tables, etc.", "Competitive fixed interest rates", "Long-term repayment options (up to 5 years)", "Helps scale your production capabilities"],
    target: "Vendors",
    icon: Sparkles,
    link: "/retailer/profile/microfinance/schemes/equipment-upgrade"
  },
];

const financialPartners = [
  {
    id: 'bank-of-style',
    name: 'Bank of Style',
    logo: 'https://picsum.photos/seed/bos_logo/80/80',
    aiHint: 'bank logo',
  },
  {
    id: 'commerce-capital',
    name: 'Commerce Capital',
    logo: 'https://picsum.photos/seed/cc_logo/80/80',
    aiHint: 'financial logo',
  },
  {
    id: 'artisan-alliance',
    name: 'Artisan Alliance',
    logo: 'https://picsum.photos/seed/aa_logo/80/80',
    aiHint: 'alliance logo',
  },
];


export default function SchemeDetailPage() {
    const router = useRouter();
    const params = useParams();
    const schemeId = params.schemeId as string;
    
    const [scheme, setScheme] = useState<(typeof mockSchemes)[0] | null>(null);

    useEffect(() => {
        const foundScheme = mockSchemes.find(s => s.slug === schemeId);
        if (foundScheme) {
            setScheme(foundScheme);
        } else {
            // Handle not found, maybe redirect
            router.push('/retailer/profile/microfinance');
        }
    }, [schemeId, router]);
    
    if (!scheme) {
        return <div className="text-center py-10">Loading scheme details...</div>;
    }

    const Icon = scheme.icon;

    return (
        <div className="space-y-6">
            <Button variant="outline" onClick={() => router.push('/retailer/profile/microfinance?tab=schemes')}>
                <ArrowLeft className="mr-2 h-4 w-4" /> Back to Schemes
            </Button>
            
            <Card>
                <CardHeader>
                    <div className="flex items-center gap-4 mb-2">
                        <Icon className="h-10 w-10 text-primary" />
                        <CardTitle className="text-3xl font-headline">{scheme.title}</CardTitle>
                    </div>
                    <CardDescription>Ideal For: {scheme.target}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <p className="text-lg text-muted-foreground">{scheme.description}</p>
                    <div>
                        <h4 className="font-semibold text-lg mb-2">Key Features</h4>
                        <ul className="space-y-2">
                            {scheme.features.map((feature, index) => (
                                <li key={index} className="flex items-start">
                                    <Shield className="h-5 w-5 text-green-500 mr-3 mt-1 flex-shrink-0" />
                                    <span>{feature}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Landmark className="h-6 w-6 text-primary"/>
                        Apply with our Partners
                    </CardTitle>
                    <CardDescription>Choose a financial partner to start your application for the "{scheme.title}".</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    {financialPartners.map(partner => (
                        <div key={partner.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors gap-4">
                            <div className="flex items-center gap-4">
                                <Avatar className="h-12 w-12 border">
                                    <AvatarImage src={partner.logo} alt={partner.name} data-ai-hint={partner.aiHint} />
                                    <AvatarFallback>{partner.name.charAt(0)}</AvatarFallback>
                                </Avatar>
                                <p className="font-semibold">{partner.name}</p>
                            </div>
                            <Button asChild className="w-full sm:w-auto">
                                <Link href={`/retailer/profile/microfinance/${partner.id}`}>
                                    Apply Now <ArrowRight className="ml-2 h-4 w-4" />
                                </Link>
                            </Button>
                        </div>
                    ))}
                     <div className="text-center pt-2">
                        <Button variant="link" asChild>
                            <Link href="/retailer/profile/microfinance?tab=banks">View All Partners</Link>
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}