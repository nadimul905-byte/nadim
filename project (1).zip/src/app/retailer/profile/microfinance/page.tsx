"use client";

import React from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { ArrowLeft, Landmark, Shield, ShoppingBag, Layers, Sparkles, RefreshCw, Info, ChevronRight, ShieldCheck, TrendingUp } from 'lucide-react';
import Link from 'next/link';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const financialPartners = [
  {
    id: 'bank-of-style',
    name: 'Bank of Style',
    logo: 'https://picsum.photos/seed/bos_logo/80/80',
    aiHint: 'bank logo',
    description: 'Specializing in providing capital for fashion startups and small boutiques.',
    features: ['Loans up to $50,000', 'Flexible repayment terms', 'Quick approval process'],
  },
  {
    id: 'commerce-capital',
    name: 'Commerce Capital',
    logo: 'https://picsum.photos/seed/cc_logo/80/80',
    aiHint: 'financial logo',
    description: 'Empowering retailers with financial tools and inventory financing solutions.',
    features: ['Inventory financing', 'Lines of credit available', 'Business mentorship program'],
  },
  {
    id: 'artisan-alliance',
    name: 'Artisan Alliance',
    logo: 'https://picsum.photos/seed/aa_logo/80/80',
    aiHint: 'alliance logo',
    description: 'A non-profit focused on providing micro-loans to independent creators and artisans.',
    features: ['Micro-loans from $500', 'Community support', 'Focus on handmade goods'],
  },
];

const mockSchemes = [
  {
    slug: 'inventory-purchase',
    title: "Inventory Purchase Loan",
    description: "Secure the funds you need to stock up on inventory for upcoming seasons or sales events.",
    features: ["Up to $25,000", "Repayment tied to sales cycles"],
    target: "Retailers",
    icon: ShoppingBag,
    link: "/retailer/profile/microfinance/schemes/inventory-purchase"
  },
  {
    slug: 'working-capital',
    title: "Working Capital Line of Credit",
    description: "A flexible line of credit to manage day-to-day operational expenses and cash flow.",
    features: ["Draw funds as you need them", "Interest only on usage"],
    target: "All Businesses",
    icon: RefreshCw,
    link: "/retailer/profile/microfinance/schemes/working-capital"
  },
];

const PartnerCard = ({ partner }: { partner: typeof financialPartners[0] }) => (
    <Card key={partner.id} className="rounded-3xl border shadow-sm overflow-hidden flex flex-col bg-card transition-all hover:border-primary/20">
        <CardHeader className="p-5 pb-4 bg-muted/10 border-b border-dashed">
            <div className="flex items-center gap-4">
                <Avatar className="h-12 w-12 border-2 border-background shadow-md">
                    <AvatarImage src={partner.logo} alt={partner.name} data-ai-hint={partner.aiHint} />
                    <AvatarFallback>{partner.name[0]}</AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                    <p className="text-[8px] font-black uppercase text-primary tracking-[0.2em]">Verified Provider</p>
                    <CardTitle className="text-sm font-black uppercase tracking-tight">{partner.name}</CardTitle>
                </div>
            </div>
        </CardHeader>
        <CardContent className="p-5 pt-4 space-y-4 flex-grow">
            <p className="text-[11px] font-medium text-muted-foreground leading-relaxed italic">"{partner.description}"</p>
            <div className="space-y-1.5">
                {partner.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2">
                        <Shield className="h-3 w-3 text-green-500 shrink-0" />
                        <span className="text-[9px] font-black uppercase text-zinc-700 tracking-tighter truncate">{feature}</span>
                    </div>
                ))}
            </div>
        </CardContent>
        <CardFooter className="p-3 border-t bg-muted/5 grid grid-cols-2 gap-2">
            <Button variant="outline" size="sm" asChild className="h-9 rounded-xl text-[9px] font-black uppercase border-primary/10 text-primary">
                <Link href={`/retailer/profile/microfinance/partners/${partner.id}`}>Details</Link>
            </Button>
            <Button size="sm" asChild className="h-9 rounded-xl text-[9px] font-black uppercase bg-zinc-900 hover:bg-zinc-800 text-white">
                <Link href={`/retailer/profile/microfinance/${partner.id}`}>Apply Now</Link>
            </Button>
        </CardFooter>
    </Card>
);

const SchemeCard = ({ scheme }: { scheme: typeof mockSchemes[0] }) => {
    const Icon = scheme.icon;
    return (
        <Card className="rounded-3xl border shadow-sm overflow-hidden flex flex-col hover:border-primary/20 transition-all bg-card">
            <CardHeader className="p-5 pb-2">
                <div className="flex items-center gap-3">
                    <div className="h-9 w-9 rounded-2xl bg-zinc-100 flex items-center justify-center">
                        <Icon className="h-4 w-4 text-zinc-600" />
                    </div>
                    <div>
                        <CardTitle className="text-xs font-black uppercase tracking-tight">{scheme.title}</CardTitle>
                        <p className="text-[8px] font-black uppercase text-muted-foreground tracking-widest">Eligibility: {scheme.target}</p>
                    </div>
                </div>
            </CardHeader>
            <CardContent className="px-5 pb-5 pt-2">
                 <p className="text-[11px] font-medium text-muted-foreground leading-relaxed">{scheme.description}</p>
            </CardContent>
             <CardFooter className="px-5 pb-5 pt-0">
              <Button asChild className="w-full rounded-xl h-10 text-[9px] font-black uppercase tracking-widest" variant="outline">
                <Link href={scheme.link}>Analyze Structure <ChevronRight className="ml-1 h-3 w-3"/></Link>
              </Button>
            </CardFooter>
        </Card>
    )
};

export default function RetailerMicrofinancePartnerSelectionPage() {
  const router = useRouter();

  return (
    <div className="space-y-6 max-w-xs mx-auto px-1 pb-20 animate-in fade-in duration-500">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => router.back()} className="rounded-full h-10 w-10 border-zinc-200 shadow-sm">
          <ArrowLeft className="h-5 w-5 text-zinc-600" />
        </Button>
        <div>
            <h1 className="text-xl font-headline font-black tracking-tight leading-tight">Financial Center</h1>
            <p className="text-[10px] text-muted-foreground uppercase font-black tracking-[0.2em]">Capital OS v4.1</p>
        </div>
      </div>

       <Card className="rounded-[2rem] border-none bg-primary/5 shadow-none overflow-hidden ring-1 ring-primary/10">
        <CardHeader className="p-6 pb-2">
            <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                    <ShieldCheck className="h-4 w-4 text-primary" />
                    <span className="text-[10px] font-black uppercase tracking-widest text-primary/80">Trust Score</span>
                </div>
                <Badge className="bg-primary/10 text-primary border-none text-[9px] font-bold">PLATINUM</Badge>
            </div>
            <CardDescription className="text-[11px] font-medium text-primary/70 leading-relaxed italic">
                "Your performance on Ladook unlocks prioritized capital access."
            </CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-2 gap-3 p-6 pt-2 text-center">
            <div className="p-3 bg-background/50 backdrop-blur-sm rounded-2xl border border-primary/10">
                <p className="text-xl font-black text-primary">4.8 ★</p>
                <p className="text-[8px] font-black uppercase text-muted-foreground mt-0.5">Rating</p>
            </div>
            <div className="p-3 bg-background/50 backdrop-blur-sm rounded-2xl border border-primary/10">
                <p className="text-xl font-black text-primary">99%</p>
                <p className="text-[8px] font-black uppercase text-muted-foreground mt-0.5">Repayment</p>
            </div>
        </CardContent>
      </Card>
      
      <Tabs defaultValue="banks" className="w-full">
          <TabsList className="grid w-full grid-cols-2 h-11 items-center justify-center rounded-2xl bg-muted/30 p-1 border mb-6">
              <TabsTrigger value="banks" className="rounded-xl text-[9px] font-black uppercase tracking-widest h-full data-[state=active]:bg-background transition-all">Providers</TabsTrigger>
              <TabsTrigger value="schemes" className="rounded-xl text-[9px] font-black uppercase tracking-widest h-full data-[state=active]:bg-background transition-all">Schemes</TabsTrigger>
          </TabsList>

          <TabsContent value="banks" className="space-y-5 outline-none">
            <div className="flex items-center justify-between px-1">
                <h2 className="text-[9px] font-black uppercase tracking-[0.3em] text-muted-foreground">Certified Providers</h2>
            </div>
            {financialPartners.map((partner) => (
                <PartnerCard key={partner.id} partner={partner} />
            ))}
          </TabsContent>

          <TabsContent value="schemes" className="space-y-5 outline-none">
            <div className="flex items-center justify-between px-1">
                <h2 className="text-[9px] font-black uppercase tracking-[0.3em] text-muted-foreground">Capital Structures</h2>
            </div>
            {mockSchemes.map((scheme) => (
                <SchemeCard key={scheme.slug} scheme={scheme} />
            ))}
          </TabsContent>
      </Tabs>
    </div>
  );
}
