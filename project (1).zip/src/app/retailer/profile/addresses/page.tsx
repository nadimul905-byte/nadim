
"use client";

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, PlusCircle, Edit3, Trash2, Home, Briefcase, Check, Star, Loader2 } from 'lucide-react';
import { useRouter } from 'next/navigation';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";

interface Address {
  id: string;
  label: string;
  fullName: string;
  phone: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  zip: string;
  country: string;
  isDefault?: boolean;
}

const RETAILER_ADDRESS_BOOK_STORAGE_KEY = 'ladookRetailerAddressBook';

const initialAddresses: Address[] = [
  { id: 'addr1', label: 'Home', fullName: 'Jane Doe', phone: '555-123-4567', addressLine1: '123 Main St', city: 'Retailville', state: 'CA', zip: '90210', country: 'USA', isDefault: true },
  { id: 'addr2', label: 'Work', fullName: 'Jane Doe', phone: '555-987-6543', addressLine1: '456 Commerce Ave', city: 'Retailville', state: 'CA', zip: '90211', country: 'USA', isDefault: false },
];

const AddressForm = ({ address, onSave, onCancel }: { address?: Address | null, onSave: (address: Address) => void, onCancel: () => void }) => {
  const [formData, setFormData] = useState<Omit<Address, 'id'>>({
    label: address?.label || '',
    fullName: address?.fullName || '',
    phone: address?.phone || '',
    addressLine1: address?.addressLine1 || '',
    addressLine2: address?.addressLine2 || '',
    city: address?.city || '',
    state: address?.state || '',
    zip: address?.zip || '',
    country: address?.country || 'USA',
    isDefault: address?.isDefault || false,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
        const { checked } = e.target as HTMLInputElement;
        setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
        setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.label || !formData.fullName || !formData.addressLine1 || !formData.city || !formData.state || !formData.zip || !formData.country) {
        // Basic validation, can be expanded
        alert("Please fill all required fields for the address.");
        return;
    }
    onSave({ ...formData, id: address?.id || `addr-${Date.now()}` });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div><Label htmlFor="label">Label (e.g., Home, Office)</Label><Input id="label" name="label" value={formData.label} onChange={handleChange} required /></div>
      <div><Label htmlFor="fullName">Full Name</Label><Input id="fullName" name="fullName" value={formData.fullName} onChange={handleChange} required /></div>
      <div><Label htmlFor="phone">Phone</Label><Input id="phone" name="phone" type="tel" value={formData.phone} onChange={handleChange} /></div>
      <div><Label htmlFor="addressLine1">Address Line 1</Label><Input id="addressLine1" name="addressLine1" value={formData.addressLine1} onChange={handleChange} required /></div>
      <div><Label htmlFor="addressLine2">Address Line 2 (Optional)</Label><Input id="addressLine2" name="addressLine2" value={formData.addressLine2} onChange={handleChange} /></div>
      <div className="grid grid-cols-2 gap-4">
        <div><Label htmlFor="city">City</Label><Input id="city" name="city" value={formData.city} onChange={handleChange} required /></div>
        <div><Label htmlFor="state">State/Province</Label><Input id="state" name="state" value={formData.state} onChange={handleChange} required /></div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div><Label htmlFor="zip">ZIP/Postal Code</Label><Input id="zip" name="zip" value={formData.zip} onChange={handleChange} required /></div>
        <div><Label htmlFor="country">Country</Label><Input id="country" name="country" value={formData.country} onChange={handleChange} required /></div>
      </div>
      <div className="flex items-center space-x-2">
        <Checkbox id="isDefault" name="isDefault" checked={formData.isDefault} onCheckedChange={(checked) => setFormData(prev => ({...prev, isDefault: Boolean(checked)}))}/>
        <Label htmlFor="isDefault">Set as default shipping address</Label>
      </div>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
        <Button type="submit">{address ? 'Save Changes' : 'Add Address'}</Button>
      </DialogFooter>
    </form>
  );
};

export default function RetailerAddressBookPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingAddress, setEditingAddress] = useState<Address | null>(null);
  const [addressToDelete, setAddressToDelete] = useState<Address | null>(null);
  const [selectedAddressId, setSelectedAddressId] = useState<string | null>(null);

  useEffect(() => {
    const storedAddresses = localStorage.getItem(RETAILER_ADDRESS_BOOK_STORAGE_KEY);
    if (storedAddresses) {
      setAddresses(JSON.parse(storedAddresses));
    } else {
      localStorage.setItem(RETAILER_ADDRESS_BOOK_STORAGE_KEY, JSON.stringify(initialAddresses));
      setAddresses(initialAddresses);
    }
  }, []);

  const saveAddressesToStorage = (updatedAddresses: Address[]) => {
    localStorage.setItem(RETAILER_ADDRESS_BOOK_STORAGE_KEY, JSON.stringify(updatedAddresses));
    setAddresses(updatedAddresses);
  };

  const handleSaveAddress = (address: Address) => {
    let updatedAddresses;
    if (editingAddress) {
      updatedAddresses = addresses.map(a => (a.id === address.id ? address : a));
    } else {
      updatedAddresses = [...addresses, address];
    }

    if (address.isDefault) {
      updatedAddresses = updatedAddresses.map(a => ({ ...a, isDefault: a.id === address.id }));
    }
    
    saveAddressesToStorage(updatedAddresses);
    toast({ title: editingAddress ? "Address Updated" : "Address Added", description: `Address "${address.label}" has been saved.` });
    setIsFormOpen(false);
    setEditingAddress(null);
  };
  
  const handleSetDefault = (addressId: string) => {
    const updatedAddresses = addresses.map(addr => ({
      ...addr,
      isDefault: addr.id === addressId
    }));
    saveAddressesToStorage(updatedAddresses);
    toast({ title: "Default Address Set", description: "Your default shipping address has been updated." });
  };

  const openEditForm = (address: Address) => {
    setEditingAddress(address);
    setIsFormOpen(true);
  };

  const openAddForm = () => {
    setEditingAddress(null);
    setIsFormOpen(true);
  };

  const handleDeleteAddress = () => {
    if (!addressToDelete) return;
    const updatedAddresses = addresses.filter(a => a.id !== addressToDelete.id);
    saveAddressesToStorage(updatedAddresses);
    toast({ title: "Address Deleted", description: `Address "${addressToDelete.label}" has been removed.`, variant: "destructive" });
    setAddressToDelete(null);
    if (selectedAddressId === addressToDelete.id) {
      setSelectedAddressId(null); // Clear selection if deleted address was selected
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={() => router.back()}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Profile
        </Button>
        <Dialog open={isFormOpen} onOpenChange={(open) => { setIsFormOpen(open); if (!open) setEditingAddress(null); }}>
          <DialogTrigger asChild>
            <Button onClick={openAddForm}>
              <PlusCircle className="mr-2 h-4 w-4" /> Add New Address
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>{editingAddress ? 'Edit Address' : 'Add New Address'}</DialogTitle>
              <DialogDescription>
                {editingAddress ? 'Update the details of your address.' : 'Enter the details for your new shipping address.'}
              </DialogDescription>
            </DialogHeader>
            <AddressForm 
                address={editingAddress} 
                onSave={handleSaveAddress} 
                onCancel={() => { setIsFormOpen(false); setEditingAddress(null); }} 
            />
          </DialogContent>
        </Dialog>
      </div>

      <h1 className="text-3xl font-headline font-semibold">Address Book</h1>

      {addresses.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Home className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold">No Addresses Saved</h3>
            <p className="text-muted-foreground">Add your shipping addresses for faster checkout.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {addresses.map(addr => (
            <Card 
              key={addr.id} 
              className={cn(
                'flex flex-col cursor-pointer transition-all hover:shadow-xl',
                addr.isDefault && 'border-primary border-2',
                selectedAddressId === addr.id && 'ring-2 ring-offset-background ring-accent'
              )}
              onClick={() => setSelectedAddressId(addr.id)}
            >
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="flex items-center text-lg">
                    {addr.label === 'Home' ? <Home className="mr-2 h-5 w-5 text-primary" /> : <Briefcase className="mr-2 h-5 w-5 text-primary" />}
                    {addr.label}
                    {addr.isDefault && <Star className="ml-2 h-4 w-4 fill-yellow-400 text-yellow-400" />}
                  </CardTitle>
                  {!addr.isDefault && (
                     <Button variant="outline" size="sm" onClick={(e) => { e.stopPropagation(); handleSetDefault(addr.id); }}>Set as Default</Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground flex-grow">
                <p className="font-medium text-foreground">{addr.fullName}</p>
                <p>{addr.phone}</p>
                <p>{addr.addressLine1}</p>
                {addr.addressLine2 && <p>{addr.addressLine2}</p>}
                <p>{addr.city}, {addr.state} {addr.zip}</p>
                <p>{addr.country}</p>
              </CardContent>
              <CardFooter className="border-t p-3 flex justify-end gap-2">
                <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); openEditForm(addr); }}>
                  <Edit3 className="h-4 w-4" />
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); setAddressToDelete(addr); }} className="text-destructive hover:text-destructive hover:bg-destructive/10">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent onClick={(e) => e.stopPropagation()}>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This action cannot be undone. This will permanently delete the address labeled "{addressToDelete?.label}".
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel onClick={() => setAddressToDelete(null)}>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleDeleteAddress} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">Delete</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

