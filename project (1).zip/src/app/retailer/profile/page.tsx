
"use client";
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { User, Mail, Phone, MapPin, CreditCard, History, Heart, Settings, HelpCircle, LogOut, Edit3, Bell, Moon, Sun, Landmark, Wallet, ArrowRight, ShieldCheck } from 'lucide-react';
import Link from 'next/link';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useThemeContext } from '@/app/providers';
import { useRouter, usePathname } from 'next/navigation'; // Import useRouter & usePathname

const RETAILER_PROFILE_STORAGE_KEY = 'ladookRetailerProfile';
const RETAILER_ADDRESS_BOOK_STORAGE_KEY = 'ladookRetailerAddressBook';
const RETAILER_PAYMENT_METHODS_STORAGE_KEY = 'ladookRetailerPaymentMethods';
const DEFAULT_AVATAR_URL = "https://picsum.photos/seed/profile/150/150";

interface Address {
  id: string;
  label: string;
  fullName: string;
  phone: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  zip: string;
  country: string;
  isDefault?: boolean;
}

interface PaymentMethod {
  id: string;
  cardType: string;
  last4: string;
  expiryDate: string;
  cardholderName: string;
  isDefault?: boolean;
}


const ProfileItem = ({ icon: Icon, label, value, action, href }: { icon: React.ElementType, label: string, value?: string | React.ReactNode, action?: React.ReactNode, href?: string }) => (
  <div className="flex items-center justify-between py-3">
    <div className="flex items-center">
      <Icon className="h-5 w-5 text-muted-foreground mr-3" />
      <div>
        <p className="text-sm font-medium">{label}</p>
        {value && typeof value === 'string' ? <p className="text-xs text-muted-foreground">{value}</p> : value}
      </div>
    </div>
    {action && !href && action}
    {href && <Button variant="ghost" size="sm" asChild><Link href={href}><Edit3 className="h-4 w-4"/></Link></Button>}
  </div>
);


export default function RetailerProfilePage() {
  const router = useRouter(); 
  const pathname = usePathname(); // Get current pathname
  const { theme, toggleTheme } = useThemeContext();

  const [userName, setUserName] = useState("Jane Doe"); 
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [avatarSrc, setAvatarSrc] = useState(DEFAULT_AVATAR_URL);
  const [addressCount, setAddressCount] = useState(0);
  const [paymentMethodCount, setPaymentMethodCount] = useState(0);
  
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const storedProfileData = localStorage.getItem(RETAILER_PROFILE_STORAGE_KEY);
      const storedEmailFromMainKey = localStorage.getItem('userEmail'); // Primary source for email
      
      let currentUserName = "Jane Doe";
      let currentAvatarSrc = DEFAULT_AVATAR_URL;
      let currentEmail = storedEmailFromMainKey || "loading...";

      if (storedProfileData) {
        try {
          const parsedData = JSON.parse(storedProfileData);
          currentUserName = parsedData.fullName || "Jane Doe";
          currentAvatarSrc = parsedData.avatarPreview || DEFAULT_AVATAR_URL;
          // If userEmail from dedicated key was null/empty, AND profile has an email, use profile's email as fallback.
          if (!storedEmailFromMainKey && parsedData.email) {
            currentEmail = parsedData.email;
          }
        } catch (error) {
          console.error("Failed to parse retailer profile from localStorage", error);
          // currentEmail is already set from storedEmailFromMainKey or "loading..."
        }
      } else {
        // No stored profile, currentEmail already set, defaults for others are fine.
      }
      
      setUserName(currentUserName);
      setUserEmail(currentEmail);
      setAvatarSrc(currentAvatarSrc);

      const storedAddresses = localStorage.getItem(RETAILER_ADDRESS_BOOK_STORAGE_KEY);
      if (storedAddresses) {
        try {
          const parsedAddresses: Address[] = JSON.parse(storedAddresses);
          setAddressCount(parsedAddresses.length);
        } catch (error) {
          console.error("Failed to parse addresses from localStorage", error);
          setAddressCount(0);
        }
      } else {
        const initialAddresses: Address[] = [
            { id: 'addr1', label: 'Home', fullName: 'Jane Doe', phone: '555-123-4567', addressLine1: '123 Main St', city: 'Retailville', state: 'CA', zip: '90210', country: 'USA', isDefault: true },
        ];
        localStorage.setItem(RETAILER_ADDRESS_BOOK_STORAGE_KEY, JSON.stringify(initialAddresses));
        setAddressCount(initialAddresses.length);
      }

      const storedPaymentMethods = localStorage.getItem(RETAILER_PAYMENT_METHODS_STORAGE_KEY);
      if (storedPaymentMethods) {
        try {
          const parsedPaymentMethods: PaymentMethod[] = JSON.parse(storedPaymentMethods);
          setPaymentMethodCount(parsedPaymentMethods.length);
        } catch (error) {
          console.error("Failed to parse payment methods from localStorage", error);
          setPaymentMethodCount(0);
        }
      } else {
         const initialPaymentMethods: PaymentMethod[] = [
            { id: 'pm1', cardType: 'Visa', last4: '1234', expiryDate: '12/25', cardholderName: 'Jane Doe', isDefault: true },
        ];
        localStorage.setItem(RETAILER_PAYMENT_METHODS_STORAGE_KEY, JSON.stringify(initialPaymentMethods));
        setPaymentMethodCount(initialPaymentMethods.length);
      }
    }
  }, [pathname]); // Add pathname as a dependency

  const handleLogout = () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('isAuthenticated');
      localStorage.removeItem('selectedRole');
      localStorage.removeItem('userEmail');
      localStorage.removeItem(RETAILER_PROFILE_STORAGE_KEY);
      localStorage.removeItem(RETAILER_ADDRESS_BOOK_STORAGE_KEY);
      localStorage.removeItem(RETAILER_PAYMENT_METHODS_STORAGE_KEY);
    }
    router.push('/auth'); 
  };

  return (
    <div className="space-y-6">
      <Card className="overflow-hidden">
        <CardHeader className="bg-muted/30 p-6 flex flex-col items-center text-center">
           <Avatar className="w-24 h-24 mb-3 border-4 border-background shadow-md">
            <AvatarImage src={avatarSrc} alt={userName} data-ai-hint="person fashion" />
            <AvatarFallback>{userName?.charAt(0)?.toUpperCase() || 'R'}</AvatarFallback>
          </Avatar>
          <CardTitle className="text-2xl font-headline">{userName}</CardTitle>
          <CardDescription>{userEmail || 'loading...'}</CardDescription>
          <Button variant="outline" size="sm" className="mt-2" asChild>
            <Link href="/retailer/profile/edit">
              <Edit3 className="mr-2 h-4 w-4"/>Edit Profile
            </Link>
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y">
            <ProfileItem icon={MapPin} label="Address Book" value={`${addressCount} saved address${addressCount !== 1 ? 'es' : ''}`} href="/retailer/profile/addresses" />
            <ProfileItem icon={CreditCard} label="Payment Methods" value={`${paymentMethodCount} saved card${paymentMethodCount !== 1 ? 's' : ''}`} href="/retailer/profile/payment-methods" />
            <ProfileItem icon={History} label="Purchase History" href="/retailer/orders" />
            <ProfileItem icon={Heart} label="Wishlist" href="/retailer/wishlist" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="flex items-center gap-2"><Wallet/> Ladook Wallet</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="p-4 bg-secondary/50 rounded-lg flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground">Current Balance</p>
              <p className="text-2xl font-bold text-primary">$724.50</p>
            </div>
            <Button asChild>
              <Link href="/retailer/profile/wallet">Manage <ArrowRight className="ml-2 h-4 w-4"/></Link>
            </Button>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader><CardTitle>Financial Services</CardTitle></CardHeader>
        <CardContent className="p-0">
            <ProfileItem icon={Landmark} label="Microfinance & Loans" value="Apply for a business loan" href="/retailer/profile/microfinance" />
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Settings</CardTitle></CardHeader>
        <CardContent className="divide-y">
          <ProfileItem 
            icon={Bell} 
            label="Notifications" 
            action={
                <div className="flex items-center space-x-2">
                    <Switch id="notifications-toggle" defaultChecked/>
                </div>
            }
          />
          <ProfileItem 
            icon={theme === 'dark' ? Moon : Sun} 
            label="Theme"
            action={
                <div className="flex items-center space-x-2">
                    <Switch id="theme-toggle-profile" checked={theme === 'dark'} onCheckedChange={toggleTheme}/>
                    <Label htmlFor="theme-toggle-profile" className="text-xs">{theme === 'dark' ? 'Dark Mode' : 'Light Mode'}</Label>
                </div>
            }
          />
           <ProfileItem icon={Settings} label="Language & Currency" value="English (US), USD" action={<Button variant="ghost" size="sm"><Edit3 className="h-4 w-4"/></Button>} />
            <ProfileItem icon={ShieldCheck} label="Account Security" value="Password, PIN, 2FA" href="/retailer/profile/wallet/security" />
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Help & Support</CardTitle></CardHeader>
        <CardContent className="p-0 divide-y">
            <ProfileItem icon={HelpCircle} label="FAQs" href="/retailer/help/faq" />
            <ProfileItem icon={Mail} label="Contact Support" href="/retailer/help/contact" />
        </CardContent>
      </Card>
      
      <Button variant="destructive" className="w-full" onClick={handleLogout}>
        <LogOut className="mr-2 h-4 w-4" /> Logout
      </Button>
    </div>
  );
}
    
