
"use client";

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Save, UploadCloud, Mail, Phone, Building, Briefcase, Loader2, User } from 'lucide-react';
import Image from 'next/image';

const RETAILER_PROFILE_STORAGE_KEY = 'ladookRetailerProfile';
const DEFAULT_AVATAR_URL = "https://picsum.photos/seed/profile/150/150";

export default function RetailerEditProfilePage() {
  const router = useRouter();
  const { toast } = useToast();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [storeAddress, setStoreAddress] = useState('');
  const [avatarImage, setAvatarImage] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(DEFAULT_AVATAR_URL);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const storedProfileData = localStorage.getItem(RETAILER_PROFILE_STORAGE_KEY);
      const storedUserEmail = localStorage.getItem('userEmail');

      if (storedProfileData) {
        try {
          const parsedData = JSON.parse(storedProfileData);
          setFullName(parsedData.fullName || 'Jane Doe');
          // Prioritize storedUserEmail for initial display, but profile data can override if storedUserEmail is null
          setEmail(storedUserEmail || parsedData.email || '');
          setPhone(parsedData.phone || '');
          setCompanyName(parsedData.companyName || '');
          setStoreAddress(parsedData.storeAddress || '');
          setAvatarPreview(parsedData.avatarPreview || DEFAULT_AVATAR_URL);
        } catch (error) {
          console.error("Failed to parse retailer profile from localStorage", error);
          // Fallback if parsing fails, still try to use global userEmail
          setEmail(storedUserEmail || '');
        }
      } else {
        // No stored profile, initialize email from global userEmail if available
        setEmail(storedUserEmail || '');
        setFullName('Jane Doe'); // Default name if no profile
      }
    }
  }, []);

  const handleAvatarChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      setAvatarImage(file);
      if (avatarPreview && avatarPreview.startsWith("blob:")) {
        URL.revokeObjectURL(avatarPreview);
      }
      setAvatarPreview(URL.createObjectURL(file));
    }
  };
  
  useEffect(() => {
    // Cleanup object URLs for avatar preview on component unmount or when preview changes
    return () => {
      if (avatarPreview && avatarPreview.startsWith("blob:")) {
        URL.revokeObjectURL(avatarPreview);
      }
    };
  }, [avatarPreview]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    if (!fullName || !email) {
      toast({ title: "Missing Information", description: "Full Name and Email are required.", variant: "destructive" });
      setIsSubmitting(false);
      return;
    }
    
    // Here, you would typically send data to your backend.
    // For mock purposes, we'll save to localStorage.
    // If an avatarImage is set, it means a new image was uploaded.
    // In a real app, you'd upload this file and get back a URL to save.
    // For this mock, we're just saving the preview URL (which might be a blob or the default).
    const profileDataToSave = {
      fullName,
      email,
      phone,
      companyName,
      storeAddress,
      avatarPreview: avatarPreview || DEFAULT_AVATAR_URL, 
    };

    console.log("Updating retailer profile:", profileDataToSave);
    
    if (typeof window !== 'undefined') {
        localStorage.setItem(RETAILER_PROFILE_STORAGE_KEY, JSON.stringify(profileDataToSave));
        // Also update the general userEmail in localStorage if it has changed, as TopBar uses it.
        if (localStorage.getItem('userEmail') !== email) {
            localStorage.setItem('userEmail', email);
        }
    }
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000)); 
    toast({ title: "Profile Updated!", description: "Your profile has been successfully updated." });
    setIsSubmitting(false);
    router.push('/retailer/profile'); 
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="flex items-center gap-4">
        <Button type="button" variant="outline" size="icon" onClick={() => router.push('/retailer/profile')} aria-label="Back to Profile">
            <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-3xl font-headline font-semibold">Edit My Profile</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader><CardTitle>Personal Information</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="fullName">Full Name</Label>
                 <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input id="fullName" value={fullName} onChange={(e) => setFullName(e.target.value)} required className="pl-10"/>
                </div>
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="pl-10"/>
                </div>
              </div>
              <div>
                <Label htmlFor="phone">Phone</Label>
                <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input id="phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} className="pl-10"/>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Business/Store Information</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="companyName">Company Name (Optional)</Label>
                 <div className="relative">
                    <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input id="companyName" value={companyName} onChange={(e) => setCompanyName(e.target.value)} className="pl-10"/>
                </div>
              </div>
              <div>
                <Label htmlFor="storeAddress">Store Address</Label>
                <div className="relative">
                    <Building className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input id="storeAddress" value={storeAddress} onChange={(e) => setStoreAddress(e.target.value)} className="pl-10"/>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-1 space-y-6">
          <Card>
            <CardHeader><CardTitle>Profile Picture</CardTitle></CardHeader>
            <CardContent className="flex flex-col items-center space-y-4">
              <Avatar className="w-32 h-32 mb-3 border-4 border-background shadow-lg">
                <AvatarImage src={avatarPreview || undefined} alt={fullName} data-ai-hint="person retail" />
                <AvatarFallback className="text-4xl">{fullName?.charAt(0)?.toUpperCase() || 'R'}</AvatarFallback>
              </Avatar>
              <Label htmlFor="avatarUpload" className="cursor-pointer w-full">
                <div className="flex items-center justify-center w-full p-3 border-2 border-dashed rounded-md hover:bg-muted/50">
                  <UploadCloud className="w-6 h-6 mr-2 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Upload New Picture</span>
                </div>
                <Input id="avatarUpload" type="file" className="hidden" onChange={handleAvatarChange} accept="image/*" />
              </Label>
              {avatarPreview && avatarPreview !== DEFAULT_AVATAR_URL && (
                <Button type="button" variant="ghost" size="sm" onClick={() => { setAvatarImage(null); if (avatarPreview && avatarPreview.startsWith("blob:")) URL.revokeObjectURL(avatarPreview); setAvatarPreview(DEFAULT_AVATAR_URL); }}>
                  Remove Custom Picture
                </Button>
              )}
              <p className="text-xs text-muted-foreground text-center">Recommended: Square JPG or PNG, min 150x150px.</p>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={() => router.push('/retailer/profile')} disabled={isSubmitting}>
          Cancel
        </Button>
        <Button type="submit" disabled={isSubmitting} size="lg">
          {isSubmitting ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Save className="mr-2 h-5 w-5" />}
          Save Changes
        </Button>
      </div>
    </form>
  );
}
