"use client";
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { MinusCircle, PlusCircle, Trash2, ShoppingBag, ArrowLeft, ChevronRight, Calculator, Package } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';

export interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  aiHint: string;
  variant?: string;
}

const initialCartItems: CartItem[] = [
  { id: '1', name: 'Elegant Evening Gown', price: 129.99, quantity: 5, image: 'https://images.unsplash.com/photo-1589083133356-aa13ceaef7fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw3fHxldmVuaW5nJTIwZ293bnxlbnwwfHx8fDE3NDkzMzY1NzZ8MA&ixlib=rb-4.1.0&q=80&w=1080', aiHint: "evening gown", variant: "Size: M, Color: Burgundy" },
];

export default function RetailerCartPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [cartItems, setCartItems] = useState<CartItem[]>(initialCartItems);

  const updateQuantity = (id: string, newQuantity: number) => {
    if (newQuantity < 1) newQuantity = 1;
    setCartItems(items => items.map(item => item.id === id ? { ...item, quantity: newQuantity } : item));
  };

  const removeItem = (id: string) => {
    setCartItems(items => items.filter(item => item.id !== id));
    toast({ title: "Inventory Released", description: "Item removed from your active batch." });
  };

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const total = subtotal + 15.00 + (subtotal * 0.08);

  if (cartItems.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center space-y-6 max-w-xs mx-auto">
        <div className="h-24 w-24 rounded-[2rem] bg-muted flex items-center justify-center">
            <ShoppingBag className="w-10 h-10 text-muted-foreground/50" />
        </div>
        <div className="space-y-2">
            <h2 className="text-2xl font-headline font-black">Empty Batch</h2>
            <p className="text-xs text-muted-foreground font-medium">Your procurement queue is currently idle.</p>
        </div>
        <Button asChild size="lg" className="w-full rounded-2xl h-14 font-black uppercase text-xs">
          <Link href="/retailer/categories">Shop Now</Link>
        </Button>
      </div>
    );
  }

  const handleCheckout = () => {
      if (typeof window !== 'undefined') {
          localStorage.setItem('ladook-buy-now', JSON.stringify(cartItems));
      }
      router.push('/retailer/checkout');
  };

  return (
    <div className="space-y-6 max-w-xs mx-auto px-1 pb-20">
      <div className="flex items-center justify-between">
        <div>
            <h1 className="text-2xl font-headline font-bold">Procurement</h1>
            <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest">Active Batch</p>
        </div>
        <Badge variant="outline" className="rounded-full bg-primary/5 text-primary border-primary/20 text-[10px] font-bold px-3">
            {cartItems.length} ITEMS
        </Badge>
      </div>

      <div className="space-y-4">
          {cartItems.map(item => (
            <Card key={item.id} className="rounded-3xl border shadow-sm overflow-hidden flex flex-col p-4 gap-4">
              <div className="flex items-center gap-4">
                <div className="relative h-20 w-16 rounded-2xl overflow-hidden bg-muted flex-shrink-0 border">
                    <Image src={item.image} alt={item.name} fill className="object-cover" data-ai-hint={item.aiHint} />
                </div>
                <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-sm truncate">{item.name}</h3>
                    <p className="text-[10px] text-muted-foreground font-medium truncate uppercase tracking-tighter">{item.variant}</p>
                    <p className="text-sm font-black text-primary mt-1">${item.price.toFixed(2)} <span className="text-[10px] text-muted-foreground font-normal">/ Unit</span></p>
                </div>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-dashed">
                <div className="flex items-center gap-1 bg-muted/50 rounded-full px-2 py-1">
                    <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full" onClick={() => updateQuantity(item.id, item.quantity - 1)} disabled={item.quantity <= 1}>
                    <MinusCircle className="h-4 w-4" />
                    </Button>
                    <span className="text-xs font-black w-8 text-center">{item.quantity}</span>
                    <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full" onClick={() => updateQuantity(item.id, item.quantity + 1)}>
                    <PlusCircle className="h-4 w-4" />
                    </Button>
                </div>
                <Button variant="ghost" size="icon" onClick={() => removeItem(item.id)} className="text-muted-foreground hover:text-destructive hover:bg-destructive/5 rounded-full h-10 w-10">
                    <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </Card>
          ))}
      </div>

      <Card className="rounded-[2.5rem] bg-zinc-900 text-white border-none shadow-2xl overflow-hidden relative">
          <CardHeader className="p-8 pb-4">
            <div className="flex items-center gap-2">
                <Calculator className="h-5 w-5 text-primary" />
                <CardTitle className="text-[10px] uppercase font-black tracking-widest text-zinc-300">Batch Summary</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="px-8 pb-8 space-y-3">
            <div className="flex justify-between text-[11px] font-bold uppercase tracking-widest text-zinc-300">
                <span>Est. Total</span>
                <span className="text-white text-lg">${total.toFixed(2)}</span>
            </div>
            <p className="text-[10px] text-zinc-300 font-medium leading-relaxed italic border-l-2 border-primary/30 pl-3">
                "Includes bulk logistics fees & compliance tax."
            </p>
          </CardContent>
          <CardFooter className="px-8 pb-8 pt-0">
            <Button onClick={handleCheckout} className="w-full h-14 rounded-2xl bg-white text-black hover:bg-zinc-200 font-black text-sm uppercase shadow-xl shadow-black/20">
              Checkout <ChevronRight className="ml-1 h-4 w-4" />
            </Button>
          </CardFooter>
      </Card>
    </div>
  );
}
