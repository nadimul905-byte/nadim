
"use client";
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { CreditCard, Banknote, Truck, Loader2, ArrowLeft, ShieldCheck, ChevronRight, Package, Calculator, Building, MapPin, Phone } from 'lucide-react';
import { mockOrders, type Order, type OrderItem } from '../orders/page'; 
import { format } from 'date-fns';
import { type CartItem } from '../cart/page';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from '@/components/ui/badge';

export default function RetailerCheckoutPage() {
    const { toast } = useToast();
    const router = useRouter();
    
    const [cartItems, setCartItems] = useState<CartItem[]>([]);
    const [shippingAddress, setShippingAddress] = useState({ 
        name: '', 
        businessName: '', 
        phone: '', 
        address1: '', 
        city: '', 
        state: '', 
        zip: '', 
        country: 'Bangladesh',
        instructions: '' 
    });
    const [paymentMethod, setPaymentMethod] = useState('card');
    const [savedAddresses] = useState([
        { id: 'addr1', label: 'Dhaka Warehouse - Gulshan', fullAddress: { name: 'Jane Doe', businessName: 'Elegance Retail Ltd', phone: '+880 1711-223344', address1: 'House 12, Road 5, Block C', city: 'Dhaka', state: 'Dhaka Division', zip: '1212', country: 'Bangladesh', instructions: 'Dock 4 available' }}
    ]);
    const [selectedSavedAddress, setSelectedSavedAddress] = useState('new');
    const [isProcessing, setIsProcessing] = useState(false);

    useEffect(() => {
        const buyNowItemsRaw = typeof window !== 'undefined' ? localStorage.getItem('ladook-buy-now') : null;
        if (buyNowItemsRaw) {
            try {
                const items: CartItem[] = JSON.parse(buyNowItemsRaw);
                setCartItems(items);
            } catch (e) {
                console.error("Failed to parse items from localStorage", e);
                router.push('/retailer/cart');
            }
        } else {
            setCartItems([
                { id: '1', name: 'Elegant Evening Gown', price: 129.99, quantity: 5, image: 'https://images.unsplash.com/photo-1589083133356-aa13ceaef7fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw3fHxldmVuaW5nJTIwZ293bnxlbnwwfHx8fDE3NDkzMzY1NzZ8MA&ixlib=rb-4.1.0&q=80&w=1080', aiHint: "evening gown", variant: "Size: M, Color: Burgundy" }
            ]);
        }
    }, [router]);
    
    const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const tax = subtotal * 0.08;
    const shippingCost = 15.00;
    const total = subtotal + tax + shippingCost;
    
    const handleSelectSavedAddress = (value: string) => {
        setSelectedSavedAddress(value);
        if(value !== 'new') {
            const addr = savedAddresses.find(a => a.id === value)?.fullAddress;
            if(addr) setShippingAddress(addr);
        } else {
            setShippingAddress({ name: '', businessName: '', phone: '', address1: '', city: '', state: '', zip: '', country: 'Bangladesh', instructions: '' });
        }
    }
    
    const handleShippingInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setShippingAddress((prev: any) => ({ ...prev, [name]: value }));
    };

    const handlePlaceOrder = (e: React.FormEvent) => {
        e.preventDefault();
        setIsProcessing(true);

        if (!shippingAddress.name || !shippingAddress.address1 || !shippingAddress.city || !shippingAddress.zip) {
            toast({
                title: "Logistic Error",
                description: "Primary destination details are missing.",
                variant: "destructive"
            });
            setIsProcessing(false);
            return;
        }

        toast({ title: "Authorizing Logistics...", description: "Securing transaction with Ladook Trust Bridge." });
        setTimeout(() => {
            const orderId = `ORD${Math.floor(Math.random() * 9000) + 1000}`;
            
            const newOrder: Order = {
                id: orderId, 
                date: format(new Date(), 'yyyy-MM-dd'), 
                vendorName: 'Global Manufacturing Corp', 
                status: 'Processing', 
                totalAmount: total,
                items: cartItems.map(i => ({ ...i, sku: `LSB-${i.id}`, unitPrice: i.price, totalPrice: i.price * i.quantity })),
                shippingAddress: { ...shippingAddress, addressLine1: shippingAddress.address1 },
                paymentMethod: paymentMethod === 'card' ? 'Visa **** 1234' : 'Bank Transfer',
                shippingMethod: 'Express Freight',
            };
            
            mockOrders.unshift(newOrder);
            
            if (typeof window !== 'undefined') {
                localStorage.removeItem('ladook-buy-now');
                localStorage.setItem('lastOrderId', orderId);
            }
            toast({ title: "Shipment Manifested", description: `Order #${orderId} has been moved to production.` });
            router.push('/retailer/orders/confirmation'); 
            setIsProcessing(false);
        }, 2000);
    };

    return (
      <div className="space-y-6 max-w-xs mx-auto px-1 pb-20 animate-in fade-in duration-500">
        <div className="flex items-center gap-4">
            <Button variant="outline" size="icon" onClick={() => router.back()} className="rounded-full h-10 w-10 border-zinc-200 shadow-sm">
                <ArrowLeft className="h-5 w-5 text-zinc-600" />
            </Button>
            <div>
                <h1 className="text-xl font-headline font-black tracking-tight">Secure Checkout</h1>
                <p className="text-[10px] text-muted-foreground font-black uppercase tracking-[0.2em]">Logistic Chain v4.1</p>
            </div>
        </div>

        <div className="space-y-4">
            <Accordion type="single" collapsible defaultValue="shipping" className="w-full space-y-4">
              <Card className="rounded-3xl border-none shadow-md overflow-hidden bg-card transition-all ring-1 ring-zinc-200/50">
                <AccordionItem value="shipping" className="border-none">
                  <AccordionTrigger className="hover:no-underline px-6 py-5">
                    <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-2xl bg-zinc-100 flex items-center justify-center">
                            <Truck className="h-5 w-5 text-zinc-600" />
                        </div>
                        <div className="text-left">
                            <p className="text-sm font-black uppercase tracking-tight">1. Logistic Details</p>
                            <p className="text-[9px] text-muted-foreground font-black uppercase tracking-widest">Destination Hub</p>
                        </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-6 pb-6 pt-0">
                    <div className="space-y-4 pt-4 border-t border-dashed border-zinc-100">
                      <div className="space-y-1.5">
                        <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-800">Logistics Profile</Label>
                        <Select onValueChange={handleSelectSavedAddress} defaultValue="new">
                            <SelectTrigger className="rounded-xl h-11 border-zinc-200 bg-muted/20 font-bold text-xs"><SelectValue placeholder="Select an address" /></SelectTrigger>
                            <SelectContent className="rounded-2xl">
                                {savedAddresses.map((addr: any) => <SelectItem key={addr.id} value={addr.id} className="text-xs font-bold">{addr.label}</SelectItem>)}
                                <SelectItem value="new" className="text-xs font-bold">+ Create New Terminal</SelectItem>
                            </SelectContent>
                        </Select>
                      </div>
                      
                      {selectedSavedAddress === 'new' && (
                        <div className="space-y-4 pt-2">
                          <div className="space-y-1.5">
                              <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-800 flex items-center gap-1">
                                  <Building className="h-3 w-3"/> Corporate / Business Name
                              </Label>
                              <Input name="businessName" value={shippingAddress.businessName} onChange={handleShippingInputChange} placeholder="e.g., Elegance Retail Ltd" className="rounded-xl h-11 border-zinc-200 bg-background font-medium" />
                          </div>
                          <div className="grid grid-cols-2 gap-3">
                            <div className="space-y-1.5">
                                <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-900 underline underline-offset-4 decoration-primary/30">Recipient</Label>
                                <Input name="name" value={shippingAddress.name} onChange={handleShippingInputChange} required className="rounded-xl h-11 border-zinc-400 bg-background shadow-sm font-black text-foreground focus:ring-primary/20" />
                            </div>
                            <div className="space-y-1.5">
                                <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-800">Contact Comms</Label>
                                <Input name="phone" type="tel" value={shippingAddress.phone} onChange={handleShippingInputChange} required className="rounded-xl h-11 border-zinc-200 bg-background font-medium" />
                            </div>
                          </div>
                          <div className="space-y-1.5">
                              <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-800 flex items-center gap-1">
                                  <MapPin className="h-3 w-3"/> Terminal Address
                              </Label>
                              <Input name="address1" value={shippingAddress.address1} onChange={handleShippingInputChange} required className="rounded-xl h-11 border-zinc-200 bg-background font-medium" />
                          </div>
                          <div className="grid grid-cols-2 gap-3">
                              <div className="space-y-1.5">
                                <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-800">Region / City</Label>
                                <Input name="city" value={shippingAddress.city} onChange={handleShippingInputChange} required className="rounded-xl h-11 border-zinc-200 bg-background font-medium" />
                              </div>
                              <div className="space-y-1.5">
                                <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-800">Postal Identity</Label>
                                <Input name="zip" value={shippingAddress.zip} onChange={handleShippingInputChange} required className="rounded-xl h-11 border-zinc-200 bg-background font-medium" />
                              </div>
                          </div>
                          <div className="space-y-1.5">
                            <Label className="text-[10px] font-black uppercase tracking-widest text-zinc-800">Unloading Instructions</Label>
                            <Textarea 
                                name="instructions" 
                                value={shippingAddress.instructions} 
                                onChange={handleShippingInputChange} 
                                placeholder="Dock requirements, gate codes, or delivery windows..."
                                className="rounded-xl text-xs resize-none border-zinc-200 bg-background font-medium"
                                rows={3}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Card>

              <Card className="rounded-3xl border-none shadow-md overflow-hidden bg-card ring-1 ring-zinc-200/50">
                <AccordionItem value="payment" className="border-none">
                  <AccordionTrigger className="hover:no-underline px-6 py-5">
                    <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-2xl bg-zinc-100 flex items-center justify-center">
                            <CreditCard className="h-5 w-5 text-zinc-600" />
                        </div>
                        <div className="text-left">
                            <p className="text-sm font-black uppercase tracking-tight">2. Payment Method</p>
                            <p className="text-[9px] text-muted-foreground font-black uppercase tracking-widest">Authorization Module</p>
                        </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-6 pb-6 pt-0">
                      <RadioGroup defaultValue="card" onValueChange={setPaymentMethod} className="space-y-3 pt-4 border-t border-dashed border-zinc-100">
                          <Label htmlFor="card" className="flex items-center space-x-3 p-4 border rounded-2xl has-[:checked]:border-zinc-400 has-[:checked]:bg-zinc-50 cursor-pointer transition-all border-zinc-100">
                              <RadioGroupItem value="card" id="card" className="border-zinc-300" />
                              <div className="flex-1">
                                  <p className="text-xs font-black uppercase tracking-tight text-zinc-900">Corporate Credit Card</p>
                                  <p className="text-[10px] text-muted-foreground font-bold">Visa, Mastercard, Amex</p>
                              </div>
                              <CreditCard className="h-4 w-4 text-zinc-400" />
                          </Label>
                          {paymentMethod === 'card' && (
                              <div className="p-4 bg-muted/30 rounded-2xl space-y-3 animate-in slide-in-from-top-2 duration-300 border border-zinc-100">
                                  <Input placeholder="Card Number" className="rounded-xl bg-background border-zinc-200 h-11 text-xs font-bold" />
                                  <div className="grid grid-cols-2 gap-3">
                                      <Input placeholder="MM/YY" className="rounded-xl bg-background border-zinc-200 h-11 text-xs font-bold" />
                                      <Input placeholder="CVC" className="rounded-xl bg-background border-zinc-200 h-11 text-xs font-bold" />
                                  </div>
                              </div>
                          )}
                          <Label htmlFor="bank" className="flex items-center space-x-3 p-4 border rounded-2xl has-[:checked]:border-zinc-400 has-[:checked]:bg-zinc-50 cursor-pointer transition-all border-zinc-100">
                              <RadioGroupItem value="bank" id="bank" className="border-zinc-300" />
                              <div className="flex-1">
                                  <p className="text-xs font-black uppercase tracking-tight text-zinc-900">Direct Bank Transfer</p>
                                  <p className="text-[10px] text-muted-foreground font-bold">ACH / SWIFT Wire</p>
                              </div>
                              <Banknote className="h-4 w-4 text-zinc-400" />
                          </Label>
                      </RadioGroup>
                  </AccordionContent>
                </AccordionItem>
              </Card>
            </Accordion>

            <Card className="rounded-[2.5rem] bg-zinc-900 text-white border-none shadow-2xl overflow-hidden relative">
              <CardHeader className="p-8 pb-4">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <Calculator className="h-5 w-5 text-primary" />
                        <CardTitle className="text-[10px] uppercase font-black tracking-[0.3em] text-zinc-300">Transaction Summary</CardTitle>
                    </div>
                    <Badge variant="outline" className="rounded-full text-[8px] font-black uppercase text-zinc-500 border-zinc-800 tracking-widest">
                        OS v4.1
                    </Badge>
                </div>
              </CardHeader>
              <CardContent className="px-8 pb-8 space-y-6">
                  <div className="space-y-4 max-h-48 overflow-y-auto pr-2 no-scrollbar border-b border-white/5 pb-4">
                    {cartItems.map((item: CartItem) => (
                      <div key={item.id} className="flex items-center justify-between group">
                        <div className="flex items-center gap-3">
                          <div className="relative h-12 w-12 rounded-xl overflow-hidden border border-white/10 group-hover:border-primary/50 transition-colors bg-zinc-800">
                             <Image src={item.image} alt={item.name} fill className="object-cover" data-ai-hint={item.aiHint}/>
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-black text-white truncate w-24 sm:w-32">{item.name}</p>
                            <p className="text-[9px] text-zinc-300 font-black uppercase tracking-widest mt-0.5">Quantity: {item.quantity}</p>
                          </div>
                        </div>
                        <p className="text-xs font-black text-white">${(item.price * item.quantity).toFixed(2)}</p>
                      </div>
                    ))}
                  </div>
                  
                  <div className="space-y-3.5">
                    <div className="flex justify-between text-[11px] font-black uppercase tracking-widest text-zinc-300">
                        <span>Net Subtotal</span>
                        <span className="text-white">${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-[11px] font-black uppercase tracking-widest text-zinc-300">
                        <span>Logistic Freight</span>
                        <span className="text-white">${shippingCost.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-[11px] font-black uppercase tracking-widest text-zinc-300">
                        <span>Compliance Tax</span>
                        <span className="text-white">${tax.toFixed(2)}</span>
                    </div>
                    <div className="pt-5 flex justify-between items-center border-t border-white/10 mt-2">
                        <span className="text-[12px] font-black uppercase tracking-[0.2em] text-zinc-200">Grand Total</span>
                        <span className="text-3xl font-black text-white tracking-tighter">${total.toFixed(2)}</span>
                    </div>
                  </div>

                   <Card className="rounded-2xl border-none bg-primary/10 shadow-none p-0 mt-6">
                        <CardContent className="p-4 flex gap-3">
                            <ShieldCheck className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                            <p className="text-[11px] font-bold text-zinc-100 leading-relaxed italic">
                                "Secure B2B Escrow active. Capital released only upon terminal arrival verification."
                            </p>
                        </CardContent>
                    </Card>
              </CardContent>
              <CardFooter className="px-8 pb-8 pt-0">
                 <Button size="lg" className="w-full h-14 rounded-2xl bg-white text-black hover:bg-zinc-200 font-black text-sm uppercase shadow-xl transition-transform active:scale-95" onClick={handlePlaceOrder} disabled={isProcessing}>
                    {isProcessing ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Package className="mr-2 h-4 w-4"/>}
                    Commit Order
                </Button>
              </CardFooter>
            </Card>
        </div>
      </div>
    );
}
