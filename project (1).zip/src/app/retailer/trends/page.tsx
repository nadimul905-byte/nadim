
"use client";
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp, Zap, Search, Star, Sparkles, ArrowRight } from 'lucide-react';
import { allMockProducts, type Product as HomePageProduct } from '../products/page';
import ProductRecommendationsSection from '../components/ProductRecommendationsSection';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import Link from 'next/link';
import Image from 'next/image';

const bestSellers = allMockProducts.filter(p => ['rp1', 'rp2', 'rp3', 'rp4', 'rp5', 'rp6'].includes(p.id));
const trendingKeywords = ["minimalist jewelry", "sustainable cotton", "linen dresses", "Y2K fashion", "oversized blazer", "cargo pants"];
const featuredVendors = [
    { name: "Chic Designs Co.", slug: "chic-designs-co", avatar: "https://images.unsplash.com/photo-1590874315261-788881621f7a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwbG9nb3xlbnwwfHx8fDE3NDg4NjUyODl8MA&ixlib=rb-4.1.0&q=80&w=1080", avatarAiHint: "fashion logo", specialty: "Elegant Women's Wear" },
    { name: "Denim Dreams", slug: "denim-dreams", avatar: "https://images.unsplash.com/photo-1459173422306-0ce3fb37f832?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw2fHxkZW5pbSUyMGJyYW5kfGVufDB8fHx8MTc0OTIxNTcwMHww&ixlib.rb-4.1.0&q=80&w=1080", avatarAiHint: "denim brand", specialty: "Premium Denim" },
    { name: "Artisan Leather", slug: "artisan-leather", avatar: "https://placehold.co/40x40.png?text=AL", avatarAiHint: "leather goods", specialty: "Handcrafted Bags & Wallets" },
];

const topDesigners = [
    { name: "Isabella Rossi", slug: "isabella-rossi", avatar: "https://picsum.photos/seed/designer1/80/80", avatarAiHint: "woman designer", specialty: "Italian Couture" },
    { name: "Kenji Tanaka", slug: "kenji-tanaka", avatar: "https://picsum.photos/seed/designer2/80/80", avatarAiHint: "man designer", specialty: "Japanese Streetwear" },
    { name: "Chloe Dubois", slug: "chloe-dubois", avatar: "https://picsum.photos/seed/designer3/80/80", avatarAiHint: "female fashion", specialty: "Parisian Chic" },
];


const ProductCardSmall = ({ product }: { product: HomePageProduct }) => (
    <Link href={`/retailer/products/${product.id}`} className="block group">
        <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted">
            <div className="relative h-16 w-16 rounded-md overflow-hidden bg-muted flex-shrink-0">
                <Image src={product.image} alt={product.name} layout="fill" objectFit="cover" data-ai-hint={product.aiHint} />
            </div>
            <div className="flex-1">
                <p className="text-sm font-medium truncate group-hover:text-primary">{product.name}</p>
                <p className="text-xs text-muted-foreground">{product.vendorName}</p>
                <p className="text-sm font-semibold text-primary mt-1">{product.price}</p>
            </div>
        </div>
    </Link>
);


export default function RetailerTrendsPage() {
    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-headline font-semibold flex items-center gap-3">
                <TrendingUp className="h-8 w-8 text-primary"/> Market Trends & Insights
            </h1>
            
            <div className="overflow-x-auto pb-4 no-scrollbar -mx-4 px-4">
              <ProductRecommendationsSection />
            </div>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Sparkles className="text-primary"/> Platform Best-Sellers</CardTitle>
                    <CardDescription>Top-selling products across the Ladook marketplace this week.</CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {bestSellers.map(product => <ProductCardSmall key={product.id} product={product} />)}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Search className="text-primary"/> Trending Searches</CardTitle>
                    <CardDescription>What buyers are looking for right now.</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-wrap gap-2">
                    {trendingKeywords.map(keyword => (
                        <Button key={keyword} variant="outline" asChild>
                            <Link href={`/retailer/search?q=${encodeURIComponent(keyword)}`}>{keyword}</Link>
                        </Button>
                    ))}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Star className="text-primary"/> Featured Vendors</CardTitle>
                    <CardDescription>Top-performing and up-and-coming brands to watch.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    {featuredVendors.map(vendor => (
                        <Link key={vendor.slug} href={`/retailer/vendors/${vendor.slug}`} className="block">
                            <div className="flex items-center justify-between p-3 rounded-lg hover:bg-muted">
                                <div className="flex items-center gap-4">
                                    <Avatar className="h-12 w-12 border">
                                        <AvatarImage src={vendor.avatar} alt={vendor.name} data-ai-hint={vendor.avatarAiHint} />
                                        <AvatarFallback>{vendor.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <p className="font-semibold">{vendor.name}</p>
                                        <p className="text-sm text-muted-foreground">{vendor.specialty}</p>
                                    </div>
                                </div>
                                <ArrowRight className="h-5 w-5 text-muted-foreground" />
                            </div>
                        </Link>
                    ))}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2"><Sparkles className="text-primary"/> Top Designers</CardTitle>
                    <CardDescription>Industry-leading and visionary designers to follow.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    {topDesigners.map(designer => (
                        <Link key={designer.slug} href={`/retailer/vendors/${designer.slug}`} className="block">
                            <div className="flex items-center justify-between p-3 rounded-lg hover:bg-muted">
                                <div className="flex items-center gap-4">
                                    <Avatar className="h-12 w-12 border">
                                        <AvatarImage src={designer.avatar} alt={designer.name} data-ai-hint={designer.avatarAiHint} />
                                        <AvatarFallback>{designer.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <p className="font-semibold">{designer.name}</p>
                                        <p className="text-sm text-muted-foreground">{designer.specialty}</p>
                                    </div>
                                </div>
                                <ArrowRight className="h-5 w-5 text-muted-foreground" />
                            </div>
                        </Link>
                    ))}
                </CardContent>
            </Card>
        </div>
    );
}
