
"use client";

import React, { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Send, Loader2, ShieldAlert, UploadCloud, Trash2 } from 'lucide-react';
import Image from 'next/image';

export default function ReportIssuePage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();

  const [orderId, setOrderId] = useState('');
  const [issueType, setIssueType] = useState('');
  const [description, setDescription] = useState('');
  const [images, setImages] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const orderIdFromUrl = searchParams.get('orderId');
    if (orderIdFromUrl) {
      setOrderId(orderIdFromUrl);
    }
  }, [searchParams]);

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      const filesArray = Array.from(event.target.files);
      if (images.length + filesArray.length > 3) {
        toast({ title: "Image limit reached", description: "You can upload a maximum of 3 images.", variant: "destructive" });
        return;
      }
      setImages(prev => [...prev, ...filesArray]);
      const newPreviews = filesArray.map(file => URL.createObjectURL(file));
      setImagePreviews(prev => [...prev, ...newPreviews]);
    }
  };

  const removeImage = (index: number) => {
    URL.revokeObjectURL(imagePreviews[index]);
    setImages(prev => prev.filter((_, i) => i !== index));
    setImagePreviews(prev => prev.filter((_, i) => i !== index));
  };
  
  useEffect(() => {
    // Cleanup object URLs on component unmount
    return () => {
      imagePreviews.forEach(url => URL.revokeObjectURL(url));
    };
  }, [imagePreviews]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderId || !issueType || !description) {
      toast({ title: "Missing Information", description: "Please fill out all required fields.", variant: "destructive" });
      return;
    }
    setIsSubmitting(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    console.log("Dispute Submitted:", { orderId, issueType, description, images: images.map(f => f.name) });

    toast({ title: "Issue Reported", description: "Your dispute has been submitted and the vendor has been notified. An admin will review it shortly." });
    // Redirect to a confirmation or disputes page
    router.push(`/retailer/orders/${orderId}`);
    setIsSubmitting(false);
  };

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => router.back()} aria-label="Back">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-3xl font-headline font-semibold">Report an Issue</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <ShieldAlert className="mr-3 h-6 w-6 text-destructive" />
            Dispute for Order #{orderId}
          </CardTitle>
          <CardDescription>
            Please provide details about the issue. This will be sent to the vendor and a platform admin for resolution.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label htmlFor="issueType">Issue Type</Label>
              <Select value={issueType} onValueChange={setIssueType} required>
                <SelectTrigger id="issueType">
                  <SelectValue placeholder="Select the main issue..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="damaged">Damaged Goods</SelectItem>
                  <SelectItem value="not-as-described">Item Not as Described</SelectItem>
                  <SelectItem value="wrong-item">Wrong Item Received</SelectItem>
                  <SelectItem value="missing-items">Missing Items from Order</SelectItem>
                  <SelectItem value="late-delivery">Late Delivery</SelectItem>
                  <SelectItem value="other">Other (Please describe below)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="description">Detailed Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Explain the issue in detail. What was wrong, how was it different from what you expected?"
                rows={8}
                required
              />
            </div>
            <div>
              <Label>Attach Photos (Max 3)</Label>
              <Label htmlFor="imageUpload" className="mt-1 flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer hover:bg-muted/50">
                <UploadCloud className="w-8 h-8 mb-2 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">Click to upload images</p>
                <Input id="imageUpload" type="file" multiple accept="image/*" className="hidden" onChange={handleImageChange} disabled={images.length >= 3} />
              </Label>
              {imagePreviews.length > 0 && (
                <div className="mt-4 grid grid-cols-3 gap-3">
                  {imagePreviews.map((src, index) => (
                    <div key={index} className="relative group aspect-square">
                      <Image src={src} alt={`Preview ${index + 1}`} layout="fill" className="rounded-md object-cover" />
                      <Button type="button" variant="destructive" size="icon" className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity" onClick={() => removeImage(index)} aria-label={`Remove image ${index + 1}`}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="flex justify-end">
              <Button type="submit" disabled={isSubmitting} size="lg">
                {isSubmitting ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Send className="mr-2 h-5 w-5" />}
                Submit Dispute
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
