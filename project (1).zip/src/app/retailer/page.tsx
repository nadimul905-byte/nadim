
"use client";
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation'; 
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { 
    Search, Image as ImageIcon, Heart, 
    Sparkles, ShoppingCart, MessageSquare, 
    ArrowRight, Users, ChevronRight, Zap,
    TrendingUp, Eye, ShoppingBag, ArrowUpRight,
    PlusCircle, Palette
} from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import ProductRecommendationsSection from './components/ProductRecommendationsSection';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import { mockSocialFeed, type SocialPost } from '@/lib/mockSocialData';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetDescription } from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import { type CartItem } from './cart/page';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { allMockProducts, type Product as HomePageProduct } from '@/app/retailer/products/page';

const promoBanners = [
  { id: 1, src: "https://images.unsplash.com/photo-1594969155368-f19485a9d88c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxmYXNoaW9uJTIwc2FsZXxlbnwwfHx8fDE3NDkxMjUyMTd8MA&ixlib=rb-4.1.0&q=80&w=1080", alt: "Seasonal Sale", link: "/retailer/products?category=sale", aiHint: "fashion sale" },
  { id: 2, src: "https://images.unsplash.com/photo-1626784579980-db39c1a13aa9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw3fHxmYXNoaW9uJTIwbGVhcm5pbmclMjBjbGFzc3xlbnwwfHx8fDE3NDkyMjAxNTN8MA&ixlib=rb-4.1.0&q=80&w=1080", alt: "Featured Designers", link: "/retailer/trends", aiHint: "fashion designer" },
];

const trendingProducts = allMockProducts.filter(p => ['rp1', 'rp2', 'rp3', 'rp4'].includes(p.id));
const newArrivals = allMockProducts.filter(p => ['rp5', 'rp6', 'rp12', 'vprod4'].includes(p.id));
const mostViewed = allMockProducts.filter(p => ['rp7', 'vprod1', 'rp1', 'rp3'].includes(p.id));
const mostPurchased = allMockProducts.filter(p => ['rp2', 'rp12', 'rp5', 'vprod1'].includes(p.id));

const ProductCard = ({ product, isFeatured = false }: { product: HomePageProduct, isFeatured?: boolean }) => {
  const router = useRouter();
  const { toast } = useToast();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    toast({ title: "Added to Batch", description: `${product.name} is in procurement.` });
  };

  const handleBuyNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    const cartItem: CartItem = {
      id: product.id,
      name: product.name,
      price: parseFloat(product.price.replace('$', '')),
      quantity: product.minOrderQuantity || 1,
      image: product.image,
      aiHint: product.aiHint,
    };
    if (typeof window !== 'undefined') {
        localStorage.setItem('ladook-buy-now', JSON.stringify([cartItem]));
    }
    router.push('/retailer/checkout');
  };

  return (
    <Card className={cn(
        "w-48 flex-shrink-0 snap-start rounded-3xl overflow-hidden group border shadow-sm hover:shadow-lg transition-all flex flex-col",
        isFeatured && "border-primary/20 shadow-primary/5 ring-1 ring-primary/10"
    )}>
        <Link href={`/retailer/products/${product.id}`} className="block flex-grow">
            <div className="relative h-40 w-full bg-muted">
                <Image 
                    src={product.image} 
                    alt={product.name} 
                    fill 
                    className="object-cover transition-transform duration-500 group-hover:scale-110"
                    data-ai-hint={product.aiHint} 
                />
                {isFeatured && (
                    <div className="absolute top-2 left-2 px-2 py-0.5 bg-primary text-white text-[7px] font-black uppercase rounded-full shadow-lg flex items-center gap-1">
                        <Sparkles className="h-2 w-2 fill-white" /> Trending
                    </div>
                )}
                <Button variant="ghost" size="icon" className="absolute top-2 right-2 bg-black/20 hover:bg-black/40 text-white rounded-full h-8 w-8">
                    <Heart className="h-4 w-4" />
                </Button>
            </div>
            <CardHeader className="p-3">
                <CardTitle className="text-sm font-bold truncate group-hover:text-primary">{product.name}</CardTitle>
                <CardDescription className="text-[10px] text-muted-foreground mt-0.5 line-clamp-1 font-medium">
                    {product.vendorName}
                </CardDescription>
                <div className="flex justify-between items-end mt-2">
                    <p className="text-sm font-black text-primary">{product.price}</p>
                    <p className="text-[8px] font-black uppercase text-muted-foreground tracking-widest">MOQ: {product.minOrderQuantity || 1}</p>
                </div>
            </CardHeader>
        </Link>
        <CardFooter className="p-2 border-t bg-muted/5 grid grid-cols-2 gap-2">
             <Button variant="outline" size="sm" className="h-8 rounded-xl text-[9px] font-black uppercase border-primary/10 text-primary" onClick={handleAddToCart}>
                Cart
            </Button>
            <Button size="sm" className="h-8 rounded-xl text-[9px] font-black uppercase bg-accent text-accent-foreground" onClick={handleBuyNow}>
                Buy Now
            </Button>
        </CardFooter>
    </Card>
  );
};

const ProductCarouselSection = ({ title, products, variant = 'default', link = '/retailer/products' }: { title: string, products: HomePageProduct[], variant?: 'default' | 'uplifted', link?: string }) => (
  <section className={cn(
      "space-y-4",
      variant === 'uplifted' && "bg-primary/5 p-4 rounded-[2.5rem] border border-primary/10 shadow-inner -mx-1"
  )}>
    <div className="flex items-center justify-between border-b border-dashed border-primary/10 pb-2 px-1">
        <h2 className={cn(
            "text-[10px] font-black uppercase tracking-[0.3em] flex items-center gap-2",
            variant === 'uplifted' ? "text-primary" : "text-muted-foreground"
        )}>
          {variant === 'uplifted' ? <Eye className="h-3 w-3" /> : null}
          {title}
        </h2>
        <Button variant="link" size="sm" className="p-0 h-auto text-[9px] font-black uppercase text-primary" asChild>
          <Link href={link}>All <ChevronRight className="h-3 w-3"/></Link>
        </Button>
    </div>
    <div className="flex overflow-x-auto snap-x snap-mandatory space-x-4 pb-4 no-scrollbar">
      {products.map(product => <ProductCard key={product.id} product={product} isFeatured={variant === 'uplifted'} />)}
    </div>
  </section>
);

const SocialPostCard = ({ post }: { post: SocialPost }) => {
    const [isLiked, setIsLiked] = useState(false);
    const [likeCount, setLikeCount] = useState(post.likes);
    const [isSheetOpen, setIsSheetOpen] = useState(false);
    
    const initialComments = [
        { user: "Jane Doe", text: "This looks amazing! 🔥" },
        { user: "Bob Smith", text: "What's the MOQ on this?" }
    ];
    const [comments, setComments] = useState(initialComments);
    const [newComment, setNewComment] = useState("");

    const handleLikeClick = () => {
        setIsLiked(!isLiked);
        setLikeCount(prev => isLiked ? prev - 1 : prev + 1);
    };

    const handlePostComment = (e: React.FormEvent) => {
        e.preventDefault();
        if (newComment.trim() === "") return;
        setComments(prev => [{ user: "Me", text: newComment }, ...prev]);
        setNewComment("");
    };

    return (
        <Card className="rounded-3xl border shadow-sm overflow-hidden bg-card">
          <CardHeader className="flex flex-row items-center gap-3 p-4 bg-muted/20 border-b border-dashed">
            <Avatar className="h-10 w-10 border-2 border-background shadow-sm">
              <AvatarImage src={post.vendorAvatar} alt={post.vendorName} data-ai-hint={post.vendorAvatarAiHint}/>
              <AvatarFallback>{post.vendorName.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-xs truncate leading-none">{post.vendorName}</p>
              <p className="text-[9px] text-muted-foreground font-black uppercase tracking-widest mt-1.5">{post.timestamp}</p>
            </div>
            <Badge variant="outline" className="rounded-full bg-primary/5 text-primary border-primary/20 text-[8px] font-black px-2.5">DISCOVERY</Badge>
          </CardHeader>
          <CardContent className="p-4 space-y-4">
             <p className="text-xs font-medium leading-relaxed text-muted-foreground italic">"{post.postText}"</p>
             {post.postImage && (
                 <div className="relative aspect-video rounded-2xl overflow-hidden border shadow-inner bg-muted">
                    <Image src={post.postImage} alt="Post image" fill className="object-cover" data-ai-hint={post.postImageAiHint} />
                 </div>
             )}
          </CardContent>
           <CardFooter className="p-4 border-t border-dashed flex justify-between items-center bg-muted/5">
             <div className="flex gap-4">
                 <Button variant="ghost" size="sm" className="flex items-center gap-1.5 h-auto p-0 hover:bg-transparent" onClick={handleLikeClick}>
                    <Heart className={cn("h-4 w-4 transition-colors", isLiked ? 'fill-primary text-primary' : 'text-muted-foreground')}/> 
                    <span className="text-[10px] font-black text-muted-foreground">{likeCount}</span>
                 </Button>
                 <Sheet open={isSheetOpen} onOpenChange={setIsSheetOpen}>
                    <SheetTrigger asChild>
                        <Button variant="ghost" size="sm" className="flex items-center gap-1.5 h-auto p-0 hover:bg-transparent">
                            <MessageSquare className="h-4 w-4 text-muted-foreground"/> 
                            <span className="text-[10px] font-black text-muted-foreground">{comments.length}</span>
                        </Button>
                    </SheetTrigger>
                    <SheetContent side="right" className="w-[85vw] sm:max-w-md p-0 flex flex-col rounded-l-[2rem] border-none shadow-2xl overflow-hidden">
                        <SheetHeader className="p-6 bg-zinc-900 text-white flex-shrink-0">
                            <SheetTitle className="text-white text-lg font-black tracking-tight">Discussion Thread</SheetTitle>
                            <SheetDescription className="text-zinc-500 text-[10px] font-black uppercase tracking-widest">Public Procurement Log</SheetDescription>
                        </SheetHeader>
                        <ScrollArea className="flex-1 p-6 bg-zinc-50 dark:bg-zinc-900/30">
                            <div className="space-y-6">
                                {comments.map((comment, index) => (
                                    <div key={index} className="flex items-start gap-3">
                                        <Avatar className="h-8 w-8 border">
                                            <AvatarFallback className="text-[10px] font-black">{comment.user[0]}</AvatarFallback>
                                        </Avatar>
                                        <div className="flex-1 bg-white dark:bg-zinc-800 p-3 rounded-2xl rounded-tl-none shadow-sm border">
                                            <p className="font-bold text-[10px] text-primary uppercase tracking-tighter mb-1">{comment.user}</p>
                                            <p className="text-xs font-medium leading-relaxed">{comment.text}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </ScrollArea>
                        <div className="p-4 bg-background border-t">
                            <form onSubmit={handlePostComment} className="flex gap-2">
                                <Input 
                                    placeholder="Add comment..." 
                                    className="h-11 rounded-xl bg-muted/30 border-none text-xs font-medium"
                                    value={newComment}
                                    onChange={(e) => setNewComment(e.target.value)}
                                />
                                <Button type="submit" size="icon" className="h-11 w-11 rounded-xl shadow-lg">
                                    <ArrowRight className="h-4 w-4" />
                                </Button>
                            </form>
                        </div>
                    </SheetContent>
                </Sheet>
             </div>
             <Button variant="outline" size="sm" className="h-8 rounded-xl text-[9px] font-black uppercase px-4 border-primary/20 text-primary hover:bg-primary/5" asChild>
                 <Link href="/retailer/social">Open Post</Link>
             </Button>
           </CardFooter>
        </Card>
    );
};

export default function RetailerHomePage() {
  const [currentBanner, setCurrentBanner] = React.useState(0);
  const [searchTerm, setSearchTerm] = useState(''); 
  const router = useRouter(); 

  React.useEffect(() => {
    const timer = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % promoBanners.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const handleSearchSubmit = () => {
    if (searchTerm.trim()) {
      router.push(`/retailer/search?q=${encodeURIComponent(searchTerm.trim())}`);
    }
  };

  return (
    <div className="space-y-8 max-w-xs mx-auto px-1 pb-20 animate-in fade-in duration-500">
      <div className="relative group">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground group-focus-within:text-primary transition-colors" />
        <Input 
          type="search" 
          placeholder="Procure products, fabrics, or vendors..." 
          className="pl-12 pr-14 py-3 text-sm h-14 rounded-2xl bg-card border shadow-sm transition-all focus:ring-primary/20 font-medium"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') handleSearchSubmit();
          }}
        />
        <Button variant="ghost" size="icon" className="absolute right-2 top-1/2 -translate-y-1/2 h-10 w-10 rounded-xl" onClick={() => router.push('/retailer/search?image=true')}>
          <ImageIcon className="h-5 w-5 text-muted-foreground hover:text-primary" />
        </Button>
      </div>

      <Card className="overflow-hidden shadow-2xl relative rounded-[2rem] border-none bg-zinc-900">
        <div className="relative w-full h-48 md:h-56">
          {promoBanners.map((banner, index) => (
            <Link href={banner.link} key={banner.id}>
              <Image 
                src={banner.src} 
                alt={banner.alt} 
                fill 
                className={cn(
                    "object-cover transition-all duration-1000 ease-in-out",
                    index === currentBanner ? 'opacity-100 scale-100' : 'opacity-0 scale-105'
                )}
                data-ai-hint={banner.aiHint}
              />
            </Link>
          ))}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none" />
        </div>
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2">
            {promoBanners.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentBanner(index)}
                className={cn(
                    "h-1.5 rounded-full transition-all duration-300 shadow-sm",
                    index === currentBanner ? "w-6 bg-white" : "w-1.5 bg-white/40"
                )}
                aria-label={`Slide ${index + 1}`}
              />
            ))}
          </div>
      </Card>

      {/* Quick Operations Grid */}
      <div className="grid grid-cols-2 gap-3">
        <Button asChild variant="outline" className="h-20 flex-col gap-2 rounded-3xl border-2 hover:bg-primary/5 hover:border-primary/50 transition-all group shadow-sm bg-card">
          <Link href="/retailer/custom-requests/new">
            <PlusCircle className="h-5 w-5 text-primary group-hover:scale-110 transition-transform" />
            <span className="text-[10px] font-black uppercase tracking-widest text-foreground">Post Request</span>
          </Link>
        </Button>
        <Button asChild variant="outline" className="h-20 flex-col gap-2 rounded-3xl border-2 hover:bg-primary/5 hover:border-primary/50 transition-all group shadow-sm bg-card">
          <Link href="/retailer/design-studio">
            <Palette className="h-5 w-5 text-primary group-hover:scale-110 transition-transform" />
            <span className="text-[10px] font-black uppercase tracking-widest text-foreground">Design Studio</span>
          </Link>
        </Button>
      </div>
      
      <ProductCarouselSection title="Trending Now" products={trendingProducts} link="/retailer/products?category=sale" />
      <ProductCarouselSection title="New Arrivals" products={newArrivals} link="/retailer/products" />
      
      <ProductRecommendationsSection />

      <ProductCarouselSection title="Most Viewed" products={mostViewed} variant="uplifted" link="/retailer/trends" />
      
      <ProductCarouselSection title="Most Purchased" products={mostPurchased} link="/retailer/products" />

      <section className="bg-secondary/40 rounded-[2.5rem] p-2 border shadow-inner">
        <div className="flex justify-between items-center px-6 py-4">
          <h2 className="text-[10px] font-black uppercase tracking-[0.3em] text-primary flex items-center gap-2">
            <Users className="h-3.5 w-3.5" /> Discovery Feed
          </h2>
          <div className="flex items-center gap-4">
            <Button variant="link" size="sm" asChild className="p-0 h-auto text-[9px] font-black uppercase text-primary tracking-widest">
                <Link href="/retailer/custom-requests/new">+ Post Lead</Link>
            </Button>
            <Button variant="link" size="sm" asChild className="p-0 h-auto text-[9px] font-black uppercase text-primary tracking-widest">
                <Link href="/retailer/social">All Activity</Link>
            </Button>
          </div>
        </div>
        <div className="space-y-4 px-1 pb-4">
          {mockSocialFeed.slice(0, 3).map(post => (
            <SocialPostCard key={post.id} post={post} />
          ))}
        </div>
      </section>

      <style jsx global>{`
        .no-scrollbar::-webkit-scrollbar {
            display: none;
        }
        .no-scrollbar {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}
