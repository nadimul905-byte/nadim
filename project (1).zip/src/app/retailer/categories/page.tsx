
"use client";
import React, { Suspense } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shirt, Watch, Diamond, Footprints, SprayCan, Dumbbell, ShoppingBag, Layers, Scissors, Palette, Package, Sparkles, Tag, Scaling, Loader2 } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { useSearchParams } from 'next/navigation';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Reusing the same data source as the retailer for consistency
const productCategories = [
  { name: "Women's Apparel", icon: Shirt, link: "/retailer/products?category=womens-apparel", image: "https://images.unsplash.com/photo-1618244972963-dbee1a7edc95?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw1fHx3b21lbiUyMGZhc2hpb258ZW58MHx8fHwxNzQ5NDc5NjM4fDA&ixlib=rb-4.1.0&q=80&w=1080", aiHint:"women fashion" },
  { name: "Men's Apparel", icon: Shirt, link: "/retailer/products?category=mens-apparel", image: "https://images.unsplash.com/photo-1507680434567-5739c80be1ac?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw5fHxtZW4lMjBmYXNoaW9ufGVufDB8fHx8MTc0OTQ3OTYzOHww&ixlib=rb-4.1.0&q=80&w=1080", aiHint:"men fashion" },
  { name: "Kids' Apparel", icon: Shirt, link: "/retailer/products?category=kids-apparel", image: "https://images.unsplash.com/photo-1596870230751-ebdfce98ec42?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwzfHxraWRzJTIwZmFzaGlvbnxlbnwwfHx8fDE3NDk1NTk0NTR8MA&ixlib=rb-4.1.0&q=80&w=1080", aiHint: "kids fashion" },
  { name: "Shoes", icon: Footprints, link: "/retailer/products?category=shoes", image: "https://images.unsplash.com/photo-1529810313688-44ea1c2d81d3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxMHx8bGVhdGhlciUyMHRleHR1cmV8ZW58MHx8fHwxNzUwOTQ1MTI2fDA&ixlib=rb-4.1.0&q=80&w=1080", aiHint:"shoes footwear" },
  { name: "Accessories", icon: Watch, link: "/retailer/products?category=accessories", image: "https://images.unsplash.com/photo-1618677366787-c02f9a52d6e8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw1fHxmYXNoaW9uJTIwYWNjZXNzb3JpZXN8ZW58MHx8fHwxNzQ5NDc5NjM4fDA&ixlib=rb-4.1.0&q=80&w=1080", aiHint:"fashion accessories" },
  { name: "Bags", icon: ShoppingBag, link: "/retailer/products?category=bags", image: "https://images.unsplash.com/photo-1556935383-b0f5f9ca4100?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw5fHxoYW5kYmFncyUyMGZhc2hpb258ZW58MHx8fHwxNzQ5NTU5NDU0fDA&ixlib=rb-4.1.0&q=80&w=1080", aiHint: "handbags fashion" },
  { name: "Jewelry", icon: Diamond, link: "/retailer/products?category=jewelry", image: "https://images.unsplash.com/photo-1598560917807-1bae44bd2be8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxqZXdlbHJ5JTIwZ29sZHxlbnwwfHx8fDE3NDk0Nzk2Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080", aiHint:"jewelry gold" },
  { name: "Cosmetics", icon: SprayCan, link: "/retailer/products?category=cosmetics", image: "https://images.unsplash.com/photo-1521840233161-295ed621e056?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw5fHxjb3NtZXRpY3MlMjBtYWtldXB8ZW58MHx8fHwxNzQ5NDc5NjM4fDA&ixlib=rb-4.1.0&q=80&w=1080", aiHint:"cosmetics makeup" },
  { name: "Outerwear", icon: Shirt, link: "/retailer/products?category=outerwear", image: "https://images.unsplash.com/photo-1616150840617-a0124ea42a1f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwzfHxqYWNrZXRzJTIwY29hdHN8ZW58MHx8fHwxNzQ5NTU5NDU0fDA&ixlib=rb-4.1.0&q=80&w=1080", aiHint: "jackets coats" },
  { name: "Formal Wear", icon: Shirt, link: "/retailer/products?category=formal-wear", image: "https://images.unsplash.com/photo-1601653311133-9789564fa789?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw1fHxmb3JtYWwlMjBkcmVzc3xlbnwwfHx8fDE3NDk1NTk0NTR8MA&ixlib=rb-4.1.0&q=80&w=1080", aiHint: "formal dress" },
  { name: "Activewear", icon: Dumbbell, link: "/retailer/products?category=activewear", image: "https://images.unsplash.com/photo-1637666544359-0e88de7b3206?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw4fHxhY3RpdmV3ZWFyJTIwc3BvcnRzd2VhcnxlbnwwfHx8fDE3NDk1NTk0NTN8MA&ixlib.rb-4.1.0&q=80&w=1080", aiHint: "activewear sportswear" },
];

const rawMaterialCategories = [
  { name: "Fabrics", icon: Layers, link: "/retailer/products?category=raw-materials&subCategory=Fabrics", image: "https://images.unsplash.com/photo-1705493253575-e911888621ff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw1fHx0ZXh0aWxlJTIwZmFicmljc3xlbnwwfHx8fDE3NTA5NDUxMjZ8MA&ixlib=rb-4.1.0&q=80&w=1080", aiHint:"textile fabrics" },
  { name: "Leather", icon: Layers, link: "/retailer/products?category=raw-materials&subCategory=Leather", image: "https://images.unsplash.com/photo-1585314062604-1a357de8b000?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxMHx8bGVhdGhlciUyMHRleHR1cmV8ZW58MHx8fHwxNzUwOTQ1MTI2fDA&ixlib=rb-4.1.0&q=80&w=1080", aiHint:"leather texture" },
  { name: "Buttons & Zippers", icon: Scissors, link: "/retailer/products?category=raw-materials&subCategory=Notions", image: "https://images.unsplash.com/photo-1563891510473-18923cd29239?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw1fHxzZXdpbmclMjBidXR0b25zfGVufDB8fHx8MTc1MDk0NTEyNnww&ixlib.rb-4.1.0&q=80&w=1080", aiHint:"sewing buttons" },
  { name: "Threads & Yarns", icon: Layers, link: "/retailer/products?category=raw-materials&subCategory=Yarns%20%26%20Threads", image: "https://images.unsplash.com/photo-1711318510657-e626bb0c8068?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxzcG9vbHMlMjB0aHJlYWR8ZW58MHx8fHwxNzUwOTQ1MTI3fDA&ixlib.rb-4.1.0&q=80&w=1080", aiHint:"spools thread" },
  { name: "Dyes & Chemicals", icon: Palette, link: "/retailer/products?category=raw-materials&subCategory=Dyes%20%26%20Chemicals", image: "https://images.unsplash.com/photo-1660490025500-e49fa2f64d0e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxmYWJyaWMlMjBkeWVzfGVufDB8fHx8MTc1MDk0NTEyNnww&ixlib.rb-4.1.0&q=80&w=1080", aiHint:"fabric dyes" },
  { name: "Packaging Materials", icon: Package, link: "/retailer/products?category=raw-materials&subCategory=Packaging%20Materials", image: "https://images.unsplash.com/photo-1686632800715-b705ba1b0eb6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw4fHxlY28lMjBwYWNrYWdpbmd8ZW58MHx8fHwxNzUwOTQ1MTI2fDA&ixlib.rb-4.1.0&q=80&w=1080", aiHint:"eco packaging" },
  { name: "Embellishments & Trims", icon: Sparkles, link: "/retailer/products?category=raw-materials&subCategory=Notions", image: "https://images.unsplash.com/photo-1745091947310-ff0af5e7c38c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw4fHxiZWFkcyUyMGxhY2V8ZW58MHx8fHwxNzUwOTQ1MTI2fDA&ixlib.rb-4.1.0&q=80&w=1080", aiHint:"beads lace" },
  { name: "Interlinings & Linings", icon: Layers, link: "/retailer/products?category=raw-materials&subCategory=Fabrics", image: "https://images.unsplash.com/photo-1722612701446-b0aaa51fae77?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw3fHxmYWJyaWMlMjBsaW5pbmd8ZW58MHx8fHwxNzUwOTQ1MTI2fDA&ixlib.rb-4.1.0&q=80&w=1080", aiHint:"fabric lining" },
  { name: "Labels & Tags", icon: Tag, link: "/retailer/products?category=raw-materials&subCategory=Labels%20%26%20Tags", image: "https://images.unsplash.com/photo-1628019672181-2d3f62401f2f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw0fHxjbG90aGluZyUyMGxhYmVsc3xlbnwwfHx8fDE3NTA5NDUxMjZ8MA&ixlib.rb-4.1.0&q=80&w=1080", aiHint:"clothing labels" },
  { name: "Patterns & Tools", icon: Scaling, link: "/retailer/products?category=raw-materials&subCategory=Patterns%20%26%20Tools", image: "https://images.unsplash.com/photo-1634626857321-deb416dcdb00?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxzZXdpbmclMjBwYXR0ZXJuc3xlbnwwfHx8fDE3NTA5NDUxMjZ8MA&ixlib.rb-4.1.0&q=80&w=1080", aiHint:"sewing patterns" },
];

const CategoryCard = ({ category }: { category: { name: string, icon: React.ElementType, link: string, image: string, aiHint: string }}) => {
    const Icon = category.icon;
    return (
        <Link href={category.link} key={category.name}>
          <Card className="text-center hover:shadow-xl transition-shadow duration-300 group overflow-hidden">
            <CardHeader className="p-0">
                <div className="relative w-full h-40">
                    <Image src={category.image} alt={category.name} layout="fill" objectFit="cover" className="transition-transform duration-300 group-hover:scale-105" data-ai-hint={category.image ? category.aiHint : undefined}/>
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                         <Icon className="h-10 w-10 text-white mb-2" />
                    </div>
                </div>
            </CardHeader>
            <CardContent className="p-4">
              <CardTitle className="text-md font-medium group-hover:text-primary cursor-pointer">{category.name}</CardTitle>
            </CardContent>
          </Card>
        </Link>
    )
};

function RetailerCategoriesContent() {
  const searchParams = useSearchParams();
  const tab = searchParams.get('tab') || 'products';
  
  return (
    <div className="space-y-6">
      <Tabs defaultValue={tab} className="w-full">
        <div className="space-y-4 sm:flex sm:items-center sm:justify-between sm:space-y-0">
            <h1 className="text-3xl font-headline font-semibold text-center sm:text-left">Browse Categories</h1>
            <TabsList className="grid w-full grid-cols-2 md:w-auto">
                <TabsTrigger value="products" className="px-6">Products</TabsTrigger>
                <TabsTrigger value="raw-materials" className="px-6">Raw Materials</TabsTrigger>
            </TabsList>
        </div>
        <TabsContent value="products" className="pt-6">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
                {productCategories.map(category => (
                    <CategoryCard key={category.name} category={category} />
                ))}
            </div>
        </TabsContent>
        <TabsContent value="raw-materials" className="pt-6">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
                {rawMaterialCategories.map(category => (
                    <CategoryCard key={category.name} category={category} />
                ))}
            </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function RetailerCategoriesPage() {
  return (
    <Suspense fallback={<div className="flex justify-center py-20"><Loader2 className="animate-spin h-10 w-10 text-primary" /></div>}>
      <RetailerCategoriesContent />
    </Suspense>
  );
}
