
"use client";
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Package, Truck, CheckCircle, XCircle, ArrowRight, FileText, ChevronRight, Clock, Box } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { Badge } from '@/components/ui/badge';
import { OrderStatusTimeline } from '@/components/OrderStatusTimeline';
import { cn } from '@/lib/utils';

// Define the core types for the Retailer Procurement System
export type OrderStatus = "Pending" | "Processing" | "Shipped" | "Delivered" | "Completed" | "Cancelled";

export interface OrderItem {
  id: string;
  name: string;
  sku: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  image: string;
  aiHint: string;
  variant?: string;
}

export interface Order {
  id: string;
  date: string;
  vendorName: string;
  status: OrderStatus;
  totalAmount: number;
  items: OrderItem[];
  shippingAddress: {
    name: string;
    businessName?: string;
    phone: string;
    addressLine1: string;
    city: string;
    state: string;
    zip: string;
    country: string;
  };
  paymentMethod: string;
  shippingMethod: string;
}

// Global mock data for retailer orders
export const mockOrders: Order[] = [
  {
    id: 'ORD6127',
    date: '2024-07-28',
    vendorName: 'Global Manufacturing Corp',
    status: 'Processing',
    totalAmount: 716.95,
    items: [
      {
        id: '1',
        name: 'Elegant Evening Gown',
        sku: 'LSB-1',
        quantity: 5,
        unitPrice: 129.99,
        totalPrice: 649.95,
        image: 'https://images.unsplash.com/photo-1589083133356-aa13ceaef7fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw3fHxldmVuaW5nJTIwZ293bnxlbnwwfHx8fDE3NDkzMzY1NzZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
        aiHint: "evening gown",
        variant: "Size: M, Color: Burgundy"
      }
    ],
    shippingAddress: {
      name: 'Jane Doe',
      businessName: 'Elegance Retail Ltd',
      phone: '+880 1711-223344',
      addressLine1: 'House 12, Road 5, Block C',
      city: 'Dhaka',
      state: 'Dhaka Division',
      zip: '1212',
      country: 'Bangladesh'
    },
    paymentMethod: 'Visa **** 1234',
    shippingMethod: 'Express Freight'
  },
  {
    id: 'ORD5982',
    date: '2024-07-25',
    vendorName: 'Denim Dreams Factory',
    status: 'Shipped',
    totalAmount: 1450.00,
    items: [
      {
        id: '2',
        name: 'Slim Fit Jeans',
        sku: 'LSB-2',
        quantity: 20,
        unitPrice: 70.00,
        totalPrice: 1400.00,
        image: 'https://images.unsplash.com/photo-1551024559-d69bcf67d8d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw0fHxzbGltJTIwamVhbnN8ZW58MHx8fHwxNzQ5MjE1NzAwfDA&ixlib=rb-4.1.0&q=80&w=1080',
        aiHint: 'slim jeans',
        variant: 'Dark Wash, Size 32'
      }
    ],
    shippingAddress: {
      name: 'Jane Doe',
      phone: '+880 1711-223344',
      addressLine1: 'House 12, Road 5, Block C',
      city: 'Dhaka',
      state: 'Dhaka Division',
      zip: '1212',
      country: 'Bangladesh'
    },
    paymentMethod: 'Bank Transfer',
    shippingMethod: 'Standard Freight'
  }
];

const StatusIcon = ({ status }: { status: OrderStatus }) => {
  const iconClass = "h-3.5 w-3.5 mr-1.5";
  switch (status) {
    case "Pending": return <Clock className={cn(iconClass, "text-yellow-500")} />;
    case "Processing": return <Box className={cn(iconClass, "text-blue-500")} />;
    case "Shipped": return <Truck className={cn(iconClass, "text-purple-500")} />;
    case "Delivered": case "Completed": return <CheckCircle className={cn(iconClass, "text-green-500")} />;
    case "Cancelled": return <XCircle className={cn(iconClass, "text-red-500")} />;
    default: return <Package className={cn(iconClass, "text-gray-500")} />;
  }
};

const OrderManifestCard = ({ order }: { order: Order }) => (
  <Card className="rounded-3xl border shadow-sm overflow-hidden flex flex-col group transition-all hover:border-primary/20 bg-card">
    <CardHeader className="p-5 pb-4 border-b border-dashed bg-muted/10">
      <div className="flex justify-between items-start">
        <div className="space-y-1">
            <CardTitle className="text-sm font-black uppercase tracking-tight">#{order.id}</CardTitle>
            <p className="text-[9px] font-black uppercase text-muted-foreground tracking-widest flex items-center gap-1">
                <Clock className="h-2.5 w-2.5" /> {order.date}
            </p>
        </div>
        <Badge variant="outline" className="rounded-full text-[8px] font-black uppercase tracking-widest px-2.5 py-1 bg-background border-zinc-200 shadow-sm flex items-center">
            <StatusIcon status={order.status} />
            {order.status}
        </Badge>
      </div>
      <div className="mt-3">
          <p className="text-[8px] font-black uppercase text-muted-foreground tracking-[0.1em]">Manufacturing Partner</p>
          <p className="text-[11px] font-bold text-primary truncate">{order.vendorName}</p>
      </div>
    </CardHeader>
    <CardContent className="p-5 pt-4 space-y-4 flex-grow">
      <div className="flex items-center gap-2">
        {order.items.slice(0, 4).map((item, index) => (
            <div key={index} className="relative h-10 w-8 rounded-lg overflow-hidden border bg-muted flex-shrink-0">
                <Image src={item.image} alt={item.name} fill className="object-cover" data-ai-hint={item.aiHint}/>
            </div>
        ))}
        {order.items.length > 4 && (
            <div className="h-10 w-8 rounded-lg bg-secondary flex items-center justify-center text-[9px] font-black border border-dashed">
                +{order.items.length - 4}
            </div>
        )}
      </div>
      
      {(order.status === 'Processing' || order.status === 'Shipped' || order.status === 'Delivered' || order.status === 'Completed') && (
          <div className="pt-2">
            <OrderStatusTimeline currentStatus={order.status} className="px-0 scale-90 -mx-4" />
          </div>
      )}
    </CardContent>
    <CardFooter className="p-4 border-t bg-muted/5 flex justify-between items-center">
        <div className="space-y-0.5">
            <p className="text-[8px] font-black uppercase text-muted-foreground tracking-widest">Manifest Value</p>
            <p className="font-black text-primary text-base tracking-tighter">${order.totalAmount.toFixed(2)}</p>
        </div>
        <Button variant="default" size="sm" className="h-10 px-4 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-md bg-zinc-900 hover:bg-zinc-800" asChild>
          <Link href={`/retailer/orders/${order.id}`}>
            Details <ChevronRight className="ml-1 h-3.5 w-3.5"/>
          </Link>
        </Button>
    </CardFooter>
  </Card>
);

export default function RetailerOrdersPage() {
  const orderStatuses: OrderStatus[] = ["Processing", "Shipped", "Delivered", "Cancelled", "Completed"];
  const [currentTab, setCurrentTab] = useState<string>("Processing");

  const filteredOrders = mockOrders.filter(order => order.status === currentTab);

  return (
    <div className="space-y-6 max-w-xs mx-auto px-1 pb-24 animate-in fade-in duration-500">
      <div className="space-y-1">
        <h1 className="text-2xl font-headline font-black tracking-tight">Procurement Logs</h1>
        <p className="text-[10px] text-muted-foreground uppercase font-black tracking-[0.3em]">Fulfillment OS v4.1</p>
      </div>

      <Tabs value={currentTab} onValueChange={setCurrentTab} className="w-full">
        <TabsList className="flex w-full overflow-x-auto whitespace-nowrap no-scrollbar h-auto bg-muted/30 p-1 rounded-2xl border mb-6">
          {orderStatuses.map(status => (
            <TabsTrigger 
                key={status} 
                value={status}
                className="flex-shrink-0 px-4 py-2 text-[9px] font-black uppercase tracking-widest rounded-xl data-[state=active]:bg-primary data-[state=active]:text-primary-foreground transition-all"
            >
              {status}
            </TabsTrigger>
          ))}
        </TabsList>
        
        {orderStatuses.map(status => (
          <TabsContent key={status} value={status} className="outline-none space-y-4">
            <div className="flex items-center justify-between border-b border-dashed border-primary/10 pb-2 px-1">
                <h2 className="text-[9px] font-black uppercase tracking-[0.4em] text-muted-foreground/60">{status} Manifests</h2>
                <Badge variant="outline" className="text-[8px] font-black rounded-full px-2 py-0.5 border-primary/20 text-primary bg-primary/5">
                    {filteredOrders.length} ITEMS
                </Badge>
            </div>
            
            {filteredOrders.length > 0 ? (
                <div className="space-y-5">
                    {filteredOrders.map(order => <OrderManifestCard key={order.id} order={order} />)}
                </div>
            ) : (
                <Card className="rounded-[2rem] border-2 border-dashed bg-muted/10">
                    <CardContent className="py-20 text-center">
                        <Box className="h-10 w-10 text-muted-foreground mx-auto mb-3 opacity-10" />
                        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground/40">
                            No manifests in this phase
                        </p>
                    </CardContent>
                </Card>
            )}
          </TabsContent>
        ))}
      </Tabs>

      <style jsx global>{`
        .no-scrollbar::-webkit-scrollbar {
            display: none;
        }
        .no-scrollbar {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}
