"use client";

import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { mockOrders, type Order, type OrderItem } from '../page'; 
import { ArrowLeft, Package, Truck, CheckCircle, XCircle, ShoppingBag, CreditCard, MapPin, FileText, ChevronRight, Calculator, Building, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { OrderStatusTimeline } from '@/components/OrderStatusTimeline';
import { cn } from '@/lib/utils';

const StatusBadge = ({ status }: { status: Order['status'] }) => {
  let IconComponent = Package;
  let colorClasses = "bg-zinc-100 text-zinc-700";

  switch (status) {
    case "Pending": IconComponent = Package; colorClasses = "bg-yellow-100 text-yellow-800"; break;
    case "Processing": IconComponent = Truck; colorClasses = "bg-blue-100 text-blue-800 border-blue-200"; break;
    case "Shipped": IconComponent = Truck; colorClasses = "bg-purple-100 text-purple-800 border-purple-200"; break;
    case "Delivered": IconComponent = CheckCircle; colorClasses = "bg-green-100 text-green-800 border-green-200"; break;
    case "Completed": IconComponent = ShoppingBag; colorClasses = "bg-green-100 text-green-800"; break;
    case "Cancelled": IconComponent = XCircle; colorClasses = "bg-red-100 text-red-800"; break;
  }

  return (
    <Badge variant="outline" className={cn("text-[9px] font-black uppercase tracking-widest px-2.5 py-1 rounded-full border shadow-sm", colorClasses)}>
      <IconComponent className="h-3 w-3 mr-1.5" />
      {status}
    </Badge>
  );
};

const OrderItemCard = ({ item }: { item: OrderItem }) => (
  <Card className="rounded-3xl border shadow-sm overflow-hidden flex flex-col p-4 gap-4 bg-card">
    <div className="flex items-center gap-4">
      <div className="relative h-20 w-16 rounded-2xl overflow-hidden bg-muted flex-shrink-0 border">
          <Image src={item.image} alt={item.name} fill className="object-cover" data-ai-hint={item.aiHint} />
      </div>
      <div className="flex-1 min-w-0">
          <h4 className="font-bold text-sm truncate">{item.name}</h4>
          <p className="text-[9px] text-muted-foreground font-black uppercase tracking-widest mt-1">SKU: {item.sku}</p>
          {item.variant && <p className="text-[10px] text-zinc-500 font-bold mt-0.5">{item.variant}</p>}
      </div>
    </div>
    <div className="flex items-center justify-between pt-2 border-t border-dashed">
        <p className="text-[10px] font-bold text-muted-foreground uppercase">{item.quantity} Units @ ${item.unitPrice.toFixed(2)}</p>
        <p className="text-sm font-black text-primary">${item.totalPrice.toFixed(2)}</p>
    </div>
  </Card>
);

export default function RetailerOrderDetailPage() {
  const router = useRouter();
  const params = useParams();
  const orderId = params.orderId as string;
  const { toast } = useToast();

  const [order, setOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!orderId) return;
    const foundOrder = mockOrders.find(o => o.id === orderId);
    if (foundOrder) {
      setOrder(foundOrder);
    } else {
      toast({ title: "Order Not Found", description: "The requested order could not be found.", variant: "destructive" });
      router.replace('/retailer/orders');
    }
    setIsLoading(false);
  }, [orderId, router, toast]);

  if (isLoading) {
    return (
      <div className="space-y-6 max-w-xs mx-auto animate-in fade-in duration-500">
          <div className="h-10 w-10 rounded-full bg-muted animate-pulse" />
          <div className="h-48 w-full rounded-[2.5rem] bg-muted animate-pulse" />
          <div className="h-20 w-full rounded-2xl bg-muted animate-pulse" />
      </div>
    );
  }

  if (!order) return null; 
  
  const subtotal = order.items.reduce((sum, item) => sum + item.totalPrice, 0);
  const tax = order.totalAmount * 0.08;
  const shipping = (order.totalAmount - subtotal - tax > 0) ? (order.totalAmount - subtotal - tax) : 15.00;
  const vendorSlug = order.vendorName.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]/g, '');

  return (
    <div className="space-y-6 max-w-xs mx-auto px-1 pb-24 animate-in fade-in duration-500">
      <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => router.back()} className="rounded-full h-10 w-10 border-zinc-200 shadow-sm">
              <ArrowLeft className="h-5 w-5 text-zinc-600" />
          </Button>
          <div>
              <h1 className="text-xl font-headline font-black tracking-tight">Order Details</h1>
              <p className="text-[10px] text-muted-foreground uppercase font-black tracking-[0.2em]">Manifest OS v4.1</p>
          </div>
      </div>

      <Card className="rounded-[2rem] border shadow-md overflow-hidden bg-card transition-all ring-1 ring-zinc-200/50">
        <CardHeader className="p-6 pb-4 bg-muted/10 border-b border-dashed">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
                <CardTitle className="text-base font-black uppercase tracking-tight">#{order.id}</CardTitle>
                <div className="flex items-center gap-1.5 text-[9px] font-black uppercase text-muted-foreground tracking-widest">
                    <Clock className="h-3 w-3" /> {order.date}
                </div>
            </div>
            <StatusBadge status={order.status} />
          </div>
          <div className="pt-4 flex items-center gap-3">
               <div className="h-8 w-8 rounded-xl bg-primary/10 flex items-center justify-center">
                   <Building className="h-4 w-4 text-primary" />
               </div>
               <div className="min-w-0">
                    <p className="text-[8px] font-black uppercase text-muted-foreground tracking-[0.1em]">Manufacturing Partner</p>
                    <Link href={`/retailer/vendors/${vendorSlug}`} className="text-xs font-black text-primary hover:underline truncate block">{order.vendorName}</Link>
               </div>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <OrderStatusTimeline currentStatus={order.status} />
        </CardContent>
      </Card>

      <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
              <h2 className="text-[10px] font-black uppercase tracking-[0.3em] text-muted-foreground">Batch Units ({order.items.length})</h2>
          </div>
          <div className="space-y-3">
              {order.items.map(item => <OrderItemCard key={item.id} item={item} />)}
          </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
            <h2 className="text-[10px] font-black uppercase tracking-[0.3em] text-muted-foreground">Terminal Details</h2>
        </div>
        <Card className="rounded-3xl border shadow-sm overflow-hidden bg-card">
            <CardHeader className="p-5 pb-2">
                <div className="flex items-center gap-3">
                    <div className="h-9 w-9 rounded-2xl bg-zinc-100 flex items-center justify-center">
                        <MapPin className="h-4 w-4 text-zinc-600" />
                    </div>
                    <span className="text-[10px] font-black uppercase tracking-widest text-zinc-800">Destination Hub</span>
                </div>
            </CardHeader>
            <CardContent className="px-6 pb-6 pt-2 space-y-1">
                <p className="text-xs font-black text-foreground">{order.shippingAddress.name}</p>
                <p className="text-[11px] font-medium text-muted-foreground leading-relaxed">
                    {order.shippingAddress.addressLine1}<br/>
                    {order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zip}<br/>
                    {order.shippingAddress.country}
                </p>
            </CardContent>
        </Card>

         <Card className="rounded-3xl border shadow-sm overflow-hidden bg-card">
            <CardHeader className="p-5 pb-2">
                <div className="flex items-center gap-3">
                    <div className="h-9 w-9 rounded-2xl bg-zinc-100 flex items-center justify-center">
                        <CreditCard className="h-4 w-4 text-zinc-600" />
                    </div>
                    <span className="text-[10px] font-black uppercase tracking-widest text-zinc-800">Authorization</span>
                </div>
            </CardHeader>
            <CardContent className="px-6 pb-6 pt-2">
                <p className="text-xs font-black text-foreground">{order.paymentMethod}</p>
                <p className="text-[11px] font-medium text-muted-foreground mt-1">{order.shippingMethod}</p>
            </CardContent>
        </Card>
      </div>

      <Card className="rounded-[2.5rem] bg-zinc-900 text-white border-none shadow-2xl overflow-hidden relative">
          <CardHeader className="p-8 pb-4">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <Calculator className="h-5 w-5 text-primary" />
                    <CardTitle className="text-[10px] uppercase font-black tracking-[0.3em] text-zinc-500">Ledger Summary</CardTitle>
                </div>
                <Badge variant="outline" className="rounded-full text-[8px] font-black uppercase text-zinc-600 border-zinc-800 tracking-widest">FINALIZED</Badge>
            </div>
          </CardHeader>
          <CardContent className="px-8 pb-8 space-y-4">
              <div className="space-y-3 pb-4 border-b border-white/5">
                <div className="flex justify-between text-[11px] font-black uppercase tracking-widest text-zinc-300">
                    <span>Net Subtotal</span>
                    <span className="text-white">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-[11px] font-black uppercase tracking-widest text-zinc-300">
                    <span>Logistic Freight</span>
                    <span className="text-white">${shipping.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-[11px] font-black uppercase tracking-widest text-zinc-300">
                    <span>Compliance Tax</span>
                    <span className="text-white">${tax.toFixed(2)}</span>
                </div>
              </div>
              <div className="flex justify-between items-center pt-2">
                  <span className="text-[12px] font-black uppercase tracking-[0.2em] text-zinc-200">Grand Total</span>
                  <span className="text-3xl font-black text-white tracking-tighter">${order.totalAmount.toFixed(2)}</span>
              </div>
          </CardContent>
      </Card>
      
      <style jsx global>{`
        .no-scrollbar::-webkit-scrollbar {
            display: none;
        }
        .no-scrollbar {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}
