
"use client";

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, ShoppingBag } from 'lucide-react';
import Link from 'next/link';

export default function OrderConfirmationPage() {
  const router = useRouter();
  const [orderId, setOrderId] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const lastOrderId = localStorage.getItem('lastOrderId');
      if (lastOrderId) {
        setOrderId(lastOrderId);
        // Optionally clear it if it's a one-time display
        // localStorage.removeItem('lastOrderId'); 
      } else {
        // Redirect if no order ID is found, perhaps to orders page or home
        router.replace('/retailer/orders');
      }
    }
  }, [router]);

  if (!orderId) {
    return <div className="flex items-center justify-center min-h-screen"><p>Loading confirmation...</p></div>;
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-10rem)] py-12 text-center">
      <Card className="w-full max-w-lg shadow-xl">
        <CardHeader>
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-green-100 mb-4">
            <CheckCircle className="h-10 w-10 text-green-600" />
          </div>
          <CardTitle className="text-3xl font-headline">Thank you for your order!</CardTitle>
          <CardDescription className="text-lg text-muted-foreground">
            Your order <span className="font-semibold text-primary">#{orderId}</span> has been placed successfully.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>You will receive an email confirmation shortly with your order details and tracking information once it ships.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-6">
            <Button size="lg" asChild>
              <Link href={`/retailer/orders/${orderId}`}>View Order Details</Link>
            </Button>
            <Button variant="outline" size="lg" asChild>
              <Link href="/retailer">
                <ShoppingBag className="mr-2 h-5 w-5" /> Continue Shopping
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
