
"use client";

import React from 'react';
import { Button } from '@/components/ui/button';
import LadookLogo from '@/components/LadookLogo';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { 
    TrendingUp, ShieldCheck, Zap, Bot, 
    Landmark, Globe, Users, ArrowRight, 
    Target, BarChart3, Download, Mail,
    Briefcase, FileText, CheckCircle2, ChevronRight
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import Link from 'next/link';

const ProposalSection = ({ title, icon: Icon, children, badge }: { title: string, icon: any, children: React.ReactNode, badge?: string }) => (
    <Card className="rounded-[2rem] border shadow-lg overflow-hidden bg-card">
        <CardHeader className="p-8 pb-4 border-b bg-muted/10 border-dashed">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <div className="h-10 w-10 rounded-2xl bg-primary/10 flex items-center justify-center">
                        <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <CardTitle className="text-xl font-headline font-black uppercase tracking-tight">{title}</CardTitle>
                </div>
                {badge && <Badge className="bg-primary text-white rounded-full font-black text-[10px] uppercase">{badge}</Badge>}
            </div>
        </CardHeader>
        <CardContent className="p-8 space-y-6">
            {children}
        </CardContent>
    </Card>
);

export default function BusinessProposalPage() {
    return (
        <div className="bg-background min-h-screen text-foreground selection:bg-primary/10">
            {/* Professional Navigation */}
            <nav className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
                <div className="container mx-auto h-16 flex items-center justify-between px-6">
                    <LadookLogo size="small" />
                    <div className="flex items-center gap-4">
                        <Button variant="ghost" size="sm" className="hidden md:flex font-bold text-xs uppercase tracking-widest" onClick={() => window.print()}>
                            <Download className="mr-2 h-4 w-4" /> Export PDF
                        </Button>
                        <Button size="sm" className="rounded-full bg-primary font-black text-xs uppercase tracking-widest px-6 h-10 shadow-lg">
                            Contact Founder
                        </Button>
                    </div>
                </div>
            </nav>

            <main className="container mx-auto max-w-4xl py-12 px-6 space-y-12">
                
                {/* Hero Header */}
                <div className="text-center space-y-4 py-12">
                    <Badge variant="outline" className="rounded-full border-primary/20 text-primary bg-primary/5 px-4 py-1 text-[10px] font-black uppercase tracking-[0.3em]">
                        Investment Memorandum
                    </Badge>
                    <h1 className="text-5xl md:text-6xl font-headline font-black tracking-tighter leading-none">
                        The Operating System for <span className="text-primary italic">Global Fashion.</span>
                    </h1>
                    <p className="text-muted-foreground text-lg font-medium max-w-2xl mx-auto leading-relaxed">
                        Redefining the B2B supply chain through AI-native design, vetted manufacturing, and data-driven microfinance.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card className="rounded-3xl p-6 bg-zinc-900 text-white border-none shadow-xl flex flex-col justify-between">
                        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500">Stage</p>
                        <p className="text-2xl font-black mt-2">PRE-SEED</p>
                        <Badge className="bg-primary/20 text-white border-none mt-4 self-start">Active Round</Badge>
                    </Card>
                    <Card className="rounded-3xl p-6 bg-zinc-100 border-none shadow-sm flex flex-col justify-between">
                        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-400">Target Raise</p>
                        <p className="text-2xl font-black mt-2 text-zinc-800">$500,000</p>
                        <p className="text-[10px] font-bold text-zinc-500 mt-4 uppercase">Convertible Note</p>
                    </Card>
                    <Card className="rounded-3xl p-6 bg-primary/5 border border-primary/10 shadow-sm flex flex-col justify-between">
                        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-primary/60">Beachhead</p>
                        <p className="text-2xl font-black mt-2 text-primary">BANGLADESH</p>
                        <p className="text-[10px] font-bold text-primary/60 mt-4 uppercase">Direct Port Access</p>
                    </Card>
                </div>

                <ProposalSection title="Executive Summary" icon={Zap} badge="Vision">
                    <p className="text-lg font-medium leading-relaxed italic text-muted-foreground">
                        "The multi-trillion dollar fashion industry runs on a chaotic mix of spreadsheets and WhatsApp. Ladook provides the unified infrastructure to manifest designs into global inventory."
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
                        <div className="space-y-3">
                            <h4 className="text-xs font-black uppercase tracking-widest text-primary">Market Dynamics</h4>
                            <p className="text-sm leading-relaxed">The $1.7T apparel market is shifting from mass production to agile, decentralized procurement. Small boutiques (the "Mid-Tail") are underserved by legacy players.</p>
                        </div>
                        <div className="space-y-3">
                            <h4 className="text-xs font-black uppercase tracking-widest text-primary">The Ladook Edge</h4>
                            <p className="text-sm leading-relaxed">Our SaaS-enabled Marketplace acts as the "Trust Bridge," providing the tech-pack, the factory, and the capital to scale operations.</p>
                        </div>
                    </div>
                </ProposalSection>

                <ProposalSection title="Product Roadmap" icon={Bot} badge="Core Tech">
                    <div className="space-y-8">
                        <div className="flex gap-6 items-start">
                            <div className="h-12 w-12 rounded-2xl bg-zinc-100 flex items-center justify-center shrink-0">
                                <Palette className="h-6 w-6 text-zinc-600" />
                            </div>
                            <div>
                                <h4 className="font-black text-sm uppercase">AI Design Studio (Launched)</h4>
                                <p className="text-sm text-muted-foreground mt-1">Shortening sample cycles by 70%. AI generates production-ready blueprints from descriptive vision statements.</p>
                            </div>
                        </div>
                        <div className="flex gap-6 items-start">
                            <div className="h-12 w-12 rounded-2xl bg-zinc-100 flex items-center justify-center shrink-0">
                                <Landmark className="h-6 w-6 text-zinc-600" />
                            </div>
                            <div>
                                <h4 className="font-black text-sm uppercase">Trust Bridge FinTech (Q4 Roadmap)</h4>
                                <p className="text-sm text-muted-foreground mt-1">Unlocking inventory credit using platform performance as technical collateral. Purpose-locked direct-to-vendor disbursement.</p>
                            </div>
                        </div>
                        <div className="flex gap-6 items-start">
                            <div className="h-12 w-12 rounded-2xl bg-zinc-100 flex items-center justify-center shrink-0">
                                <Globe className="h-6 w-6 text-zinc-600" />
                            </div>
                            <div>
                                <h4 className="font-black text-sm uppercase">Logistics Manifest v4.1</h4>
                                <p className="text-sm text-muted-foreground mt-1">Full-stack traceability from factory floor to retail terminal. Integrating real-time port data and customs compliance.</p>
                            </div>
                        </div>
                    </div>
                </ProposalSection>

                <ProposalSection title="Unit Economics" icon={TrendingUp} badge="Growth">
                    <div className="bg-zinc-900 rounded-3xl p-8 text-white space-y-6">
                        <div className="grid grid-cols-2 gap-8">
                            <div className="space-y-1">
                                <p className="text-[10px] font-black uppercase tracking-widest text-zinc-500">Take-Rate</p>
                                <p className="text-3xl font-black">3 - 5%</p>
                                <p className="text-[10px] text-zinc-400 font-medium">Per Transaction</p>
                            </div>
                            <div className="space-y-1">
                                <p className="text-[10px] font-black uppercase tracking-widest text-zinc-500">SaaS MRR</p>
                                <p className="text-3xl font-black">$49.00</p>
                                <p className="text-[10px] text-zinc-400 font-medium">Per Active Vendor</p>
                            </div>
                        </div>
                        <Separator className="bg-white/10" />
                        <div className="space-y-4">
                            <p className="text-[10px] font-black uppercase tracking-widest text-zinc-500">Target Run-Rate (Y1)</p>
                            <div className="flex justify-between items-baseline">
                                <span className="text-4xl font-black tracking-tighter text-primary">$1,000,000+</span>
                                <span className="text-xs font-black uppercase tracking-widest text-zinc-300">Annualized GMV</span>
                            </div>
                        </div>
                    </div>
                </ProposalSection>

                <ProposalSection title="Founding Team" icon={Users} badge="Domain Expertise">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                        <div className="space-y-3">
                            <Avatar className="h-24 w-24 mx-auto border-4 border-background shadow-xl">
                                <AvatarImage src="https://picsum.photos/seed/founder1/200/200" data-ai-hint="ceo founder" />
                                <AvatarFallback>CEO</AvatarFallback>
                            </Avatar>
                            <div>
                                <p className="font-black text-sm uppercase">Founder Name</p>
                                <p className="text-[10px] font-black text-primary uppercase tracking-widest">CEO | Product</p>
                            </div>
                            <p className="text-[10px] text-muted-foreground leading-relaxed font-medium">10+ years tech lead. Family ties to RMG factory hubs.</p>
                        </div>
                        <div className="space-y-3">
                            <Avatar className="h-24 w-24 mx-auto border-4 border-background shadow-xl">
                                <AvatarImage src="https://picsum.photos/seed/founder2/200/200" data-ai-hint="cto founder" />
                                <AvatarFallback>CTO</AvatarFallback>
                            </Avatar>
                            <div>
                                <p className="font-black text-sm uppercase">Co-Founder</p>
                                <p className="text-[10px] font-black text-primary uppercase tracking-widest">CTO | Architecture</p>
                            </div>
                            <p className="text-[10px] text-muted-foreground leading-relaxed font-medium">Ex-Shopify Senior Engineer. Expert in marketplace scale.</p>
                        </div>
                        <div className="space-y-3">
                            <Avatar className="h-24 w-24 mx-auto border-4 border-background shadow-xl">
                                <AvatarImage src="https://picsum.photos/seed/founder3/200/200" data-ai-hint="ops founder" />
                                <AvatarFallback>OPS</AvatarFallback>
                            </Avatar>
                            <div>
                                <p className="font-black text-sm uppercase">Co-Founder</p>
                                <p className="text-[10px] font-black text-primary uppercase tracking-widest">Head of Ops</p>
                            </div>
                            <p className="text-[10px] text-muted-foreground leading-relaxed font-medium">15 years in Dhaka RMG. Deep supply network access.</p>
                        </div>
                    </div>
                </ProposalSection>

                {/* Final Call to Action */}
                <Card className="rounded-[3rem] bg-primary text-white border-none shadow-2xl p-12 text-center space-y-6">
                    <div className="space-y-2">
                        <h2 className="text-4xl font-headline font-black tracking-tight leading-none">Join the Round.</h2>
                        <p className="text-primary-foreground/70 font-medium">Invest in the future of fashion infrastructure.</p>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                        <Button size="lg" className="rounded-2xl h-14 px-10 bg-white text-primary hover:bg-zinc-100 font-black text-sm uppercase">
                            Secure Data Room <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="lg" className="rounded-2xl h-14 px-10 border-white/20 text-white hover:bg-white/10 font-black text-sm uppercase">
                             Contact CEO
                        </Button>
                    </div>
                    <p className="text-[9px] font-black uppercase tracking-[0.4em] opacity-30 pt-4">© 2024 Ladook Platform Inc. Confidential Pre-Seed Presentation.</p>
                </Card>

            </main>

            {/* Bottom Nav Spacer */}
            <div className="h-20" />
            
            <style jsx global>{`
                @media print {
                    .no-print { display: none; }
                    body { background: white; }
                    main { max-width: 100%; padding: 0; }
                    .container { width: 100%; max-width: 100%; }
                }
            `}</style>
        </div>
    );
}
