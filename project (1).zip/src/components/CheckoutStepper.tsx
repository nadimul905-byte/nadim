"use client";

import { cn } from "@/lib/utils";
import { Check, Truck, CreditCard, ShoppingBag } from 'lucide-react';
import React from 'react';

interface CheckoutStepProps {
  step: number;
  label: string;
  isCompleted: boolean;
  isCurrent: boolean;
}

const stepsConfig = [
  { label: "Shipping", icon: Truck },
  { label: "Payment", icon: CreditCard },
  { label: "Review", icon: ShoppingBag },
];

const CheckoutStep: React.FC<CheckoutStepProps> = ({ step, label, isCompleted, isCurrent }) => {
  const Icon = stepsConfig[step - 1].icon;
  return (
    <div className="flex flex-col items-center">
      <div
        className={cn(
          "h-10 w-10 rounded-full flex items-center justify-center border-2 transition-all duration-300",
          isCompleted ? "bg-primary border-primary text-primary-foreground" :
          isCurrent ? "border-primary scale-110" : "bg-muted border-border"
        )}
      >
        {isCompleted ? <Check className="h-6 w-6" /> : <Icon className={cn("h-5 w-5", isCurrent ? "text-primary" : "text-muted-foreground")} />}
      </div>
      <p className={cn(
        "text-xs sm:text-sm font-medium mt-2",
        isCurrent ? "text-primary" : !isCompleted ? "text-muted-foreground" : "text-foreground"
      )}>
        {label}
      </p>
    </div>
  );
};

interface CheckoutStepperProps {
    currentStep: number;
}

export const CheckoutStepper: React.FC<CheckoutStepperProps> = ({ currentStep }) => {
  return (
    <div className="flex justify-between items-start w-full max-w-md mx-auto mb-8">
      {stepsConfig.map((step, index) => {
        const stepNumber = index + 1;
        return (
          <React.Fragment key={step.label}>
            <CheckoutStep
              step={stepNumber}
              label={step.label}
              isCompleted={currentStep > stepNumber}
              isCurrent={currentStep === stepNumber}
            />
            {index < stepsConfig.length - 1 && (
              <div className="flex-1 h-1 bg-border rounded-full mt-5 mx-2 relative overflow-hidden">
                <div
                  className={cn(
                    "absolute top-0 left-0 h-full bg-primary transition-all duration-500",
                    currentStep > stepNumber ? "w-full" : "w-0",
                    currentStep === stepNumber && "w-1/2" 
                  )}
                />
              </div>
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
};
