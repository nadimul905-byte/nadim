import React from 'react';
import { cn } from '@/lib/utils';

interface LadookLogoProps {
  size?: 'small' | 'medium' | 'large';
  className?: string;
}

const LadookLogo: React.FC<LadookLogoProps> = ({ size = 'medium', className = '' }) => {
  let textSizeClass = 'text-4xl';
  if (size === 'small') textSizeClass = 'text-2xl';
  if (size === 'large') textSizeClass = 'text-6xl';

  return (
    <div className={cn('font-headline-script text-primary font-bold', textSizeClass, className)}>
      Ladook
    </div>
  );
};

export default LadookLogo;
