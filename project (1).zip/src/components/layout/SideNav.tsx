"use client";

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import type { NavItem } from './BottomNav'; // Reusing NavItem type
import LadookLogo from '../LadookLogo';

interface SideNavProps {
  navItems: NavItem[];
  role: 'retailer' | 'vendor' | 'admin';
}

export default function SideNav({ navItems, role }: SideNavProps) {
  const pathname = usePathname();

  return (
    <aside className="hidden md:flex md:flex-col md:w-64 md:border-r md:bg-background md:fixed md:inset-y-0">
      <div className="flex items-center h-16 px-6 border-b">
        <LadookLogo size="medium" />
      </div>
      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href || (item.href !== `/${role}` && pathname.startsWith(item.href));
          return (
            <Link
              key={item.label}
              href={item.href}
              className={cn(
                "flex items-center px-3 py-2.5 rounded-md text-sm font-medium hover:bg-muted transition-colors",
                isActive ? "bg-primary text-primary-foreground hover:bg-primary/90" : "text-foreground hover:text-primary"
              )}
            >
              <Icon className={cn("w-5 h-5 mr-3", isActive ? "text-primary-foreground" : "")} />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
