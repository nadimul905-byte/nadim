"use client";

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { Button } from '@/components/ui/button';
import LadookLogo from '../LadookLogo';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Bell, Search, UserCircle, LogOut, Settings as SettingsIcon, ArrowLeft, Palette, LayoutGrid, ShoppingCart } from 'lucide-react';
import { useThemeContext } from '@/app/providers';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';

// Import mock data for notifications
import { notifications as retailerNotificationsData } from '@/app/retailer/notifications/page';
import { mockVendorNotifications } from '@/app/vendor/notifications/page';

const adminPendingApprovals = 5;
const adminOpenDisputes = 2;

interface TopBarProps {
  role: 'retailer' | 'vendor' | 'admin' | 'consumer';
  title?: string;
}

export default function TopBar({ role, title }: TopBarProps) {
  const router = useRouter();
  const pathname = usePathname();
  const { theme, toggleTheme } = useThemeContext();
  const [notificationCount, setNotificationCount] = useState(0);

  const isHomePage = pathname === `/${role}`;
  const showBackButton = !isHomePage && (
    pathname.startsWith(`/${role}/`) && 
    pathname.split('/').length > 3 
  );

  useEffect(() => {
    let count = 0;
    if (role === 'retailer') {
      count = (retailerNotificationsData || []).filter(n => !n.read).length;
    } else if (role === 'vendor') {
      count = (mockVendorNotifications || []).filter(n => !n.read).length;
    } else if (role === 'admin') {
      count = adminPendingApprovals + adminOpenDisputes; 
    } else if (role === 'consumer') {
      count = 2;
    }
    setNotificationCount(count);
  }, [role, pathname]);

  const handleLogout = () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('isAuthenticated');
      localStorage.removeItem('selectedRole');
      localStorage.removeItem('userEmail');
      if (role === 'retailer') localStorage.removeItem('ladookRetailerProfile');
      if (role === 'vendor') localStorage.removeItem('ladookVendorProfile');
    }
    router.push('/auth'); 
  };
  
  const userEmailInitial = typeof window !== 'undefined' ? localStorage.getItem('userEmail')?.charAt(0).toUpperCase() : 'L';

  const handleNotificationClick = () => {
    router.push(`/${role}/notifications`);
  };
  
  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4 sm:px-6 lg:px-8">
        <div className="flex items-center">
          {showBackButton ? (
            <Button variant="ghost" size="icon" onClick={() => router.back()} className="mr-2">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          ) : null}

          {isHomePage ? (
            <Link href={`/${role}`} passHref legacyBehavior>
              <a className="flex items-center cursor-pointer" aria-label={`${role} dashboard home`}>
                <LadookLogo size="small" />
              </a>
            </Link>
          ) : (
            title ? (
              <h1 className="text-xl font-headline font-semibold">{title}</h1>
            ) : (
              <Link href={`/${role}`} passHref legacyBehavior>
                <a className="flex items-center cursor-pointer" aria-label={`${role} dashboard home`}>
                  <LadookLogo size="small" />
                </a>
              </Link>
            )
          )}
        </div>

        <div className="flex items-center space-x-1 sm:space-x-2">
          
          {(role === 'retailer' || role === 'vendor' || role === 'consumer') && (
            <Button variant="ghost" size="icon" onClick={() => router.push(`/${role}/search`)} className="hidden sm:inline-flex">
              <Search className="h-5 w-5" />
              <span className="sr-only">Search</span>
            </Button>
          )}

          {(role === 'vendor' || role === 'retailer') && (
             <Button variant="ghost" size="icon" onClick={() => router.push(`/${role}/social`)}>
              <LayoutGrid className="h-5 w-5" />
              <span className="sr-only">Community Hub</span>
            </Button>
          )}

          {(role === 'retailer' || role === 'consumer') && (
            <Button variant="ghost" size="icon" onClick={() => router.push(`/${role}/cart`)}>
              <ShoppingCart className="h-5 w-5" />
              <span className="sr-only">Cart</span>
            </Button>
          )}
          
          <div className="relative">
            <Button variant="ghost" size="icon" onClick={handleNotificationClick}>
              <Bell className="h-5 w-5" />
              <span className="sr-only">Notifications</span>
            </Button>
            {notificationCount > 0 && (
              <Badge
                variant="destructive"
                className="absolute -top-1.5 -right-1.5 h-5 w-5 min-w-5 p-0 flex items-center justify-center rounded-full text-xs"
              >
                {notificationCount > 9 ? '9+' : notificationCount}
              </Badge>
            )}
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                <Avatar className="h-8 w-8">
                  <AvatarImage src="https://picsum.photos/seed/avatar/40/40" alt="User avatar" data-ai-hint="person avatar" />
                  <AvatarFallback>{userEmailInitial}</AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => router.push(`/${role}/profile`)}>
                <UserCircle className="mr-2 h-4 w-4" />
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => router.push(`/${role}/settings`)}>
                <SettingsIcon className="mr-2 h-4 w-4" />
                Settings
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <div className="p-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="theme-toggle-topbar" className="text-sm">Dark Mode</Label>
                  <Switch
                    id="theme-toggle-topbar"
                    checked={theme === 'dark'}
                    onCheckedChange={toggleTheme}
                  />
                </div>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:text-destructive-foreground focus:bg-destructive">
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
