"use client";

import { cn } from "@/lib/utils";
import { Check, Package, Truck, Home } from 'lucide-react';
import React from 'react';

// Define the possible statuses in a specific order for the timeline
const timelineStatuses = ["Processing", "Shipped", "Delivered", "Completed"] as const;
type TimelineStatus = typeof timelineStatuses[number];

const statusDetails: Record<TimelineStatus, { icon: React.ElementType, label: string }> = {
    "Processing": { icon: Package, label: "Processing" },
    "Shipped": { icon: Truck, label: "Shipped" },
    "Delivered": { icon: Home, label: "Delivered" },
    "Completed": { icon: Check, label: "Completed" },
};

interface OrderStatusTimelineProps {
    currentStatus: string;
    className?: string;
}

export const OrderStatusTimeline: React.FC<OrderStatusTimelineProps> = ({ currentStatus, className }) => {
    // Check if the currentStatus is one of the statuses we can display in the timeline
    const isTrackableStatus = (timelineStatuses as readonly string[]).includes(currentStatus);

    if (!isTrackableStatus) {
        return null; // Don't render anything if the status is not part of the timeline
    }
    
    // Now we know currentStatus is a TimelineStatus
    const currentTimelineStatus = currentStatus as TimelineStatus;
    const currentIndex = timelineStatuses.indexOf(currentTimelineStatus);

    return (
        <div className={cn("flex justify-between items-start text-center w-full px-4 sm:px-8", className)}>
            {timelineStatuses.map((status, index) => {
                const isCompleted = index < currentIndex;
                const isCurrent = index === currentIndex;
                const isFuture = index > currentIndex;

                const Icon = statusDetails[status].icon;

                return (
                    <React.Fragment key={status}>
                        <div className="flex flex-col items-center">
                            <div
                                className={cn(
                                    "h-10 w-10 sm:h-12 sm:w-12 rounded-full flex items-center justify-center border-2 transition-all duration-300",
                                    isCompleted || isCurrent ? "bg-primary border-primary" : "bg-muted border-border",
                                )}
                            >
                                <Icon className={cn("h-5 w-5 sm:h-6 sm:w-6", isCompleted || isCurrent ? "text-primary-foreground" : "text-muted-foreground")} />
                            </div>
                            <p className={cn(
                                "text-xs sm:text-sm font-medium mt-2",
                                isFuture ? "text-muted-foreground" : "text-foreground"
                            )}>
                                {statusDetails[status].label}
                            </p>
                        </div>

                        {index < timelineStatuses.length - 1 && (
                            <div className="flex-1 h-1 bg-border rounded-full mt-5 sm:mt-6 mx-1 sm:mx-2 relative overflow-hidden">
                                <div
                                    className={cn(
                                        "absolute top-0 left-0 h-full bg-primary transition-all duration-500",
                                        isCompleted ? "w-full" : "w-0",
                                        isCurrent && "w-1/2" // Show halfway progress for the current step
                                    )}
                                />
                            </div>
                        )}
                    </React.Fragment>
                );
            })}
        </div>
    );
};
