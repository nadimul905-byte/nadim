
"use client"; // This file might be used in client components

import { useEffect, useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';

export function useAuthProtection(allowedRole?: 'retailer' | 'vendor' | 'admin' | 'consumer') {
  const router = useRouter();
  const pathname = usePathname();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
      const storedRole = localStorage.getItem('selectedRole') as string | null;

      if (!isAuthenticated) {
        const entryFlowPaths = ['/', '/onboarding', '/select-role', '/auth', '/auth/verify'];
        if (!entryFlowPaths.includes(pathname)) {
          if (allowedRole === 'admin') {
            router.replace('/auth?role=admin'); // Redirect to auth with admin role pre-selected
          } else {
            router.replace('/select-role'); 
          }
        } else {
          setIsLoading(false);
        }
        return;
      }

      if (['/onboarding', '/select-role', '/auth', '/auth/verify'].includes(pathname)) {
         if (storedRole) router.replace(`/${storedRole}`);
         else router.replace('/'); 
         return;
      }
      
      if (allowedRole && storedRole !== allowedRole) {
        router.replace(`/${storedRole}` || '/');
        return;
      }
      setIsLoading(false);
    }
  }, [router, pathname, allowedRole]);

  return isLoading;
}
