
// src/lib/mockSocialData.ts

export interface SocialPost {
  id: string;
  vendorName: string;
  vendorSlug: string;
  vendorAvatar: string;
  vendorAvatarAiHint: string;
  timestamp: string;
  postText: string;
  postImage?: string;
  postImageAiHint?: string;
  productId?: string;
  likes: number;
  comments: number;
  status: 'Pending' | 'Approved' | 'Rejected';
}

export const mockSocialFeed: SocialPost[] = [
  {
    id: 'post1',
    vendorName: 'Chic Designs Co.',
    vendorSlug: 'chic-designs-co',
    vendorAvatar: 'https://images.unsplash.com/photo-1590874315261-788881621f7a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwbG9nb3xlbnwwfHx8fDE3NDg4NjUyODl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'fashion logo',
    timestamp: '2h ago',
    postText: 'Just dropped! 🔥 Our new line of Luxury Silk Blouses. Perfect for any occasion. Limited stock available, check them out now!',
    postImage: 'https://images.unsplash.com/photo-1717777917505-5401ba591fe3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw3fHxzaWxrJTIwYmxvdXNlfGVufDB8fHx8fDE3NDg4MTY1MjL8MA&ixlib=rb-4.1.0&q=80&w=1080',
    postImageAiHint: 'silk blouse',
    productId: 'vprod4',
    likes: 152,
    comments: 12,
    status: 'Pending',
  },
  {
    id: 'post2',
    vendorName: 'Denim Dreams',
    vendorSlug: 'denim-dreams',
    vendorAvatar: 'https://images.unsplash.com/photo-1459173422306-0ce3fb37f832?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw2fHxkZW5pbSUyMGJyYW5kfGVufDB8fHx8fDE3NDkyMTU3MDB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'denim brand',
    timestamp: '8h ago',
    postText: 'Behind the scenes! 🧵✨ Getting our new batch of Slim Fit Jeans ready for you. The perfect wash for every season.',
    postImage: 'https://images.unsplash.com/photo-1551024559-d69bcf67d8d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw0fHxzbGltJTIwamVhbnN8ZW58MHx8fHwxNzQ5MjE1NzAwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    postImageAiHint: 'slim jeans',
    productId: 'rp2',
    likes: 230,
    comments: 25,
    status: 'Approved',
  },
  {
    id: 'post3',
    vendorName: 'Ladook',
    vendorSlug: '#',
    vendorAvatar: 'https://placehold.co/40x40.png?text=L',
    vendorAvatarAiHint: 'platform logo',
    timestamp: '1d ago',
    postText: '📢 Platform Announcement: We are excited to welcome 15 new vendors this week! Discover their unique collections in the "New Arrivals" section on the categories page.',
    likes: 540,
    comments: 45,
    status: 'Approved',
  },
   {
    id: 'post4',
    vendorName: 'Summer Styles',
    vendorSlug: 'summer-styles',
    vendorAvatar: 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxzdW1tZXIlMjBmYXNoaW9ufGVufDB8fHx8MTc0OTIxNTcwMHww&ixlib=rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'summer fashion',
    timestamp: '2d ago',
    postText: 'Get ready for the sun! Our Floral Sundresses are back in stock and ready to ship. ☀️',
    postImage: 'https://images.unsplash.com/photo-1491006443886-dab2ec6d0bec?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxMHx8ZmxvcmFsJTIwc3VuZHJlc3N8ZW58MHx8fHwxNzQ5MjE1NzAwfDA&ixlib.rb-4.1.0&q=80&w=1080',
    postImageAiHint: 'floral sundress',
    productId: 'rp7',
    likes: 180,
    comments: 19,
    status: 'Pending',
  },
  {
    id: 'post5',
    vendorName: 'Artisan Leather',
    vendorSlug: 'artisan-leather',
    vendorAvatar: 'https://placehold.co/40x40.png?text=AL',
    vendorAvatarAiHint: 'leather goods',
    timestamp: '3d ago',
    postText: 'The beauty of full-grain leather. Our wallets are built to last and tell a story over time.',
    postImage: 'https://images.unsplash.com/photo-1619454019439-445801e13e51?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxsZWF0aGVyJTIwd2FsbGV0fGVufDB8fHx8MTc1MjM5OTE4N3ww&ixlib.rb-4.1.0&q=80&w=1080',
    postImageAiHint: 'leather wallet',
    productId: 'raw2',
    likes: 310,
    comments: 35,
    status: 'Approved',
  },
  {
    id: 'post6',
    vendorName: 'Pure Glow',
    vendorSlug: 'pure-glow',
    vendorAvatar: 'https://placehold.co/40x40.png?text=PG',
    vendorAvatarAiHint: 'skincare brand',
    timestamp: '4d ago',
    postText: 'Healthy skin is always in. ✨ Our new Hydrating Face Serum is packed with natural ingredients to give you a radiant complexion.',
    postImage: 'https://images.unsplash.com/photo-1631731573295-a5f163a341b5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxmYWNlJTIwc2VydW18ZW58MHx8fHwxNzUyMzk5MTg3fDA&ixlib.rb-4.1.0&q=80&w=1080',
    postImageAiHint: 'face serum',
    productId: 'bought8',
    likes: 250,
    comments: 41,
    status: 'Rejected',
  },
  {
    id: 'post7',
    vendorName: 'Timepiece Trends',
    vendorSlug: 'timepiece-trends',
    vendorAvatar: 'https://images.unsplash.com/photo-1434493651957-4ec11beae249?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw0fHx3YXRjaCUyMGNvbXBhbnl8ZW58MHx8fHwxNzQ5MjE1NzAwfDA&ixlib.rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'watch company',
    timestamp: '5d ago',
    postText: 'Timeless elegance. Our new Minimalist Watch is the perfect accessory for any look. Now available for order.',
    postImage: 'https://images.unsplash.com/photo-1594576722534-ed418b394555?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwzfHxzbWluaW1hbGlzdCUyMHdhdGNofGVufDB8fHx8MTc1MjM5ODcwNnww&ixlib.rb-4.1.0&q=80&w=1080',
    postImageAiHint: 'minimalist watch',
    productId: 'trend7',
    likes: 450,
    comments: 28,
    status: 'Approved',
  },
  {
    id: 'post8',
    vendorName: 'The Modern Gent',
    vendorSlug: 'the-modern-gent',
    vendorAvatar: 'https://placehold.co/40x40.png?text=MG',
    vendorAvatarAiHint: 'menswear',
    timestamp: '5d ago',
    postText: 'Sharp, tailored, and ready for business. The new wool blazer is here to elevate your store\'s collection.',
    postImage: 'https://images.unsplash.com/photo-1617137968427-85924c800a22?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxtZW5zJTIwYmxhemVyfGVufDB8fHx8MTc1MjM5ODcwNnww&ixlib.rb-4.1.0&q=80&w=1080',
    postImageAiHint: 'mens blazer',
    productId: 'trend5',
    likes: 290,
    comments: 22,
    status: 'Pending',
  },
  {
    id: 'post9',
    vendorName: 'Warm Knits Co.',
    vendorSlug: 'warm-knits-co',
    vendorAvatar: 'https://placehold.co/40x40.png?text=WK',
    vendorAvatarAiHint: 'knitwear brand',
    timestamp: '6d ago',
    postText: 'Cozy season is coming! Stock up on our ultra-soft cashmere scarves.',
    postImage: 'https://images.unsplash.com/photo-1533659828814-338b2518e954?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxjYXNobWVyZSUyMHNjYXJmfGVufDB8fHx8MTc1MjM5OTA3MHww&ixlib.rb-4.1.0&q=80&w=1080',
    postImageAiHint: 'cashmere scarf',
    productId: 'view8',
    likes: 380,
    comments: 48,
    status: 'Approved',
  },
  {
    id: 'post10',
    vendorName: 'Ladook',
    vendorSlug: '#',
    vendorAvatar: 'https://placehold.co/40x40.png?text=L',
    vendorAvatarAiHint: 'platform logo',
    timestamp: '1w ago',
    postText: '✨ Tip of the Week: Use high-quality images in your custom requests to get more accurate bids from vendors!',
    likes: 800,
    comments: 65,
    status: 'Approved',
  }
];

export interface SocialReel {
  id: string;
  vendorName: string;
  vendorSlug: string;
  vendorAvatar: string;
  vendorAvatarAiHint: string;
  reelCoverImage: string;
  reelCoverImageAiHint: string;
  caption: string;
  productId?: string;
  likes: number;
  comments: number;
  status: 'Pending' | 'Approved' | 'Rejected';
}

export const mockReels: SocialReel[] = [
  {
    id: 'reel1',
    vendorName: 'Summer Styles',
    vendorSlug: 'summer-styles',
    vendorAvatar: 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxzdW1tZXIlMjBmYXNoaW9ufGVufDB8fHx8MTc0OTIxNTcwMHww&ixlib=rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'summer fashion',
    reelCoverImage: 'https://images.unsplash.com/photo-1542295669297-4d352b042bca?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxzdW1tZXIlMjBkcmVzc3xlbnwwfHx8fDE3NDkyMjAxNTN8MA&ixlib.rb-4.1.0&q=80&w=1080',
    reelCoverImageAiHint: 'summer dress',
    caption: 'Twirl into summer with our new dress collection! ✨',
    productId: 'trend2',
    likes: 1280,
    comments: 45,
    status: 'Approved'
  },
    {
    id: 'reel2',
    vendorName: 'Artisan Leather',
    vendorSlug: 'artisan-leather',
    vendorAvatar: 'https://placehold.co/40x40.png?text=AL',
    vendorAvatarAiHint: 'leather goods',
    reelCoverImage: 'https://images.unsplash.com/photo-1594223274512-ad4803739b7c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxsZWF0aGVyJTIwYmFnJTIwbWFraW5nfGVufDB8fHx8fDE3NTMwNTUwNzJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    reelCoverImageAiHint: 'leather crafting',
    caption: 'The art of craftsmanship. Every stitch tells a story.',
    productId: 'trend4',
    likes: 2400,
    comments: 112,
    status: 'Pending'
  },
  {
    id: 'reel3',
    vendorName: 'Footprint Co.',
    vendorSlug: 'footprint-co',
    vendorAvatar: 'https://placehold.co/40x40.png?text=FC',
    vendorAvatarAiHint: 'shoe brand',
    reelCoverImage: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwc2hvZSUyMHZpZGVvfGVufDB8fHx8fDE3NTMwNTUzOTh8MA&ixlib.rb-4.1.0&q=80&w=1080',
    reelCoverImageAiHint: 'fashion shoes',
    caption: 'Step up your game. New sneaker drop is live!',
    productId: 'trend3',
    likes: 890,
    comments: 32,
    status: 'Approved'
  },
    {
    id: 'reel4',
    vendorName: 'Denim Dreams',
    vendorSlug: 'denim-dreams',
    vendorAvatar: 'https://images.unsplash.com/photo-1459173422306-0ce3fb37f832?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw2fHxkZW5pbSUyMGJyYW5kfGVufDB8fHx8MTc0OTIxNTcwMHww&ixlib.rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'denim brand',
    reelCoverImage: 'https://images.unsplash.com/photo-1565084888279-f368ecce360e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxkZW5pbSUyMHZpZGVvfGVufDB8fHx8MTc1MzA1NTM5OHww&ixlib.rb-4.1.0&q=80&w=1080',
    reelCoverImageAiHint: 'denim style',
    caption: 'Our denim, your story. Find your perfect fit.',
    productId: 'rp2',
    likes: 1500,
    comments: 68,
    status: 'Rejected'
  },
  {
    id: 'reel5',
    vendorName: 'Chic Designs Co.',
    vendorSlug: 'chic-designs-co',
    vendorAvatar: 'https://images.unsplash.com/photo-1590874315261-788881621f7a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwbG9nb3xlbnwwfHx8fDE3NDg4NjUyODl8MA&ixlib.rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'fashion logo',
    reelCoverImage: 'https://images.unsplash.com/photo-1588188165573-3d3958043657?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxzdHlsaXNoJTIwY2xvdGhpbmd8ZW58MHx8fHwxNzUzMDU1NTAzfDA&ixlib.rb-4.1.0&q=80&w=1080',
    reelCoverImageAiHint: 'stylish clothing',
    caption: 'From our studio to your store. A look behind the designs.',
    productId: 'vprod4',
    likes: 950,
    comments: 55,
    status: 'Pending'
  },
    {
    id: 'reel6',
    vendorName: 'Glimmer Gems',
    vendorSlug: 'glimmer-gems',
    vendorAvatar: 'https://images.unsplash.com/photo-1574582242931-e2b1d1f65d4b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwyfHxqZXdlbHJ5JTIwc2hvcHxlbnwwfHx8fDE3NDkyMTU3MDF8MA&ixlib.rb-4.1.0&q=80&w=1080',
    vendorAvatarAiHint: 'jewelry shop',
    reelCoverImage: 'https://images.unsplash.com/photo-1599352431053-d1e991475713?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHwxfHxqZXdlbHJ5JTIwdmlkZW98ZW58MHx8fHwxNzUzMDU1Mzk4fDA&ixlib.rb-4.1.0&q=80&w=1080',
    reelCoverImageAiHint: 'jewelry making',
    caption: 'Shine bright. ✨ Our latest jewelry collection.',
    productId: 'rp5',
    likes: 3100,
    comments: 210,
    status: 'Approved'
  }
];
