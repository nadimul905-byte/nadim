'use server';

/**
 * @fileOverview A Genkit flow for generating marketing scripts for products.
 *
 * This flow uses an LLM to generate a short video script based on product details.
 * - `createMarketingScript`: A function that takes product info and returns a script.
 * - `CreateMarketingScriptInput`: The input type for the function.
 * - `CreateMarketingScriptOutput`: The return type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const CreateMarketingScriptInputSchema = z.object({
  productName: z.string().describe('The name of the product.'),
  productDescription: z.string().describe('A brief description of the product and its key features.'),
  targetAudience: z.string().optional().describe('The intended audience for the marketing video.'),
});
export type CreateMarketingScriptInput = z.infer<typeof CreateMarketingScriptInputSchema>;

const ShotSchema = z.object({
  scene: z.number().describe('The scene number.'),
  visuals: z.string().describe('A description of the visual elements in the shot.'),
  voiceover: z.string().describe('The voiceover or spoken text for the shot.'),
  duration: z.string().describe('The estimated duration of the shot in seconds.'),
});

const CreateMarketingScriptOutputSchema = z.object({
  title: z.string().describe('A catchy title for the video reel.'),
  hook: z.string().describe('A strong opening hook to grab attention in the first 3 seconds.'),
  script: z.array(ShotSchema).describe('An array of shots making up the 15-second video script.'),
  callToAction: z.string().describe('A clear call to action for the end of the video.'),
});
export type CreateMarketingScriptOutput = z.infer<typeof CreateMarketingScriptOutputSchema>;


export async function createMarketingScript(input: CreateMarketingScriptInput): Promise<CreateMarketingScriptOutput> {
  return createMarketingScriptFlow(input);
}

const prompt = ai.definePrompt({
    name: 'createMarketingScriptPrompt',
    input: {schema: CreateMarketingScriptInputSchema},
    output: {schema: CreateMarketingScriptOutputSchema},
    prompt: `You are a creative director specializing in short-form video marketing for fashion and e-commerce brands. Your task is to create a compelling 15-second video script for a social media reel (like Instagram Reels or TikTok).

    The script should be for the following product:
    - Product Name: {{{productName}}}
    - Description: {{{productDescription}}}
    {{#if targetAudience}}
    - Target Audience: {{{targetAudience}}}
    {{/if}}
    
    Your output must be a complete JSON object that follows the specified schema.
    
    The script should be broken down into 3-4 distinct scenes. For each scene, provide a description of the visuals, the voiceover/text overlay, and the approximate duration.
    
    The total video duration should be around 15 seconds.
    
    Start with a strong, attention-grabbing hook for the first 3 seconds.
    End with a clear and compelling call to action for retailers to stock this product from Ladook.`,
});

const createMarketingScriptFlow = ai.defineFlow(
  {
    name: 'createMarketingScriptFlow',
    inputSchema: CreateMarketingScriptInputSchema,
    outputSchema: CreateMarketingScriptOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
