// src/ai/flows/product-recommendations.ts
'use server';
/**
 * @fileOverview Provides AI-powered product recommendations for retailers.
 *
 * - getProductRecommendations - A function that returns product recommendations.
 * - ProductRecommendationsInput - The input type for the getProductRecommendations function.
 * - ProductRecommendationsOutput - The return type for the getProductRecommendations function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ProductRecommendationsInputSchema = z.object({
  userProfile: z
    .string()
    .optional()
    .describe('A description of the user profile and their past purchases.'),
  trendingProducts: z.array(z.string()).optional().describe('A list of trending product names.'),
  newArrivals: z.array(z.string()).optional().describe('A list of new product names.'),
});
export type ProductRecommendationsInput = z.infer<typeof ProductRecommendationsInputSchema>;

const ProductRecommendationsOutputSchema = z.object({
  recommendedProducts: z
    .array(z.string())
    .describe('A list of recommended product names based on trending items and new arrivals.'),
  reasoning: z.string().describe('The AI reasoning behind recommending these products.'),
});
export type ProductRecommendationsOutput = z.infer<typeof ProductRecommendationsOutputSchema>;

export async function getProductRecommendations(input: ProductRecommendationsInput): Promise<ProductRecommendationsOutput> {
  return productRecommendationsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'productRecommendationsPrompt',
  input: {schema: ProductRecommendationsInputSchema},
  output: {schema: ProductRecommendationsOutputSchema},
  prompt: `You are an AI assistant that provides product recommendations for retailers based on trending products, new arrivals, and user profile data.

  Based on the following trending products:
  {{#each trendingProducts}}
  - {{this}}
  {{/each}}

  And the following new arrivals:
  {{#each newArrivals}}
  - {{this}}
  {{/each}}

  {{#if userProfile}}
  Considering the user profile: {{{userProfile}}}
  {{/if}}

  Recommend products that the retailer might be interested in and provide a brief explanation of why these products are recommended.
  Format your output as a JSON object.`,
});

const productRecommendationsFlow = ai.defineFlow(
  {
    name: 'productRecommendationsFlow',
    inputSchema: ProductRecommendationsInputSchema,
    outputSchema: ProductRecommendationsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
