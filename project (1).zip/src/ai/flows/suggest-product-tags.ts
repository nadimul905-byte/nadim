'use server';

/**
 * @fileOverview This file defines a Genkit flow for suggesting product tags based on a product description and images.
 *
 * The flow takes a product description and optionally a product image as input and returns a list of suggested tags.
 * @fileOverview Suggests relevant tags for a product based on its description and images to improve search visibility.
 * - `suggestProductTags`: A function that takes product information and returns suggested tags.
 * - `SuggestProductTagsInput`: The input type for the suggestProductTags function.
 * - `SuggestProductTagsOutput`: The return type for the suggestProductTags function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestProductTagsInputSchema = z.object({
  description: z.string().describe('The description of the product.'),
  photoDataUri: z
    .string()
    .optional()
    .describe(
      "A photo of the product, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type SuggestProductTagsInput = z.infer<typeof SuggestProductTagsInputSchema>;

const SuggestProductTagsOutputSchema = z.object({
  tags: z.array(z.string()).describe('An array of suggested tags for the product.'),
});
export type SuggestProductTagsOutput = z.infer<typeof SuggestProductTagsOutputSchema>;

export async function suggestProductTags(input: SuggestProductTagsInput): Promise<SuggestProductTagsOutput> {
  return suggestProductTagsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestProductTagsPrompt',
  input: {schema: SuggestProductTagsInputSchema},
  output: {schema: SuggestProductTagsOutputSchema},
  prompt: `You are an expert in product categorization and tagging for e-commerce.

  Given the following product description, and optionally a product image, suggest a list of tags that would improve the product's visibility in search results.
  The tags should be relevant to the product and its features.
  Return the tags as a simple array of strings.
  Description: {{{description}}}
  {{#if photoDataUri}}
  Photo: {{media url=photoDataUri}}
  {{/if}}
  `,
});

const suggestProductTagsFlow = ai.defineFlow(
  {
    name: 'suggestProductTagsFlow',
    inputSchema: SuggestProductTagsInputSchema,
    outputSchema: SuggestProductTagsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
