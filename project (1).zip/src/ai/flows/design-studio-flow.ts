'use server';

/**
 * @fileOverview A Genkit flow for generating product design images from a text prompt.
 *
 * This flow uses a text-to-image model to generate design concepts.
 * - `generateDesigns`: A function that takes a text prompt and returns image data URIs.
 * - `GenerateDesignsInput`: The input type for the generateDesigns function.
 * - `GenerateDesignsOutput`: The return type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateDesignsInputSchema = z.object({
  prompt: z.string().describe('A detailed text prompt describing the desired product design.'),
});
export type GenerateDesignsInput = z.infer<typeof GenerateDesignsInputSchema>;

const DesignImageSchema = z.object({
  url: z.string().describe('The data URI of the generated image.'),
  prompt: z.string().describe('The prompt used to generate this specific image.'),
});

const GenerateDesignsOutputSchema = z.object({
  designs: z.array(DesignImageSchema).describe('An array of generated design images.'),
  errorStatus: z.string().optional().describe('Details if a quota or system error occurred.'),
});
export type GenerateDesignsOutput = z.infer<typeof GenerateDesignsOutputSchema>;

export async function generateDesigns(input: GenerateDesignsInput): Promise<GenerateDesignsOutput> {
  return designStudioFlow(input);
}

const designStudioFlow = ai.defineFlow(
  {
    name: 'designStudioFlow',
    inputSchema: GenerateDesignsInputSchema,
    outputSchema: GenerateDesignsOutputSchema,
  },
  async input => {
    // Generate 1 image at a time to respect free tier quotas
    const designs: { url: string; prompt: string }[] = [];

    try {
        const result = await ai.generate({
            model: 'googleai/gemini-2.5-flash-image',
            prompt: `Generate a high-end, high-resolution professional fashion product design photography of: ${input.prompt}. Professional studio lighting, neutral background, editorial style, intricate material details, realistic textures.`,
            config: {
                responseModalities: ['TEXT', 'IMAGE']
            }
        });

        if (result.media) {
            designs.push({
                url: result.media.url,
                prompt: input.prompt
            });
        } else {
            // If no media but no error, we treat it as an empty result
            return { designs: [], errorStatus: "NO_MEDIA" };
        }
    } catch (error: any) {
        console.error("Image generation failed:", error);
        // We catch the error and return it as a status instead of throwing
        // to prevent the Next.js error overlay in the prototype.
        const isQuotaError = error.message?.includes("quota") || error.message?.includes("RESOURCE_EXHAUSTED") || error.message?.includes("429");
        
        return { 
            designs: [], 
            errorStatus: isQuotaError ? "QUOTA_EXCEEDED" : "SYNTHESIS_FAILED" 
        };
    }

    return { designs };
  }
);
