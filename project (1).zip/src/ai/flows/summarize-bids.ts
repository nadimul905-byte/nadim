'use server';

/**
 * @fileOverview Summarizes bids received for a custom design request, highlighting key differences.
 *
 * - summarizeBids - A function that takes a list of bids and returns a summary of their key differences.
 * - SummarizeBidsInput - The input type for the summarizeBids function.
 * - SummarizeBidsOutput - The return type for the summarizeBids function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const BidSchema = z.object({
  vendorName: z.string().describe('The name of the vendor submitting the bid.'),
  price: z.number().describe('The quoted price for the custom design request.'),
  estimatedDeliveryDate: z.string().describe('The estimated delivery date for the custom design request.'),
  sampleImage: z.string().optional().describe('A sample image or mockup of the design.'),
  vendorRating: z.number().describe('The rating of the vendor.'),
  message: z.string().optional().describe('Optional message from vendor to the retailer'),
});

const SummarizeBidsInputSchema = z.object({
  bids: z.array(BidSchema).describe('An array of bids received for a custom design request.'),
  requestDescription: z.string().describe('The description of the custom design request.'),
});
export type SummarizeBidsInput = z.infer<typeof SummarizeBidsInputSchema>;

const SummarizeBidsOutputSchema = z.object({
  summary: z.string().describe('A summary of the bids, highlighting key differences in price, delivery date, and vendor rating.'),
});
export type SummarizeBidsOutput = z.infer<typeof SummarizeBidsOutputSchema>;

export async function summarizeBids(input: SummarizeBidsInput): Promise<SummarizeBidsOutput> {
  return summarizeBidsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'summarizeBidsPrompt',
  input: {schema: SummarizeBidsInputSchema},
  output: {schema: SummarizeBidsOutputSchema},
  prompt: `You are an expert in analyzing bids for custom design requests. You will receive a list of bids and a description of the request. Your task is to summarize the bids, highlighting the key differences in price, estimated delivery date, vendor rating, and any other relevant factors such as the sample image provided and messages. This summary should help the retailer quickly compare the bids and choose the best offer. Be concise and focus on the most important aspects of each bid.

Request Description: {{{requestDescription}}}

Bids:
{{#each bids}}
Vendor Name: {{{vendorName}}}
Price: {{{price}}}
Estimated Delivery Date: {{{estimatedDeliveryDate}}}
{{#if sampleImage}}
Sample Image: {{media url=sampleImage}}
{{/if}}
Vendor Rating: {{{vendorRating}}}
Message: {{{message}}}
{{/each}}`,
});

const summarizeBidsFlow = ai.defineFlow(
  {
    name: 'summarizeBidsFlow',
    inputSchema: SummarizeBidsInputSchema,
    outputSchema: SummarizeBidsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
