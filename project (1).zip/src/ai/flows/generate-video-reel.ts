'use server';

/**
 * @fileOverview A Genkit flow for generating video reels using the Veo model.
 *
 * This flow takes a prompt and uses the Veo model to generate a high-quality vertical video.
 * - `generateVideoReel`: A function that handles the video generation process.
 * - `GenerateVideoReelInput`: The input type for the function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { googleAI } from '@genkit-ai/google-genai';

const GenerateVideoReelInputSchema = z.object({
  prompt: z.string().describe('The description for the video to generate.'),
});
export type GenerateVideoReelInput = z.infer<typeof GenerateVideoReelInputSchema>;

export async function generateVideoReel(input: GenerateVideoReelInput) {
  return generateVideoReelFlow(input);
}

const generateVideoReelFlow = ai.defineFlow(
  {
    name: 'generateVideoReelFlow',
    inputSchema: GenerateVideoReelInputSchema,
    outputSchema: z.object({
      videoUrl: z.string().optional(),
      error: z.string().optional(),
      status: z.enum(["SUCCESS", "BILLING_REQUIRED", "QUOTA_EXCEEDED", "ERROR"]).optional(),
    }),
  },
  async (input) => {
    try {
      let { operation } = await ai.generate({
        model: googleAI.model('veo-2.0-generate-001'),
        prompt: input.prompt,
        config: {
          durationSeconds: 5,
          aspectRatio: '9:16',
          personGeneration: 'allow_all',
        },
      });

      if (!operation) {
        throw new Error('Expected the model to return an operation');
      }

      // Poll for completion (max 24 attempts * 5s = 2 minutes)
      let attempts = 0;
      while (!operation.done && attempts < 24) {
        operation = await ai.checkOperation(operation);
        if (!operation.done) {
          await new Promise((resolve) => setTimeout(resolve, 5000));
          attempts++;
        }
      }

      if (operation.error) {
        throw new Error('failed to generate video: ' + operation.error.message);
      }

      if (!operation.done) {
        throw new Error('Video generation timed out.');
      }

      const videoPart = operation.output?.message?.content.find((p) => !!p.media);
      if (!videoPart?.media?.url) {
        throw new Error('Failed to find the generated video in the output');
      }

      // Fetch binary data with API key
      const videoDownloadResponse = await fetch(
        `${videoPart.media.url}&key=${process.env.GEMINI_API_KEY}`
      );
      
      if (!videoDownloadResponse.ok) {
        throw new Error('Failed to download video from the cloud terminal');
      }

      const buffer = await videoDownloadResponse.arrayBuffer();
      const base64Video = Buffer.from(buffer).toString('base64');
      
      return { 
        videoUrl: `data:video/mp4;base64,${base64Video}`,
        status: "SUCCESS"
      };
      
    } catch (error: any) {
      // Check for specific billing or quota errors to provide better UX
      const isBillingError = error.message?.includes("billing") || error.message?.includes("INVALID_ARGUMENT");
      const isQuotaError = error.message?.includes("quota") || error.message?.includes("429") || error.message?.includes("RESOURCE_EXHAUSTED");
      
      return { 
        error: error.message || "Failed to generate video",
        status: isBillingError ? "BILLING_REQUIRED" : isQuotaError ? "QUOTA_EXCEEDED" : "ERROR"
      };
    }
  }
);
