import { config } from 'dotenv';
config();

import '@/ai/flows/product-recommendations.ts';
import '@/ai/flows/suggest-product-tags.ts';
import '@/ai/flows/summarize-bids.ts';
import '@/ai/flows/design-studio-flow.ts';
import '@/ai/flows/create-marketing-script.ts';
import '@/ai/flows/generate-video-reel.ts';
