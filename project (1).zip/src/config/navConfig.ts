import { 
  Home, 
  Shapes, 
  ShoppingCart, 
  Package, 
  MessageCircle, 
  User, 
  LayoutDashboard, 
  Boxes, 
  Wallet, 
  Palette, 
  Landmark, 
  ShieldAlert, 
  TrendingUp,
  Users,
  LayoutGrid,
  FileArchive,
  BarChart3,
  Settings
} from 'lucide-react';
import type { NavItem } from '@/components/layout/BottomNav';

export const retailerNavItems: NavItem[] = [
  { href: '/retailer', label: 'Home', icon: Home },
  { href: '/retailer/social', label: 'Discovery', icon: LayoutGrid },
  { href: '/retailer/categories', label: 'Categories', icon: Shapes },
  { href: '/retailer/messages', label: 'Messages', icon: MessageCircle },
  { href: '/retailer/profile/wallet', label: 'Finance', icon: Wallet },
  { href: '/retailer/profile', label: 'Profile', icon: User },
];

export const vendorNavItems: NavItem[] = [
  { href: '/vendor', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/vendor/catalog', label: 'Catalog', icon: Boxes },
  { href: '/vendor/design-studio', label: 'Studio', icon: Palette },
  { href: '/vendor/messages', label: 'Messages', icon: MessageCircle },
  { href: '/vendor/profile/wallet', label: 'Finance', icon: Landmark },
  { href: '/vendor/orders', label: 'Orders', icon: Package },
  { href: '/vendor/profile', label: 'Profile', icon: User },
];

export const adminNavItems: NavItem[] = [
  { href: '/admin', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/admin/users', label: 'Users', icon: Users },
  { href: '/admin/content', label: 'Content', icon: FileArchive },
  { href: '/admin/disputes', label: 'Disputes', icon: ShieldAlert },
  { href: '/admin/finance', label: 'Finance', icon: Landmark },
  { href: '/admin/reports', label: 'Reports', icon: BarChart3 },
  { href: '/admin/social', label: 'Community', icon: LayoutGrid },
  { href: '/admin/settings', label: 'Settings', icon: Settings },
];

export const consumerNavItems: NavItem[] = [
  { href: '/consumer', label: 'Home', icon: Home },
  { href: '/consumer/categories', label: 'Shop', icon: Shapes },
  { href: '/consumer/cart', label: 'Cart', icon: ShoppingCart },
  { href: '/consumer/orders', label: 'My Orders', icon: Package },
  { href: '/consumer/profile', label: 'Me', icon: User },
];
