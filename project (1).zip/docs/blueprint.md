# **App Name**: Ladook Mobile

## Core Features:

- Unified Entry Flow: Unified entry flow for all user roles (Vendor, Retailer, Admin) via Splash screen, Onboarding, and Role Selection.
- Role-Based Navigation: Role-based bottom navigation with distinct dashboards and features for Retailer, Vendor, and Admin roles, streamlining access to relevant functionalities.
- AI-Driven Recommendations: AI-powered recommendations for Retailers on the home screen to enhance product discovery based on trending items. The AI can tool appropriate criteria when to surface different product categories.
- Custom Design Requests: Custom request system that enables Retailers to post design requests and Vendors to submit bids, ensuring a seamless collaboration process.
- Real-Time Messaging: Real-time chat functionality that facilitates direct communication between Retailers and Vendors, promoting quick resolution of queries and issues.
- Vendor Analytics Dashboard: Comprehensive vendor analytics dashboard displaying sales trends, product performance, and rating trends for Vendors to optimize their offerings.
- Admin Control Panel: Admin panel to oversee user management, product moderation, dispute resolution, and platform settings, ensuring smooth platform operation.

## Style Guidelines:

- Primary color: Burgundy (#800020) to evoke feelings of luxury, sophistication, and quality. This reflects the focus on fashion and upscale design.
- Background color: Light gray (#F0F0F0) to provide a clean and neutral backdrop that allows products and UI elements to stand out.
- Accent color: Gold (#FFD700) to highlight key interactive elements like 'Place Order' and 'Submit Bid' buttons, drawing user attention.
- Body text and headline font: 'Inter', a grotesque-style sans-serif for a clean, neutral, contemporary look suitable for UI.
- Use simple and modern icons to ensure intuitive navigation.
- Employ a consistent grid-based layout with clear content separation to improve usability.
- Use subtle animations for transitions and feedback to enhance user experience.